# Exploration Patterns

Common workflows and patterns for exploring JPA entities and Spring Data repositories.

## Pattern Categories

1. **Discovery Patterns** - Finding what exists
2. **Analysis Patterns** - Understanding structure and relationships
3. **Audit Patterns** - Checking completeness and consistency
4. **Integration Patterns** - Working with existing systems

---

## Discovery Patterns

### Pattern 1: Complete Domain Discovery

**Goal:** Get comprehensive overview of entire domain model

**Steps:**
```
1. find_jpa_entities(projectPath)
   → Returns list of all entities

2. For each entity package:
   find_jpa_entities(entityPackage, projectPath)
   → Group entities by domain area

3. find_spring_data_repositories(projectPath)
   → See data access layer structure

4. For key entities:
   get_jpa_entity_by_name(entityName, projectPath)
   → Deep dive into important entities
```

**When to use:**
- New team member onboarding
- Documentation generation
- Architecture review
- Pre-implementation planning

**Output:**
- Complete entity list
- Package organization
- Repository coverage
- Domain boundaries

---

### Pattern 2: Package-Scoped Discovery

**Goal:** Explore entities in specific package

**Steps:**
```
1. find_jpa_entities(entityPackage="com.app.orders", projectPath)
   → Get entities in orders package

2. For each entity:
   get_jpa_entity_by_name(entityName, projectPath)
   → Analyze entity details

3. find_spring_data_repositories(projectPath)
   → Check which have repositories
```

**When to use:**
- Working on specific feature
- Understanding domain subdomain
- Refactoring specific area

**Output:**
- Entities in package
- Relationships within package
- Cross-package dependencies

---

### Pattern 3: Module-Based Discovery

**Goal:** Explore entities by module in multi-module project

**Steps:**
```
1. For each module:
   find_jpa_entities(moduleName="module-name", projectPath)
   → Get entities per module

2. Analyze cross-module dependencies:
   For each entity: get_jpa_entity_by_name
   → Check relationships to other modules

3. find_spring_data_repositories(moduleName, projectPath)
   → Repository organization per module
```

**When to use:**
- Multi-module project architecture
- Understanding module boundaries
- Planning module refactoring
- Identifying circular dependencies

**Output:**
- Entity distribution across modules
- Inter-module relationships
- Module coupling analysis

---

## Analysis Patterns

### Pattern 4: Relationship Analysis

**Goal:** Understand relationships between entities

**Steps:**
```
1. Identify starting entity:
   get_jpa_entity_by_name("User", projectPath)
   → Get User entity with relationships

2. For each relationship attribute:
   get_jpa_entity_by_name(relatedEntityType, projectPath)
   → Get related entity structure

3. Analyze bidirectional relationships:
   Check if mappedBy exists
   → Determine owning side vs inverse side

4. Check relationship configuration:
   - Fetch type (LAZY/EAGER)
   - Cascade operations
   - Join columns
   - Orphan removal
```

**When to use:**
- Debugging LazyInitializationException
- Understanding data loading
- Planning query optimization
- Refactoring relationships

**Output:**
- Relationship diagram (conceptual)
- Owning vs inverse sides
- Fetch strategies
- Cascade configurations

---

### Pattern 5: Inheritance Hierarchy Analysis

**Goal:** Understand entity inheritance structure

**Steps:**
```
1. Find entities with inheritance:
   find_jpa_entities(projectPath)
   → Look for inheritanceType != null

2. Analyze parent entity:
   get_jpa_entity_by_name("BaseEntity", projectPath)
   → Get inheritance strategy, discriminator

3. Analyze each child entity:
   get_jpa_entity_by_name(childEntityName, projectPath)
   → Get discriminator values, specific attributes

4. Map the hierarchy:
   Parent
   ├── Child1 (discriminator: value1)
   ├── Child2 (discriminator: value2)
   └── Child3 (discriminator: value3)
```

**When to use:**
- Understanding polymorphic queries
- Planning subclass additions
- Analyzing table structure
- Debugging inheritance issues

**Output:**
- Inheritance tree
- Strategy (SINGLE_TABLE, JOINED, etc.)
- Discriminator configuration
- Attribute distribution

---

### Pattern 6: Composite Key Analysis

**Goal:** Understand composite primary keys

**Steps:**
```
1. Find entities with composite keys:
   find_jpa_entities(projectPath)
   → Look for compositeId: true

2. Analyze composite key entity:
   get_jpa_entity_by_name(entityName, projectPath)
   → Get all @Id attributes

3. Check for @IdClass or @EmbeddedId:
   Look at attributes with isId: true
   → Multiple means @IdClass approach

4. Analyze related entities:
   How do they reference this entity?
```

**When to use:**
- Understanding join tables
- Working with legacy schemas
- Implementing many-to-many with extra columns
- Debugging composite key issues

**Output:**
- Composite key structure
- Implementation approach
- Related entity references

---

## Audit Patterns

### Pattern 7: Repository Coverage Audit

**Goal:** Ensure all entities have repositories

**Steps:**
```
1. Get all entities:
   find_jpa_entities(projectPath)
   → List: [User, Order, OrderItem, ...]

2. Get all repositories:
   find_spring_data_repositories(projectPath)
   → List: [UserRepository, OrderRepository, ...]

3. Match entities to repositories:
   For each entity:
     Check if corresponding repository exists

4. Analyze missing repositories:
   For entities without repositories:
     get_jpa_entity_by_name(entityName, projectPath)
     → Determine if repository needed (check relationships)
```

**When to use:**
- Data access layer audit
- Before starting new feature
- Code quality review
- Documentation generation

**Output:**
- Entities with repositories
- Missing repositories
- Intentionally missing (explained)
- Recommendations

---

### Pattern 8: Database Mapping Audit

**Goal:** Verify database mappings and conventions

**Steps:**
```
1. Get all entities:
   find_jpa_entities(projectPath)

2. For each entity:
   get_jpa_entity_by_name(entityName, projectPath)
   Check:
   - tableName convention (camelCase → snake_case?)
   - column names
   - index definitions
   - unique constraints

3. Look for inconsistencies:
   - Mixed naming conventions
   - Missing indexes on foreign keys
   - No unique constraints on business keys
```

**When to use:**
- Database schema review
- Before migration
- Performance optimization
- Standardization effort

**Output:**
- Naming convention analysis
- Index coverage
- Missing constraints
- Inconsistencies list

---

### Pattern 9: Fetch Strategy Audit

**Goal:** Review fetch types for performance

**Steps:**
```
1. Get all entities:
   find_jpa_entities(projectPath)

2. For each entity:
   get_jpa_entity_by_name(entityName, projectPath)

3. For each relationship:
   Check fetch type:
   - OneToMany: Should be LAZY (collections)
   - ManyToOne: Can be EAGER or LAZY
   - ManyToMany: Should be LAZY (collections)
   - OneToOne: Depends on usage

4. Identify potential issues:
   - EAGER collections (N+1 problem)
   - Too many EAGER relationships (cartesian product)
```

**When to use:**
- Performance optimization
- Debugging N+1 queries
- LazyInitializationException issues
- Before production deployment

**Output:**
- Fetch strategy summary
- Potential N+1 problems
- EAGER collection warnings
- Recommendations

---

## Integration Patterns

### Pattern 10: Legacy Database Reverse Engineering

**Goal:** Generate entities from existing database

**Steps:**
```
1. Identify database tables:
   List all tables to reverse engineer

2. For each table:
   reverse_engineering_jpa_entity_by_name(tableName, projectPath)
   → Generates entity structure

3. Verify generated entities:
   find_jpa_entities(projectPath)
   → Confirm all entities created

4. Analyze generated structure:
   For each entity:
     get_jpa_entity_by_name(entityName, projectPath)
     → Review mappings

5. Plan relationship additions:
   Identify foreign keys
   → Need to add @ManyToOne, @OneToMany manually
```

**When to use:**
- Legacy system integration
- Database-first to code-first migration
- Initial entity scaffolding
- Working with existing production database

**Output:**
- Generated entities
- Attribute mappings
- Identified relationships (not yet mapped)
- Manual steps needed

---

### Pattern 11: Pre-Implementation Discovery

**Goal:** Understand existing structure before creating new entities

**Steps:**
```
1. Check if entity already exists:
   find_jpa_entities(projectPath)
   → Search for similar entity names

2. Analyze related entities:
   If creating Order entity, analyze:
   - User (customer)
   - Product (items)
   - Payment (if exists)

   get_jpa_entity_by_name for each

3. Check for similar patterns:
   Look at how existing relationships are structured
   → Follow project conventions

4. Verify repository patterns:
   find_spring_data_repositories(projectPath)
   → Understand repository naming and structure

5. Check package organization:
   find_jpa_entities(entityPackage, projectPath)
   → Understand package structure
```

**When to use:**
- Before creating new entities
- Planning new feature
- Ensuring consistency
- Understanding project conventions

**Output:**
- Existing related entities
- Project conventions
- Package structure
- Relationship patterns
- Repository patterns

---

### Pattern 12: Cross-Module Dependency Analysis

**Goal:** Understand dependencies between modules

**Steps:**
```
1. For each module:
   find_jpa_entities(moduleName, projectPath)
   → Get entities per module

2. For each entity:
   get_jpa_entity_by_name(entityName, projectPath)
   → Analyze relationship types

3. Build dependency graph:
   Module A depends on Module B if:
   - Entity in A references entity in B
   - Repository in A uses entity from B

4. Identify issues:
   - Circular dependencies
   - Tight coupling
   - Wrong dependency direction
```

**When to use:**
- Multi-module architecture review
- Refactoring module boundaries
- Planning module extraction
- Reducing coupling

**Output:**
- Module dependency graph
- Circular dependencies
- Coupling metrics
- Refactoring suggestions

---

## Pattern Selection Guide

| Goal | Pattern | Tools Used |
|------|---------|------------|
| Understand entire domain | Complete Domain Discovery | find_jpa_entities, get_jpa_entity_by_name |
| Debug lazy loading | Relationship Analysis | get_jpa_entity_by_name (both sides) |
| Ensure all repos exist | Repository Coverage Audit | find_jpa_entities, find_spring_data_repositories |
| Integrate legacy DB | Legacy DB Reverse Engineering | reverse_engineering_jpa_entity_by_name |
| Plan new entity | Pre-Implementation Discovery | find_jpa_entities, get_jpa_entity_by_name |
| Optimize queries | Fetch Strategy Audit | find_jpa_entities, get_jpa_entity_by_name |
| Understand inheritance | Inheritance Hierarchy Analysis | get_jpa_entity_by_name |
| Multi-module review | Cross-Module Dependency Analysis | find_jpa_entities (by module) |

---

## Combining Patterns

### Comprehensive Audit Workflow

```
1. Discovery Phase:
   - Complete Domain Discovery
   - Module-Based Discovery (if applicable)

2. Analysis Phase:
   - Relationship Analysis (key entities)
   - Inheritance Hierarchy Analysis
   - Fetch Strategy Audit

3. Audit Phase:
   - Repository Coverage Audit
   - Database Mapping Audit

4. Documentation Phase:
   - Generate summary
   - Identify issues
   - Create recommendations
```

### New Feature Preparation Workflow

```
1. Pre-Implementation Discovery
   - Check existing entities
   - Understand conventions

2. Relationship Analysis
   - Analyze entities you'll integrate with

3. Repository Patterns
   - Check how repositories are structured

4. Ready for Implementation
   - Use jpa-implementation skill
```

### Performance Optimization Workflow

```
1. Fetch Strategy Audit
   - Identify EAGER problems

2. Relationship Analysis
   - Understand entity graphs

3. Database Mapping Audit
   - Check indexes

4. Implement Optimizations
   - Use jpa-implementation to modify
```
