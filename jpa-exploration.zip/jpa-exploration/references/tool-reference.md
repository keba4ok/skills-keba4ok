# Tool Reference - JPA Exploration

Comprehensive documentation for all exploration tools.

## find_jpa_entities

### Purpose
Discover and analyze existing JPA entities in your Spring Data project.

### When to Use
- Getting an overview of all entities in the project
- Understanding domain model structure
- Checking what entities exist in a specific package
- Exploring entity hierarchies and inheritance
- Before creating new entities (to avoid duplicates)
- Analyzing entity organization across modules

### Parameters

#### entityPackage (optional)
- **Type:** String
- **Description:** Filter entities by package name
- **Examples:**
  - `"com.example.domain"`
  - `"com.myapp.entities"`
  - `"persistence.model"`
- **When to use:** When you want to narrow down results to a specific package
- **When to omit:** To discover ALL entities in the entire project

#### moduleName (optional)
- **Type:** String
- **Description:** Search within a specific module (for multi-module projects)
- **Examples:**
  - `"domain-module"`
  - `"entity-layer"`
  - `"core-service"`
- **When to use:** In multi-module Spring Boot projects to scope the search
- **When to omit:** For single-module projects or when searching across all modules

#### projectPath (recommended)
- **Type:** String
- **Description:** The project root path
- **Examples:**
  - `"/Users/username/projects/my-spring-app"`
  - `"/home/dev/workspace/order-service"`
- **When to use:** ALWAYS pass if you know it - reduces ambiguous calls
- **Default behavior:** If not provided, will attempt to detect from current working directory

### Return Value

Returns an object with:
```json
{
  "entities": [
    {
      "name": "User",
      "tableName": "users",
      "packageName": "com.example.domain",
      "attributes": [...],
      "mappedSuperclass": false,
      "compositeId": false,
      "inheritanceType": null,
      "superclass": null,
      "indexes": [...],
      "namedQueries": [...]
    }
  ]
}
```

### Usage Examples

**Example 1: Discover all entities in project**
```
Input: "Show me all JPA entities in the project"

Tool Call:
{
  "projectPath": "/Users/dev/my-app"
}

Use Case: Getting complete domain model overview
```

**Example 2: Find entities in specific package**
```
Input: "What entities exist in com.example.domain package?"

Tool Call:
{
  "entityPackage": "com.example.domain",
  "projectPath": "/Users/dev/my-app"
}

Use Case: Exploring a specific domain area
```

**Example 3: Multi-module project search**
```
Input: "List entities in the core module"

Tool Call:
{
  "moduleName": "core-module",
  "projectPath": "/Users/dev/my-app"
}

Use Case: Scoping search to specific module
```

---

## get_jpa_entity_by_name

### Purpose
Retrieve detailed information about a specific JPA entity including all attributes, relationships, inheritance structure, and database mappings.

### When to Use
- Analyzing entity structure before modifications
- Understanding entity relationships and their configuration
- Checking fetch types (LAZY vs EAGER) for performance tuning
- Diagnosing LazyInitializationException issues
- Understanding the owning side of relationships
- Checking inheritance strategies
- Preparing for entity migrations
- Verifying entity annotations and mappings

### Parameters

#### entityName (required)
- **Type:** String
- **Description:** Entity class name or fully qualified name
- **Examples:**
  - `"User"` (simple name)
  - `"Product"` (simple name)
  - `"com.example.domain.Order"` (fully qualified)
- **Tips:**
  - Use simple name if entity name is unique in project
  - Use FQN if there are multiple entities with same name

#### projectPath (recommended)
- **Type:** String
- **Description:** The project root path
- **When to use:** ALWAYS pass if known

### Return Value

Returns detailed entity information:
```json
{
  "entities": [
    {
      "name": "User",
      "tableName": "users",
      "packageName": "com.example.domain",
      "attributes": [
        {
          "name": "id",
          "type": "Long",
          "isId": true,
          "column": "id",
          "columnProperties": {...},
          "idGenerationProperties": {
            "generatedStrategy": "IDENTITY"
          },
          "relationshipProperties": {},
          "collectionProperties": {},
          "embeddedProperties": {}
        },
        {
          "name": "orders",
          "type": "List<Order>",
          "isId": false,
          "relationshipProperties": {
            "relationship": "OneToMany",
            "mappedBy": "user",
            "cascade": "ALL",
            "fetch": "LAZY"
          }
        }
      ],
      "mappedSuperclass": false,
      "compositeId": false,
      "inheritanceType": null,
      "superclass": null,
      "indexes": [
        {
          "name": "idx_user_email",
          "columnList": ["email"],
          "unique": true
        }
      ]
    }
  ]
}
```

### Usage Examples

**Example 1: Analyze entity structure**
```
Input: "Show me the User entity structure"

Tool Call:
{
  "entityName": "User",
  "projectPath": "/Users/dev/my-app"
}

Use Case: Understanding entity before modifications
```

**Example 2: Debug relationship issues**
```
Input: "I'm getting LazyInitializationException with Order entity, show me its configuration"

Tool Call:
{
  "entityName": "Order",
  "projectPath": "/Users/dev/my-app"
}

Use Case: Check fetch types and relationship configuration
What to look for:
- relationshipProperties.fetch (LAZY vs EAGER)
- relationshipProperties.mappedBy (owning side)
- relationshipProperties.cascade
```

**Example 3: Understand inheritance**
```
Input: "How is the Employee entity structured with inheritance?"

Tool Call:
{
  "entityName": "Employee",
  "projectPath": "/Users/dev/my-app"
}

Use Case: Analyze inheritance strategy
What to check:
- inheritanceType (SINGLE_TABLE, JOINED, etc.)
- superclass (parent entity)
- discriminatorColumn and discriminatorValue
```

---

## find_spring_data_repositories

### Purpose
Discover existing Spring Data repositories and analyze their relationships with JPA entities.

### When to Use
- Understanding current data access layer
- Checking if a repository exists for an entity
- Identifying missing repositories
- Analyzing repository inheritance patterns
- Auditing Spring Data setup
- Before creating new repositories (to avoid duplicates)
- Planning repository extensions

### Parameters

#### entityName (optional)
- **Type:** String
- **Description:** Filter repositories by entity
- **Examples:**
  - `"User"`
  - `"Product"`
  - `"com.example.Order"`
- **When to use:** Looking for repository for specific entity
- **When to omit:** Want to see all repositories in project

#### moduleName (optional)
- **Type:** String
- **Description:** Scope search to specific module
- **Examples:**
  - `"data-module"`
  - `"persistence-layer"`
- **When to use:** Multi-module projects
- **When to omit:** Single-module projects

#### searchInLibraries (optional)
- **Type:** Boolean
- **Description:** Include repositories from external dependencies
- **Default:** false
- **When to use:** Analyzing complete Spring Data ecosystem including inherited repositories
- **When to omit:** Only want project-specific repositories

#### projectPath (recommended)
- **Type:** String
- **Description:** The project root path
- **When to use:** ALWAYS pass if known

### Return Value

Returns repository information:
```json
{
  "repositories": [
    {
      "name": "UserRepository",
      "path": "/src/main/java/com/example/repository/UserRepository.java",
      "content": "public interface UserRepository extends JpaRepository<User, Long> {...}",
      "entity": "User",
      "description": "Repository for User entity"
    }
  ]
}
```

### Usage Examples

**Example 1: List all repositories**
```
Input: "Show me all Spring Data repositories"

Tool Call:
{
  "projectPath": "/Users/dev/my-app"
}

Use Case: Complete data access layer overview
```

**Example 2: Check if repository exists**
```
Input: "Does a UserRepository exist?"

Tool Call:
{
  "entityName": "User",
  "projectPath": "/Users/dev/my-app"
}

Use Case: Verify repository before creating
```

**Example 3: Module-specific search**
```
Input: "Find all repositories in the core module"

Tool Call:
{
  "moduleName": "core-module",
  "projectPath": "/Users/dev/my-app"
}

Use Case: Multi-module project repository audit
```

---

## reverse_engineering_jpa_entity_by_name

### Purpose
Generate JPA entity classes from existing database tables. Perfect for legacy database integration or database-first development.

### When to Use
- Working with existing/legacy databases
- Migrating from database-first to code-first
- Rapid entity scaffolding from schema
- Understanding database structure through entities
- Creating initial entity models from production database

### Parameters

#### entityTableName (required)
- **Type:** String
- **Description:** Database table name to reverse engineer
- **Examples:**
  - `"users"`
  - `"product_catalog"`
  - `"order_items"`
- **Format:** Use actual database table name (usually lowercase with underscores)

#### projectPath (recommended)
- **Type:** String
- **Description:** The project root path
- **When to use:** ALWAYS pass if known

### Return Value

Returns generated entity attributes:
```json
{
  "attributes": [
    "id: Long",
    "username: String",
    "email: String",
    "created_at: Timestamp"
  ]
}
```

### Usage Examples

**Example 1: Generate entity from table**
```
Input: "Create an entity from the users table"

Tool Call:
{
  "entityTableName": "users",
  "projectPath": "/Users/dev/my-app"
}

Use Case: Reverse engineering from database
```

**Example 2: Legacy database integration**
```
Input: "I have a legacy database with a 'product_catalog' table, generate an entity for it"

Tool Call:
{
  "entityTableName": "product_catalog",
  "projectPath": "/Users/dev/my-app"
}

Use Case: Integrating with existing database schema
```

**Example 3: Multiple table reverse engineering**
```
Input: "Generate entities for tables: users, orders, order_items"

Tool Calls (sequential):
1. {"entityTableName": "users", "projectPath": "/..."}
2. {"entityTableName": "orders", "projectPath": "/..."}
3. {"entityTableName": "order_items", "projectPath": "/..."}

Use Case: Batch reverse engineering
```

---

## Common Tool Combinations

### Pattern 1: Complete Domain Discovery
```
1. find_jpa_entities()
   → Get all entities overview

2. get_jpa_entity_by_name("User")
   → Detailed analysis of key entities

3. find_spring_data_repositories()
   → See which entities have repositories
```

### Pattern 2: Entity-Specific Investigation
```
1. get_jpa_entity_by_name("Order")
   → Analyze Order entity

2. find_spring_data_repositories(entityName: "Order")
   → Check if OrderRepository exists

3. get_jpa_entity_by_name("OrderItem")
   → Analyze related entities
```

### Pattern 3: Package Exploration
```
1. find_jpa_entities(entityPackage: "com.example.domain")
   → Get entities in package

2. For each entity: get_jpa_entity_by_name(entityName)
   → Detailed analysis of each

3. find_spring_data_repositories()
   → Check repository coverage
```

### Pattern 4: Legacy Database Migration
```
1. reverse_engineering_jpa_entity_by_name("users")
   → Generate from DB table

2. get_jpa_entity_by_name("User")
   → Verify generated structure

3. find_jpa_entities()
   → See all reverse-engineered entities
```

## Best Practices

1. **Always pass projectPath** - Reduces ambiguous tool calls and improves accuracy

2. **Start broad, then narrow** - Use `find_jpa_entities` first for overview, then `get_jpa_entity_by_name` for details

3. **Verify before creating** - Always check if entity or repository exists before creating new ones

4. **Understand relationships** - Use `get_jpa_entity_by_name` to analyze both sides of relationships

5. **Module awareness** - In multi-module projects, always specify `moduleName` to avoid confusion

6. **Repository audit** - Regularly use `find_spring_data_repositories` to ensure all entities have repositories

7. **Documentation** - The detailed output from these tools serves as living documentation of your domain model
