# Practical Examples - JPA Exploration

Real-world scenarios and complete workflows for exploring JPA entities and Spring Data repositories.

## Example 1: New Developer Onboarding

**Scenario:** A new developer joins the project and needs to understand the domain model.

**Workflow:**

```
User: "I'm new to this project. Show me what entities we have."

Step 1: Get complete entity overview
Tool: find_jpa_entities
{
  "projectPath": "/Users/dev/order-service"
}

Result:
- User
- Order
- OrderItem
- Product
- Category
- Payment

Step 2: Understand core entity (User)
Tool: get_jpa_entity_by_name
{
  "entityName": "User",
  "projectPath": "/Users/dev/order-service"
}

Result shows:
- id: Long (primary key, IDENTITY strategy)
- username: String (unique, not null)
- email: String (unique)
- orders: List<Order> (OneToMany, mappedBy="user", LAZY)
- createdAt: LocalDateTime

Step 3: Check repositories
Tool: find_spring_data_repositories
{
  "projectPath": "/Users/dev/order-service"
}

Result:
- UserRepository (JpaRepository<User, Long>)
- OrderRepository (JpaRepository<Order, Long>)
- ProductRepository (JpaRepository<Product, Long>)

Summary for developer:
"The project has 6 entities organized in an e-commerce domain model:
- User (with orders relationship)
- Order and OrderItem (order management)
- Product and Category (product catalog)
- Payment (payment processing)

All entities have corresponding Spring Data repositories extending JpaRepository."
```

---

## Example 2: Debugging LazyInitializationException

**Scenario:** Application throws LazyInitializationException when accessing orders from User.

**Workflow:**

```
User: "I'm getting LazyInitializationException when trying to access user.getOrders(). Can you help?"

Step 1: Analyze User entity relationships
Tool: get_jpa_entity_by_name
{
  "entityName": "User",
  "projectPath": "/Users/dev/myapp"
}

Key findings from result:
{
  "name": "orders",
  "type": "List<Order>",
  "relationshipProperties": {
    "relationship": "OneToMany",
    "mappedBy": "user",
    "fetch": "LAZY",  ← Problem identified!
    "cascade": "ALL"
  }
}

Step 2: Check the other side (Order entity)
Tool: get_jpa_entity_by_name
{
  "entityName": "Order",
  "projectPath": "/Users/dev/myapp"
}

Key findings:
{
  "name": "user",
  "type": "User",
  "relationshipProperties": {
    "relationship": "ManyToOne",
    "joinColumn": "user_id",
    "fetch": "LAZY"
  }
}

Analysis:
"The LazyInitializationException occurs because:
1. User.orders is configured with LAZY fetch
2. The collection is being accessed outside the transaction/session
3. User entity is the inverse side (mappedBy='user')
4. Order entity is the owning side (has joinColumn)

Solutions:
A. Use @Transactional on the service method
B. Use JOIN FETCH in query: 'SELECT u FROM User u JOIN FETCH u.orders'
C. Change to EAGER fetch (not recommended for collections)
D. Use EntityGraph to fetch orders selectively"
```

---

## Example 3: Planning New Feature

**Scenario:** Need to add a shopping cart feature. First, understand existing structure.

**Workflow:**

```
User: "We need to add a shopping cart feature. What entities do we have related to products and users?"

Step 1: Find all entities
Tool: find_jpa_entities
{
  "entityPackage": "com.shop.domain",
  "projectPath": "/Users/dev/shop-app"
}

Result shows: User, Product, Category, Order, OrderItem

Step 2: Analyze User entity
Tool: get_jpa_entity_by_name
{
  "entityName": "User",
  "projectPath": "/Users/dev/shop-app"
}

Key attributes:
- id: Long
- username: String
- orders: List<Order> (OneToMany)
- No cart relationship exists

Step 3: Analyze Product entity
Tool: get_jpa_entity_by_name
{
  "entityName": "Product",
  "projectPath": "/Users/dev/shop-app"
}

Key attributes:
- id: Long
- name: String
- price: BigDecimal
- category: Category (ManyToOne)
- No cart relationship exists

Step 4: Check for any cart-related entities
Tool: find_jpa_entities
{
  "projectPath": "/Users/dev/shop-app"
}

Result: No Cart or CartItem entities exist

Analysis:
"Current state:
- User entity exists with orders relationship
- Product entity exists with category relationship
- No shopping cart entities exist

Recommendation for cart feature:
1. Create Cart entity with OneToOne relationship to User
2. Create CartItem entity with:
   - ManyToOne to Cart
   - ManyToOne to Product
   - quantity field
3. Add cart: Cart relationship to User
4. Create CartRepository and CartItemRepository

Next step: Use jpa-implementation skill to create these entities."
```

---

## Example 4: Legacy Database Integration

**Scenario:** Integrating with an existing database schema.

**Workflow:**

```
User: "We have a legacy database with tables: customer, product, sales_order. Generate entities for these."

Step 1: Reverse engineer customer table
Tool: reverse_engineering_jpa_entity_by_name
{
  "entityTableName": "customer",
  "projectPath": "/Users/dev/legacy-app"
}

Result:
{
  "attributes": [
    "customer_id: Long",
    "customer_name: String",
    "email: String",
    "phone: String",
    "created_date: Date"
  ]
}

Step 2: Reverse engineer product table
Tool: reverse_engineering_jpa_entity_by_name
{
  "entityTableName": "product",
  "projectPath": "/Users/dev/legacy-app"
}

Result:
{
  "attributes": [
    "product_id: Long",
    "product_name: String",
    "price: BigDecimal",
    "stock_quantity: Integer"
  ]
}

Step 3: Reverse engineer sales_order table
Tool: reverse_engineering_jpa_entity_by_name
{
  "entityTableName": "sales_order",
  "projectPath": "/Users/dev/legacy-app"
}

Result:
{
  "attributes": [
    "order_id: Long",
    "customer_id: Long",
    "order_date: Date",
    "total_amount: BigDecimal",
    "status: String"
  ]
}

Step 4: Verify generated entities
Tool: find_jpa_entities
{
  "projectPath": "/Users/dev/legacy-app"
}

Result: Customer, Product, SalesOrder entities created

Step 5: Analyze relationships
Tool: get_jpa_entity_by_name
{
  "entityName": "SalesOrder",
  "projectPath": "/Users/dev/legacy-app"
}

Analysis:
"Successfully reverse-engineered 3 entities from legacy database.

Next steps:
1. Review field mappings (customer_id → customerId)
2. Add proper relationships:
   - SalesOrder.customer: ManyToOne to Customer
   - Customer.orders: OneToMany to SalesOrder
3. Add JPA annotations for relationships
4. Create repositories for all entities
5. Consider adding indexes for foreign keys"
```

---

## Example 5: Multi-Module Project Exploration

**Scenario:** Large project with multiple modules, need to understand entity distribution.

**Workflow:**

```
User: "This is a multi-module project. Show me entities in each module."

Step 1: Explore core module
Tool: find_jpa_entities
{
  "moduleName": "core-module",
  "projectPath": "/Users/dev/enterprise-app"
}

Result: User, Role, Permission (security entities)

Step 2: Explore order module
Tool: find_jpa_entities
{
  "moduleName": "order-module",
  "projectPath": "/Users/dev/enterprise-app"
}

Result: Order, OrderItem, OrderStatus

Step 3: Explore product module
Tool: find_jpa_entities
{
  "moduleName": "product-module",
  "projectPath": "/Users/dev/enterprise-app"
}

Result: Product, Category, Inventory

Step 4: Check for cross-module relationships
Tool: get_jpa_entity_by_name
{
  "entityName": "Order",
  "projectPath": "/Users/dev/enterprise-app"
}

Look for:
- user: User (ManyToOne to core-module entity)
- items: List<OrderItem> (OneToMany within module)
- Check if Product is referenced

Step 5: Find repositories by module
Tool: find_spring_data_repositories
{
  "moduleName": "order-module",
  "projectPath": "/Users/dev/enterprise-app"
}

Result: OrderRepository, OrderItemRepository

Summary:
"Entity distribution across modules:

Core Module (3 entities):
- User, Role, Permission
- Security/authentication domain

Order Module (3 entities):
- Order, OrderItem, OrderStatus
- Order management domain
- Has cross-module reference to User

Product Module (3 entities):
- Product, Category, Inventory
- Product catalog domain

Architecture notes:
- Clean module separation
- Core module provides shared User entity
- Order module depends on core module
- Product module is independent
- All modules have corresponding repositories"
```

---

## Example 6: Inheritance Hierarchy Analysis

**Scenario:** Understanding entity inheritance structure.

**Workflow:**

```
User: "We have different types of users. Show me the inheritance structure."

Step 1: Find all user-related entities
Tool: find_jpa_entities
{
  "entityPackage": "com.app.users",
  "projectPath": "/Users/dev/myapp"
}

Result: BaseUser, Customer, Admin, Vendor

Step 2: Analyze base entity
Tool: get_jpa_entity_by_name
{
  "entityName": "BaseUser",
  "projectPath": "/Users/dev/myapp"
}

Key findings:
{
  "name": "BaseUser",
  "mappedSuperclass": false,
  "inheritanceType": "SINGLE_TABLE",
  "discriminatorColumn": "user_type",
  "discriminatorType": "STRING",
  "attributes": [
    {"name": "id", "type": "Long", "isId": true},
    {"name": "username", "type": "String"},
    {"name": "email", "type": "String"}
  ]
}

Step 3: Analyze subclasses
Tool: get_jpa_entity_by_name
{
  "entityName": "Customer",
  "projectPath": "/Users/dev/myapp"
}

Result:
{
  "name": "Customer",
  "superclass": "BaseUser",
  "discriminatorValue": "CUSTOMER",
  "attributes": [
    {"name": "loyaltyPoints", "type": "Integer"},
    {"name": "membershipLevel", "type": "String"}
  ]
}

Tool: get_jpa_entity_by_name
{
  "entityName": "Admin",
  "projectPath": "/Users/dev/myapp"
}

Result:
{
  "name": "Admin",
  "superclass": "BaseUser",
  "discriminatorValue": "ADMIN",
  "attributes": [
    {"name": "accessLevel", "type": "Integer"},
    {"name": "department", "type": "String"}
  ]
}

Analysis:
"Entity Inheritance Structure:

BaseUser (Parent - SINGLE_TABLE strategy)
├── Table: base_user
├── Discriminator column: user_type (STRING)
├── Common attributes: id, username, email
│
├── Customer (discriminator: 'CUSTOMER')
│   └── Specific: loyaltyPoints, membershipLevel
│
├── Admin (discriminator: 'ADMIN')
│   └── Specific: accessLevel, department
│
└── Vendor (discriminator: 'VENDOR')
    └── Specific: [need to analyze]

SINGLE_TABLE strategy means:
- All entities stored in one table (base_user)
- user_type column distinguishes entity types
- All subclass columns nullable in database
- Good query performance (no joins)
- Can have unused columns for each type

Queries:
- 'FROM BaseUser' returns all users
- 'FROM Customer' returns only customers
- WHERE user_type = 'CUSTOMER' auto-added by JPA"
```

---

## Example 7: Composite Key Investigation

**Scenario:** Understanding entities with composite primary keys.

**Workflow:**

```
User: "How is the UserRole entity structured? It seems to use a composite key."

Step 1: Analyze the entity
Tool: get_jpa_entity_by_name
{
  "entityName": "UserRole",
  "projectPath": "/Users/dev/myapp"
}

Result:
{
  "name": "UserRole",
  "tableName": "user_roles",
  "compositeId": true,
  "attributes": [
    {
      "name": "userId",
      "type": "Long",
      "isId": true,
      "column": "user_id"
    },
    {
      "name": "roleId",
      "type": "Long",
      "isId": true,
      "column": "role_id"
    },
    {
      "name": "assignedDate",
      "type": "LocalDateTime"
    }
  ]
}

Step 2: Check related entities
Tool: get_jpa_entity_by_name
{
  "entityName": "User",
  "projectPath": "/Users/dev/myapp"
}

Look for relationship to UserRole

Tool: get_jpa_entity_by_name
{
  "entityName": "Role",
  "projectPath": "/Users/dev/myapp"
}

Look for relationship to UserRole

Analysis:
"UserRole entity uses composite primary key:

Structure:
- Composite key: (userId, roleId)
- Join table pattern for Many-to-Many relationship
- Additional column: assignedDate (audit field)

Implementation approach:
- Two @Id annotations on userId and roleId
- Likely uses @IdClass or @EmbeddedId
- Table: user_roles
- Columns: user_id, role_id, assigned_date

Relationships:
- User entity: ManyToMany to Role through UserRole
- Role entity: ManyToMany to User through UserRole

This is a Many-to-Many with extra columns pattern:
- Standard @ManyToMany can't have extra fields
- UserRole entity stores the relationship + metadata
- Provides better control over the join table"
```

---

## Example 8: Repository Coverage Audit

**Scenario:** Ensure all entities have repositories.

**Workflow:**

```
User: "Do all our entities have repositories?"

Step 1: Get all entities
Tool: find_jpa_entities
{
  "projectPath": "/Users/dev/myapp"
}

Result:
- User
- Order
- OrderItem
- Product
- Category
- Payment
- Address

Step 2: Get all repositories
Tool: find_spring_data_repositories
{
  "projectPath": "/Users/dev/myapp"
}

Result:
- UserRepository (entity: User)
- OrderRepository (entity: Order)
- ProductRepository (entity: Product)
- CategoryRepository (entity: Category)

Step 3: Analysis
Entities with repositories:
✓ User → UserRepository
✓ Order → OrderRepository
✓ Product → ProductRepository
✓ Category → CategoryRepository

Missing repositories:
✗ OrderItem (no repository)
✗ Payment (no repository)
✗ Address (no repository)

Step 4: Check if missing repositories are intentional
Tool: get_jpa_entity_by_name
{
  "entityName": "OrderItem",
  "projectPath": "/Users/dev/myapp"
}

Check relationships - if OrderItem is always accessed through Order:
{
  "name": "order",
  "type": "Order",
  "relationshipProperties": {
    "relationship": "ManyToOne",
    "joinColumn": "order_id"
  }
}

In Order entity:
{
  "name": "items",
  "type": "List<OrderItem>",
  "relationshipProperties": {
    "relationship": "OneToMany",
    "mappedBy": "order",
    "cascade": "ALL",
    "orphanRemoval": true
  }
}

Analysis:
"Repository Coverage Audit Results:

Entities WITH repositories (4/7):
✓ User → UserRepository
✓ Order → OrderRepository
✓ Product → ProductRepository
✓ Category → CategoryRepository

Entities WITHOUT repositories (3/7):
✗ OrderItem - Likely intentional
  - Always accessed through Order.items
  - CascadeType.ALL handles persistence
  - No need for independent access

✗ Payment - May need repository
  - Should payments be queried independently?
  - Recommend creating PaymentRepository if needed

✗ Address - Check usage pattern
  - Is it @Embedded or separate entity?
  - If separate entity with independent access, needs repository

Recommendations:
1. OrderItem: No repository needed (managed through Order)
2. Payment: Create PaymentRepository if queried independently
3. Address: Analyze if it's embedded or needs repository"
```

---

## Common Patterns Summary

1. **Domain Discovery**: find_jpa_entities → get_jpa_entity_by_name (for each)
2. **Relationship Analysis**: get_jpa_entity_by_name (both sides)
3. **Repository Audit**: find_jpa_entities + find_spring_data_repositories (compare)
4. **Legacy Integration**: reverse_engineering (for each table) → verify
5. **Debug Issues**: get_jpa_entity_by_name (analyze problematic entity)
6. **Module Exploration**: find_jpa_entities (by module) → analyze cross-module refs
