# JPA Exploration — Best Practices

---

## Core Rules

| Rule | Why |
|---|---|
| Always call `find_jpa_entities` before creating any entity | Prevents duplicates, reveals package conventions |
| Always call `get_jpa_entity_by_name` before modifying any entity | Gets the FQN needed for modification tools; reveals current state |
| Always call `find_spring_data_repositories` before creating any repository | Prevents duplicates |
| Never read `@Entity` files with `get_file_text_by_path` to understand entity structure | Raw file reading is slower and error-prone; use the structured tools |
| Never search for `@Entity` with text/regex search | `find_jpa_entities` is faster, IDE-indexed, and returns parsed data |
| Always use FQN from tool output — never guess it | FQN differs by project; guessing leads to `entityFqn` errors |

---

## When to Use Which Tool

| Situation | Tool |
|---|---|
| "Do any entities exist? What packages do they use?" | `find_jpa_entities` |
| "Does a User entity exist?" | `find_jpa_entities` or `get_jpa_entity_by_name("User")` |
| "What fields does User have? What are its relationships?" | `get_jpa_entity_by_name("User")` |
| "Does a UserRepository exist?" | `find_spring_data_repositories(entityName: "User")` |
| "Show me all repositories" | `find_spring_data_repositories` (no filter) |
| "Create an entity from the `orders` table" | `reverse_engineering_jpa_entity_by_name("orders")` |

---

## Reading Entity Output

Key fields to check in `get_jpa_entity_by_name` output:

| Field | What to look for |
|---|---|
| `packageName` | Use this as `entityPackage` when creating related entities |
| `attributes[].relationshipProperties.fetch` | `LAZY` = risk of `LazyInitializationException` outside `@Transactional` |
| `attributes[].relationshipProperties.mappedBy` | Present = this is the **inverse** side (no FK column in DB) |
| `attributes[].idGenerationProperties.generatedStrategy` | Match this in new entities for consistency |
| `inheritanceType` | `SINGLE_TABLE`, `JOINED`, or `TABLE_PER_CLASS` — affects table structure |
| `compositeId` | `true` = entity has composite primary key |

---

## Anti-Patterns

### ❌ Reading entity files to understand structure
```
# WRONG
get_file_text_by_path("src/main/java/com/example/domain/User.java")
# You'll have to parse annotations manually and can miss relationships

# CORRECT
get_jpa_entity_by_name(entityName: "User")
# Returns structured data: attributes, relationships, fetch types, cascade, inheritance
```

### ❌ Searching for @Entity with grep
```
# WRONG
search_in_files_by_text(searchText: "@Entity")
# Returns raw file lines — no structure, no relationship data

# CORRECT
find_jpa_entities()
# Returns parsed entity objects with all attributes and relationships
```

### ❌ Assuming FQN from simple name
```
# WRONG — assuming User is in com.example.domain
create_or_update_entity_attribute(entityFqn: "com.example.domain.User", ...)

# CORRECT — retrieve the actual FQN
get_jpa_entity_by_name(entityName: "User")
→ packageName: "com.example.model"  ← might be different!
→ FQN: "com.example.model.User"
```

---

## Debugging Relationship Issues

When debugging `LazyInitializationException` or wrong relationship behavior:

```
1. get_jpa_entity_by_name("OwningEntity")
   → Check: fetch = LAZY or EAGER?
   → Check: cascade = what types?
   → Check: mappedBy present? (if yes, this is NOT the owning side)

2. get_jpa_entity_by_name("InverseEntity")
   → Confirm: which side has @JoinColumn (= owning side)
   → Confirm: mappedBy value matches field name on owning side

3. Common fixes:
   → LazyInitializationException → use @Transactional on service method
   → Wrong FK column → check joinColumn value on owning side
   → Cascade not working → cascade must be on owning side or explicitly on inverse
```

---

## Exploration Before Implementation Checklist

Before calling any implementation tool:
- [ ] `find_jpa_entities` — know what entities exist and their packages
- [ ] `get_jpa_entity_by_name` — know exact structure of any entity you will modify
- [ ] `find_spring_data_repositories` — know what repositories exist
- [ ] For new entities: note package naming pattern from existing entities
- [ ] For relationships: check both entities' current relationship fields
