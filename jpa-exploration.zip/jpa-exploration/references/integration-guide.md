# Integration Guide - JPA Exploration to Implementation

How to transition from exploration to implementation and integrate with other workflows.

## Overview

The exploration skill is the **first step** in the JPA development workflow:

```
1. EXPLORATION (this skill)
   ↓
2. PLANNING
   ↓
3. IMPLEMENTATION (jpa-implementation skill)
   ↓
4. VERIFICATION (back to exploration)
   ↓
5. TESTING
```

---

## Workflow Integration Patterns

### Pattern 1: New Entity Creation Workflow

**Phase 1: Exploration**
```
User: "I need to create a Product entity with categories"

Step 1: Check if entity exists
Tool: find_jpa_entities
{
  "projectPath": "/path"
}
Result: Product entity doesn't exist

Step 2: Check if Category entity exists
Tool: find_jpa_entities
{
  "projectPath": "/path"
}
Result: Category entity exists!

Step 3: Analyze Category entity
Tool: get_jpa_entity_by_name
{
  "entityName": "Category",
  "projectPath": "/path"
}

Results show:
- id: Long (IDENTITY)
- name: String
- description: String
- No products collection yet

Step 4: Check repository patterns
Tool: find_spring_data_repositories
{
  "projectPath": "/path"
}

Results show:
- CategoryRepository exists
- Naming pattern: {Entity}Repository
- Extends: JpaRepository
```

**Phase 2: Planning**
```
Based on exploration:

1. Create Product entity with:
   - id: Long (IDENTITY - match pattern)
   - name: String
   - price: BigDecimal
   - category: Category (ManyToOne)

2. Update Category entity:
   - Add products: Set<Product> (OneToMany, mappedBy="category")

3. Create ProductRepository:
   - Follow naming: ProductRepository
   - Extend JpaRepository<Product, Long>
```

**Phase 3: Implementation**
```
Now use jpa-implementation skill:

1. create_jpa_entity(
     entityName: "Product",
     attributes: [...]
   )

2. create_or_update_entity_attribute(
     entityFqn: "com.example.Category",
     name: "products",
     ...relationshipProperties
   )

3. create_spring_data_repository(
     repositoryClassName: "ProductRepository",
     entityName: "Product"
   )
```

**Phase 4: Verification (Exploration Again)**
```
Tool: get_jpa_entity_by_name("Product", projectPath)
→ Verify Product was created correctly

Tool: get_jpa_entity_by_name("Category", projectPath)
→ Verify products collection was added

Tool: find_spring_data_repositories(entityName="Product", projectPath)
→ Verify ProductRepository exists
```

---

### Pattern 2: Relationship Modification Workflow

**Phase 1: Exploration**
```
User: "I need to add a one-to-many relationship between User and Order"

Step 1: Analyze User entity
Tool: get_jpa_entity_by_name
{
  "entityName": "User",
  "projectPath": "/path"
}

Current state:
- Has id, username, email
- No orders relationship

Step 2: Analyze Order entity
Tool: get_jpa_entity_by_name
{
  "entityName": "Order",
  "projectPath": "/path"
}

Current state:
- Has id, orderDate, totalAmount
- No user relationship

Step 3: Understand project patterns
Check other relationships:

Tool: find_jpa_entities
{
  "projectPath": "/path"
}

Then check entities with relationships to see patterns used
```

**Phase 2: Planning**
```
Based on exploration, plan:

1. Add to User entity:
   - orders: List<Order>
   - OneToMany, mappedBy="user"
   - LAZY fetch (follow pattern)
   - Cascade: NONE (don't delete orders when deleting user)

2. Add to Order entity:
   - user: User
   - ManyToOne
   - joinColumn: "user_id"
   - LAZY fetch
   - nullable: false
```

**Phase 3: Implementation**
```
Use jpa-implementation skill:

1. create_or_update_entity_attribute(
     entityFqn: "com.example.User",
     name: "orders",
     type: "List<Order>",
     relationshipProperties: {
       relationship: "OneToMany",
       mappedBy: "user",
       fetch: "LAZY"
     }
   )

2. create_or_update_entity_attribute(
     entityFqn: "com.example.Order",
     name: "user",
     type: "User",
     relationshipProperties: {
       relationship: "ManyToOne",
       joinColumn: "user_id",
       fetch: "LAZY"
     },
     columnProperties: {
       nullable: false
     }
   )
```

**Phase 4: Verification**
```
Tool: get_jpa_entity_by_name("User", projectPath)
→ Verify orders collection exists

Tool: get_jpa_entity_by_name("Order", projectPath)
→ Verify user relationship exists
→ Check mappedBy vs joinColumn correctly set
```

---

### Pattern 3: Legacy Database Integration Workflow

**Phase 1: Exploration (Reverse Engineering)**
```
User: "We need to integrate with legacy tables: customers, orders, products"

Step 1: Reverse engineer each table
Tool: reverse_engineering_jpa_entity_by_name
{
  "entityTableName": "customers",
  "projectPath": "/path"
}

Tool: reverse_engineering_jpa_entity_by_name
{
  "entityTableName": "orders",
  "projectPath": "/path"
}

Tool: reverse_engineering_jpa_entity_by_name
{
  "entityTableName": "products",
  "projectPath": "/path"
}

Step 2: Verify generated entities
Tool: find_jpa_entities
{
  "projectPath": "/path"
}

Result: Customer, Order, Product entities created

Step 3: Analyze generated structure
Tool: get_jpa_entity_by_name("Order", projectPath)

Generated attributes:
- order_id: Long → needs ID generation
- customer_id: Long → should be @ManyToOne to Customer
- product_id: Long → should be @ManyToOne to Product
- order_date: Date
- quantity: Integer
```

**Phase 2: Planning**
```
Need to:
1. Identify foreign keys → relationships
   - customer_id → @ManyToOne to Customer
   - product_id → @ManyToOne to Product

2. Add inverse relationships
   - Customer.orders: OneToMany to Order
   - Product.orders: OneToMany to Order

3. Fix naming conventions
   - order_id → id
   - customer_id → customer (relationship)

4. Add generation strategies to IDs

5. Create repositories for all
```

**Phase 3: Implementation**
```
Use jpa-implementation skill:

1. Fix Order entity:
   - Update customer_id to be @ManyToOne relationship
   - Update product_id to be @ManyToOne relationship
   - Configure ID generation

2. Update Customer entity:
   - Add orders: List<Order> with OneToMany

3. Update Product entity:
   - Add orders: List<Order> with OneToMany

4. Create repositories:
   - CustomerRepository
   - OrderRepository
   - ProductRepository
```

**Phase 4: Verification**
```
Tool: get_jpa_entity_by_name("Order", projectPath)
→ Verify relationships instead of primitive fields

Tool: get_jpa_entity_by_name("Customer", projectPath)
→ Verify orders collection added

Tool: find_spring_data_repositories(projectPath)
→ Verify all repositories created
```

---

### Pattern 4: Performance Optimization Workflow

**Phase 1: Exploration (Problem Identification)**
```
User: "Application is slow when loading users. Can you investigate?"

Step 1: Analyze User entity
Tool: get_jpa_entity_by_name
{
  "entityName": "User",
  "projectPath": "/path"
}

Findings:
{
  "name": "orders",
  "relationshipProperties": {
    "relationship": "OneToMany",
    "fetch": "EAGER"  ← Problem!
  }
}

{
  "name": "roles",
  "relationshipProperties": {
    "relationship": "ManyToMany",
    "fetch": "EAGER"  ← Another problem!
  }
}

{
  "name": "profile",
  "relationshipProperties": {
    "relationship": "OneToOne",
    "fetch": "EAGER"  ← Might be OK
  }
}

Step 2: Check related entities
Tool: get_jpa_entity_by_name("Order", projectPath)

Check if Order has more EAGER relationships:
{
  "name": "items",
  "relationshipProperties": {
    "fetch": "EAGER"  ← Cascading EAGER problem!
  }
}

Problem identified: Loading User causes:
- All orders (EAGER)
- All roles (EAGER)
- Profile (EAGER)
- And each order loads all items (EAGER)
= Massive data loading!
```

**Phase 2: Planning**
```
Optimization plan:

1. Change User.orders to LAZY
   - Load orders only when needed
   - Use JOIN FETCH in queries when needed

2. Change User.roles to LAZY
   - ManyToMany collections should be LAZY
   - Use EntityGraph for selective loading

3. Keep User.profile EAGER
   - OneToOne usually loaded together
   - Small data size

4. Change Order.items to LAZY
   - Stop cascading EAGER loading
```

**Phase 3: Implementation**
```
Use jpa-implementation skill:

1. Update User.orders fetch type
2. Update User.roles fetch type
3. Update Order.items fetch type

(Modify relationship properties using create_or_update_entity_attribute)
```

**Phase 4: Verification**
```
Tool: get_jpa_entity_by_name("User", projectPath)
→ Verify fetch types changed

Tool: get_jpa_entity_by_name("Order", projectPath)
→ Verify Order.items is now LAZY

Performance testing:
- Test application
- Verify only necessary data loaded
- Add JOIN FETCH queries where needed
```

---

## Handoff Points

### From Exploration to Implementation

**Exploration Provides:**
- Existing entity structure
- Current relationships
- Naming conventions
- Package organization
- Repository patterns
- Database mapping conventions

**Implementation Needs:**
- Entity names and packages
- Attribute specifications
- Relationship configurations
- Repository requirements

**Handoff Checklist:**
- [ ] Verified entity doesn't exist (if creating new)
- [ ] Analyzed related entities
- [ ] Understood project conventions
- [ ] Identified repository patterns
- [ ] Checked package structure
- [ ] Ready to implement

---

### From Implementation back to Exploration

**After Implementation, Use Exploration to:**

1. **Verify Creation**
   ```
   Tool: find_jpa_entities
   → Confirm entity appears in list
   ```

2. **Verify Structure**
   ```
   Tool: get_jpa_entity_by_name
   → Check all attributes correct
   → Verify relationships configured
   ```

3. **Verify Repository**
   ```
   Tool: find_spring_data_repositories
   → Confirm repository created
   ```

4. **Check Integration**
   ```
   Tool: get_jpa_entity_by_name (related entities)
   → Verify bidirectional relationships
   ```

---

## Integration with Testing

After exploration and implementation, testing workflow:

```
1. Unit Tests:
   - Test entity methods
   - Test relationship mappings
   - Test equals/hashCode

2. Repository Tests:
   - Test CRUD operations
   - Test custom queries
   - Test relationship loading

3. Integration Tests:
   - Test with actual database
   - Verify schema generation
   - Test relationship persistence

4. Performance Tests:
   - Test N+1 query issues
   - Verify LAZY loading
   - Check query performance
```

If issues found in testing, return to exploration:
```
Tool: get_jpa_entity_by_name
→ Re-analyze entity configuration
→ Check fetch strategies
→ Verify relationship mappings
```

---

## Integration with Documentation

Use exploration results for documentation:

```
1. Generate Entity Documentation:
   find_jpa_entities
   → List all entities

   For each entity:
     get_jpa_entity_by_name
     → Document structure

2. Generate Relationship Diagrams:
   Analyze relationships
   → Create ERD

3. Generate Repository Documentation:
   find_spring_data_repositories
   → Document data access layer

4. Update README:
   Include domain model overview
```

---

## Common Integration Scenarios

### Scenario 1: Feature Development
```
1. Explore (understand existing)
2. Plan (design changes)
3. Implement (make changes)
4. Verify (exploration again)
5. Test (run tests)
6. Document (update docs)
```

### Scenario 2: Bug Fix
```
1. Explore (understand current state)
2. Identify problem (in exploration results)
3. Plan fix
4. Implement fix
5. Verify (exploration)
6. Test fix
```

### Scenario 3: Refactoring
```
1. Explore (document current state)
2. Plan refactoring
3. Implement changes
4. Verify each step (exploration)
5. Test thoroughly
6. Document changes
```

### Scenario 4: Code Review
```
1. Explore (get overview)
2. Analyze relationships
3. Check conventions
4. Identify issues
5. Suggest improvements
6. Verify after changes
```

---

## Best Practices for Integration

1. **Always Explore First**
   - Don't implement blind
   - Understand existing structure
   - Follow project conventions

2. **Verify After Implementation**
   - Always check your work
   - Use exploration tools to verify
   - Confirm relationships bidirectional

3. **Document Your Journey**
   - Keep notes of exploration findings
   - Document design decisions
   - Link exploration results to implementation

4. **Iterate When Needed**
   - Explore → Implement → Verify → Repeat
   - Refine based on verification results

5. **Use Both Skills Together**
   - Exploration for understanding
   - Implementation for changes
   - Back to exploration for verification

---

## Transition Templates

### Template: From Exploration to Implementation

```
After exploring, I found:
- [Existing related entities]
- [Current relationships]
- [Project conventions]

Based on this, I'll implement:
- [What to create]
- [What to modify]
- [What relationships to add]

Using these tools:
- [List implementation tools needed]

With these parameters:
- [Specific parameters based on exploration]
```

### Template: From Implementation to Verification

```
Implemented:
- [What was created/modified]

Now verifying:
- Tool: get_jpa_entity_by_name
  → Check [specific aspects]

- Tool: find_spring_data_repositories
  → Confirm [repository aspects]

Expected results:
- [What should be present]
- [What relationships should exist]
- [What configuration should be set]
```

---

## Quick Reference

**Before Creating Entity:**
→ Use jpa-exploration

**Before Modifying Entity:**
→ Use jpa-exploration

**After Any Implementation:**
→ Use jpa-exploration to verify

**When Debugging:**
→ Use jpa-exploration to understand

**For Performance Issues:**
→ Use jpa-exploration to analyze fetch strategies

**For Architecture Review:**
→ Use jpa-exploration for complete audit
