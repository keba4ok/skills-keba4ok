# Troubleshooting Guide - JPA Exploration

Common issues when exploring JPA entities and how to resolve them.

## Tool Execution Issues

### Issue 1: "Entity not found"

**Symptom:**
```
get_jpa_entity_by_name returns empty result or error
```

**Possible Causes:**
1. Entity name typo
2. Entity doesn't exist
3. Wrong project path
4. Entity not in expected module

**Resolution Steps:**

**Step 1:** Verify entity exists
```
Tool: find_jpa_entities
{
  "projectPath": "/path/to/project"
}

Check if entity is in the list
```

**Step 2:** Check exact name
```
Entity might be:
- "User" vs "UserEntity"
- In different package
- In different module
```

**Step 3:** Try fully qualified name
```
Tool: get_jpa_entity_by_name
{
  "entityName": "com.example.domain.User",
  "projectPath": "/path/to/project"
}
```

**Step 4:** Verify project path
```
Check current working directory:
- pwd command
- Ensure projectPath points to project root
```

---

### Issue 2: "Multiple entities found"

**Symptom:**
```
Tool asks which entity you meant:
- com.example.domain.User
- com.example.admin.User
```

**Resolution:**
Use fully qualified name:
```
Tool: get_jpa_entity_by_name
{
  "entityName": "com.example.domain.User",
  "projectPath": "/path/to/project"
}
```

**Prevention:**
- Always use fully qualified names in large projects
- Check package structure first with find_jpa_entities

---

### Issue 3: "No entities found in project"

**Symptom:**
```
find_jpa_entities returns empty array
```

**Possible Causes:**
1. Wrong project path
2. No @Entity annotations in project
3. Entities not compiled yet
4. Wrong module specified

**Resolution Steps:**

**Step 1:** Verify project structure
```
Check if this is a Spring Boot project:
- Look for @Entity annotations
- Check src/main/java/*/entity or domain packages
```

**Step 2:** Check project path
```
Ensure projectPath points to project root:
- Should contain pom.xml or build.gradle
- Should have src/ directory
```

**Step 3:** Try without filters
```
Tool: find_jpa_entities
{
  "projectPath": "/path/to/project"
  // No entityPackage or moduleName filters
}
```

**Step 4:** Verify multi-module setup
```
If multi-module project:

Tool: find_jpa_entities
{
  "moduleName": "specific-module",
  "projectPath": "/path/to/project"
}
```

---

### Issue 4: "Repository not found for entity"

**Symptom:**
```
find_spring_data_repositories returns no repository for known entity
```

**Possible Causes:**
1. Repository doesn't exist yet
2. Repository uses non-standard naming
3. Repository in different module
4. Custom base repository interface

**Resolution Steps:**

**Step 1:** Confirm entity exists
```
Tool: get_jpa_entity_by_name
{
  "entityName": "User",
  "projectPath": "/path"
}
```

**Step 2:** Search without entity filter
```
Tool: find_spring_data_repositories
{
  "projectPath": "/path"
}

Look for repository manually in results
```

**Step 3:** Check custom naming
```
Repository might be named:
- UserRepo (not UserRepository)
- UserDataRepository
- UserDAO
- CustomUserRepository
```

**Step 4:** Verify repository exists
```
If no repository found, you need to create one:
- Use jpa-implementation skill
- create_spring_data_repository tool
```

---

## Analysis Issues

### Issue 5: Understanding Lazy Loading Errors

**Symptom:**
```
LazyInitializationException in application
Need to understand entity configuration
```

**Investigation Steps:**

**Step 1:** Get entity with relationship
```
Tool: get_jpa_entity_by_name
{
  "entityName": "User",
  "projectPath": "/path"
}
```

**Step 2:** Check relationship configuration
```json
Look for:
{
  "name": "orders",
  "relationshipProperties": {
    "relationship": "OneToMany",
    "fetch": "LAZY",  ← This is the key
    "mappedBy": "user"
  }
}
```

**Step 3:** Check both sides
```
Tool: get_jpa_entity_by_name
{
  "entityName": "Order",  // Related entity
  "projectPath": "/path"
}

Check the other side of relationship:
{
  "name": "user",
  "relationshipProperties": {
    "relationship": "ManyToOne",
    "fetch": "LAZY",
    "joinColumn": "user_id"
  }
}
```

**Understanding:**
- LAZY = data loaded only when accessed
- Exception occurs when accessing outside transaction
- Need @Transactional or JOIN FETCH query

**Solutions:**
1. Use @Transactional on service method
2. Use JOIN FETCH in query
3. Use EntityGraph
4. Change to EAGER (not recommended for collections)

---

### Issue 6: Determining Owning Side of Relationship

**Symptom:**
```
Confused about which side owns the relationship
Need to know where to add relationship
```

**Investigation:**

**Step 1:** Get both entities
```
Tool: get_jpa_entity_by_name("User", projectPath)
Tool: get_jpa_entity_by_name("Order", projectPath)
```

**Step 2:** Look for these indicators

**In User entity:**
```json
{
  "name": "orders",
  "relationshipProperties": {
    "relationship": "OneToMany",
    "mappedBy": "user"  ← mappedBy = INVERSE side
  }
}
```

**In Order entity:**
```json
{
  "name": "user",
  "relationshipProperties": {
    "relationship": "ManyToOne",
    "joinColumn": "user_id"  ← joinColumn = OWNING side
  }
}
```

**Rules:**
- Has `mappedBy` → Inverse side (doesn't own)
- Has `joinColumn` → Owning side (owns the FK)
- ManyToOne side usually owns relationship
- OneToMany side usually has `mappedBy`

---

### Issue 7: Understanding Inheritance Strategy

**Symptom:**
```
Not clear how inheritance is implemented
Multiple user types but unclear table structure
```

**Investigation:**

**Step 1:** Get parent entity
```
Tool: get_jpa_entity_by_name
{
  "entityName": "BaseUser",
  "projectPath": "/path"
}
```

**Step 2:** Check inheritance fields
```json
{
  "inheritanceType": "SINGLE_TABLE",  ← Strategy
  "discriminatorColumn": "user_type", ← Column name
  "discriminatorType": "STRING",      ← Column type
  "mappedSuperclass": false
}
```

**Interpretation:**

**SINGLE_TABLE:**
- All entities in one table
- Discriminator column identifies type
- Fast queries (no joins)
- Wasted space (nullable columns)

**JOINED:**
- Each entity has own table
- Parent table + child tables
- Normalized structure
- Slower queries (requires joins)

**TABLE_PER_CLASS:**
- Separate table per concrete class
- No shared table
- No discriminator
- Union queries

**Step 3:** Check subclasses
```
Tool: get_jpa_entity_by_name("Customer", projectPath)

Look for:
{
  "superclass": "BaseUser",
  "discriminatorValue": "CUSTOMER"
}
```

---

### Issue 8: Composite Key Confusion

**Symptom:**
```
Entity has multiple @Id fields
Not clear how to reference it
```

**Investigation:**

**Step 1:** Get entity
```
Tool: get_jpa_entity_by_name
{
  "entityName": "UserRole",
  "projectPath": "/path"
}
```

**Step 2:** Check composite key indicator
```json
{
  "compositeId": true,
  "attributes": [
    {"name": "userId", "isId": true},
    {"name": "roleId", "isId": true}
  ]
}
```

**Implementation Approaches:**

**@IdClass:**
```java
// Multiple @Id fields in entity
// Separate ID class with same fields
```

**@EmbeddedId:**
```java
// Single @EmbeddedId field
// Embeddable class contains key fields
```

**Check for Embedded:**
```json
{
  "name": "id",
  "embeddedProperties": {
    "embedded": true
  }
}
```

If embedded property exists → Using @EmbeddedId
If multiple isId: true → Using @IdClass

---

## Reverse Engineering Issues

### Issue 9: Reverse Engineering Returns Incomplete Data

**Symptom:**
```
reverse_engineering_jpa_entity_by_name returns basic fields
Missing relationships or complex types
```

**Understanding:**
Reverse engineering provides raw table structure:
- Column names → attribute names
- Column types → Java types
- Primary keys identified

**But doesn't include:**
- Relationships (@OneToMany, etc.)
- Business logic
- Validation rules
- Computed fields

**Next Steps:**

**Step 1:** Verify generated structure
```
Tool: get_jpa_entity_by_name
{
  "entityName": "User",
  "projectPath": "/path"
}
```

**Step 2:** Identify foreign keys
```
Look for fields like:
- customer_id → Should be @ManyToOne to Customer
- order_id → Should be @ManyToOne to Order
```

**Step 3:** Add relationships manually
```
Use jpa-implementation skill:
- create_or_update_entity_attribute
- Add relationshipProperties
```

---

### Issue 10: Table Name Not Found

**Symptom:**
```
reverse_engineering_jpa_entity_by_name can't find table
```

**Resolution:**

**Step 1:** Verify table name
```
Check exact table name in database:
- Case sensitivity matters
- Use exact name including underscores
```

**Step 2:** Check database connection
```
Verify application.properties:
- spring.datasource.url
- spring.datasource.username
- spring.datasource.password
```

**Step 3:** Use correct schema
```
If table in specific schema:
"entityTableName": "schema_name.table_name"
```

---

## Multi-Module Issues

### Issue 11: Can't Find Entities in Multi-Module Project

**Symptom:**
```
find_jpa_entities returns partial results
Missing entities from other modules
```

**Resolution:**

**Step 1:** List modules
```
Check project structure:
- Look for multiple pom.xml files
- Identify module names
```

**Step 2:** Search by module
```
For each module:

Tool: find_jpa_entities
{
  "moduleName": "core-module",
  "projectPath": "/path"
}

Tool: find_jpa_entities
{
  "moduleName": "order-module",
  "projectPath": "/path"
}
```

**Step 3:** Search without module filter
```
Tool: find_jpa_entities
{
  "projectPath": "/path"
  // No moduleName - searches all
}
```

---

### Issue 12: Cross-Module Relationship Not Clear

**Symptom:**
```
Entity in one module references entity in another
Relationship structure unclear
```

**Investigation:**

**Step 1:** Get entity from first module
```
Tool: get_jpa_entity_by_name
{
  "entityName": "Order",
  "projectPath": "/path"
}
```

**Step 2:** Check relationship type
```json
{
  "name": "customer",
  "type": "com.example.core.Customer",  ← Different package/module
  "relationshipProperties": {
    "relationship": "ManyToOne"
  }
}
```

**Step 3:** Get referenced entity
```
Tool: get_jpa_entity_by_name
{
  "entityName": "com.example.core.Customer",
  "projectPath": "/path"
}
```

**Step 4:** Check module dependencies
```
Verify in pom.xml or build.gradle:
- order-module depends on core-module
- Proper dependency declaration
```

---

## Performance Analysis Issues

### Issue 13: Too Many EAGER Relationships

**Symptom:**
```
Application slow, loading too much data
Cartesian product in queries
```

**Investigation:**

**Step 1:** Audit entity fetch strategies
```
Tool: find_jpa_entities
{
  "projectPath": "/path"
}
```

**Step 2:** Check each entity
```
For each entity:

Tool: get_jpa_entity_by_name
{
  "entityName": "User",
  "projectPath": "/path"
}

Look for:
{
  "relationshipProperties": {
    "fetch": "EAGER"  ← Multiple EAGER = problem
  }
}
```

**Step 3:** Identify issues
```
Problems:
✗ Multiple EAGER OneToMany relationships
✗ EAGER ManyToMany relationships
✗ Cascading EAGER (User → Order → OrderItem all EAGER)

Solutions:
✓ Change to LAZY
✓ Use EntityGraph for selective loading
✓ Use JOIN FETCH in queries when needed
```

---

## Resolution Checklist

When encountering issues:

- [ ] Verify projectPath is correct
- [ ] Check entity name spelling
- [ ] Try with fully qualified name
- [ ] Confirm entity has @Entity annotation
- [ ] Check module name if multi-module
- [ ] Verify project is compiled
- [ ] Look at both sides of relationships
- [ ] Check for custom naming conventions
- [ ] Verify database connection (for reverse engineering)
- [ ] Review Spring Boot configuration

---

## Getting Help

If issues persist:

1. **Gather Information:**
   ```
   - Project structure (single/multi-module)
   - Spring Boot version
   - Entity package structure
   - Exact error message
   ```

2. **Try Simplest Case:**
   ```
   find_jpa_entities(projectPath)
   → Does this work?
   ```

3. **Narrow Down:**
   ```
   - Try one entity
   - Try one package
   - Try one module
   ```

4. **Check Assumptions:**
   ```
   - Is this really a JPA entity?
   - Does it have @Entity annotation?
   - Is it in the right directory?
   ```
