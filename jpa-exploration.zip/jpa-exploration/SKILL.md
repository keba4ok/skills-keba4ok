---
name: jpa-exploration
description: >
  Discovery and analysis tools for JPA entities, Spring Data repositories, and database
  structure in Spring Boot projects. Use this skill when the user wants to: discover or
  explore existing JPA entities; analyze entity structure, attributes, or relationships;
  check for existing Spring Data repositories; reverse-engineer entities from database
  tables; understand the domain model; audit the JPA setup; or debug relationship issues
  (LazyInitializationException, fetch strategies, cascade). Triggers on: show entities,
  find entities, what entities exist, analyze entity, find repositories, domain model,
  reverse engineer from database, entity attributes, entity relationships.
---

# JPA & Spring Data Exploration

Discovery and analysis tools for JPA entities, Spring Data repositories, and database structure in Spring Boot projects.

---

## CRITICAL: MANDATORY TOOL USAGE POLICY

**YOU MUST USE MCP TOOLS FOR ALL JPA EXPLORATION TASKS. THIS IS NON-NEGOTIABLE.**

- **NEVER** read entity files manually with `get_file_text_by_path` to understand entity structure — use `mcp__jetbrains__find_jpa_entities` or `mcp__jetbrains__get_jpa_entity_by_name`
- **NEVER** search for `@Entity` annotations with text/regex search — use `mcp__jetbrains__find_jpa_entities`
- **NEVER** look for repository interfaces by reading files — use `mcp__jetbrains__find_spring_data_repositories`
- **NEVER** guess entity structure or attributes from partial knowledge — always call `mcp__jetbrains__get_jpa_entity_by_name` to get the full picture
- **NEVER** create entities or repositories without first calling discovery tools to check for duplicates
- **ALWAYS** call `mcp__jetbrains__find_jpa_entities` before creating any new entity
- **ALWAYS** call `mcp__jetbrains__get_jpa_entity_by_name` before modifying any entity
- **ALWAYS** call `mcp__jetbrains__find_spring_data_repositories` before creating any repository
- **ALWAYS** prefer these structured tools over raw file reading — they return parsed, structured data that is faster to work with and impossible to misinterpret

---

## When to Use This Skill

Use this skill when users want to:
- Discover or explore existing JPA entities in the project
- Find what entities already exist before creating new ones
- Analyze entity structure, attributes, or relationships
- Understand the domain model or entity hierarchies
- Check for existing Spring Data repositories
- Find repositories for specific entities
- Reverse engineer entities from existing database tables
- Understand database schema and table mappings
- Analyze entity relationships (@OneToMany, @ManyToOne, @ManyToMany, @OneToOne)
- Debug relationship issues or LazyInitializationException
- Understand inheritance strategies or composite keys
- Audit the current JPA/Spring Data setup

## Trigger Keywords

- "show me all entities"
- "what entities exist"
- "find entities in [package]"
- "list JPA entities"
- "show me the User entity"
- "analyze the Order entity"
- "what attributes does [entity] have"
- "find repositories"
- "does a [Entity]Repository exist"
- "reverse engineer from database"
- "create entity from table"
- "what's in the domain model"
- "explore the data model"

## Available Tools

This skill provides access to these MCP tools. **They must be called via the `mcp__jetbrains__` prefix.**

| Tool | Purpose | When to Call |
|---|---|---|
| `mcp__jetbrains__find_jpa_entities` | Discover all entities in project | Before creating any entity; for domain model overview |
| `mcp__jetbrains__get_jpa_entity_by_name` | Get full entity details (attributes, relationships, inheritance) | Before modifying any entity; when debugging relationship issues |
| `mcp__jetbrains__find_spring_data_repositories` | Find existing repositories | Before creating any repository |
| `mcp__jetbrains__reverse_engineering_jpa_entity_by_name` | Generate entity structure from a database table | For legacy/database-first integration |

## Reference Files

- **references/tool-reference.md** - Detailed documentation for each tool
- **references/examples.md** - Practical usage examples
- **references/patterns.md** - Common exploration workflows
- **references/troubleshooting.md** - Solutions to common issues
- **references/integration-guide.md** - How to integrate with implementation workflow
- **references/best-practices.md** - Rules, anti-patterns, exploration checklist, key output fields to check

## Next Steps

After exploring, you typically want to:
- Create new entities using **jpa-implementation** skill
- Modify existing entities using **jpa-implementation** skill
- Generate repositories using **jpa-implementation** skill
