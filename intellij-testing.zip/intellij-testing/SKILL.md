---
name: intellij-testing
description: >
  Build, run, test, and validate Spring Boot projects using IntelliJ IDEA MCP tools.
  Use this skill whenever you need to build, run, test, or validate a Spring Boot project:
  build the project and check for compilation errors; run a full rebuild; execute test
  suites (unit tests, integration tests); run the Spring Boot application; check files for
  errors using IDE inspections; validate that code changes compile; run Maven/Gradle
  commands; diagnose build or test failures; or verify the application starts correctly.
  Triggers on: build project, compile, run tests, run application, check compilation,
  full rebuild, run [ConfigName], check file problems, IntelliJ inspections, mvn test,
  gradlew test.
---

# IntelliJ Testing Skill

Build, run, test, and validate Spring Boot projects using IntelliJ IDEA MCP tools.

---

## CRITICAL: MANDATORY TOOL USAGE POLICY

**YOU MUST USE MCP TOOLS FOR ALL BUILD AND TEST TASKS. THIS IS NON-NEGOTIABLE.**

- **NEVER** check compilation by reading files manually — use `mcp__jetbrains__build_project`
- **NEVER** run tests or apps with raw `mvn`/`gradle` shell commands when a run config exists — use `mcp__jetbrains__execute_run_configuration`
- **NEVER** guess what run configurations exist — call `mcp__jetbrains__get_run_configurations` first
- **NEVER** analyze code quality by reading files line-by-line — use `mcp__jetbrains__get_file_problems`
- **ALWAYS** call `mcp__jetbrains__build_project` after any code change before running tests
- **ALWAYS** call `mcp__jetbrains__get_run_configurations` before `execute_run_configuration` — names are case-sensitive
- **ALWAYS** prefer `mcp__jetbrains__execute_run_configuration` over raw terminal commands when a config exists
- **ALWAYS** use `truncateMode: "START"` with `maxLinesCount: 300` for test runs — results appear at the end of output

---

## When to Use This Skill

- Build the project and check for compilation errors
- Run a full project rebuild to clear stale artifacts
- Execute test suites (unit, integration, specific test classes)
- Run the Spring Boot application via run configurations
- Check specific files for errors using IDE inspections
- Run Maven or Gradle commands not covered by run configurations
- Diagnose build or test failures

## Trigger Keywords

"build the project", "compile", "run tests", "run application", "check compilation", "full rebuild", "run [ConfigName]", "check file problems", "IntelliJ inspections", "mvn test", "gradlew test", "does it compile", "are there errors"

---

## Available Tools

All tools use the `mcp__jetbrains__` prefix.

| Tool | Purpose | When |
|---|---|---|
| `build_project` | Build project, return compilation errors | After EVERY code change |
| `get_run_configurations` | List all run configs (name, command, env) | Always before execute_run_configuration |
| `execute_run_configuration` | Run a named configuration (tests/app) | After get_run_configurations |
| `get_file_problems` | IDE inspections on a specific file | After creating/editing files |
| `execute_terminal_command` | Run shell commands in IDE terminal | When no run config exists (fallback) |

---

## Workflow

```
After any code change:
  build_project
    → errors: []    → proceed to tests
    → errors: [...]  → fix using intellij-implementation → rebuild

Run tests:
  get_run_configurations → find exact config name
    → execute_run_configuration(configurationName: "...", truncateMode: "START", maxLinesCount: 300)
      → exitCode: 0  → success
      → exitCode: ≠ 0 → read output for failure details → fix → re-run

Check file:
  get_file_problems(filePath: "src/main/java/...", errorsOnly: false)

Fallback (no run config):
  execute_terminal_command(command: "mvn test -Dtest=ClassName", truncateMode: "START")
```

---

## Reference Files

- **references/tool-reference.md** — All 5 tools: parameters, return values, workflows, error tables
- **references/examples.md** — 6 testing scenarios (validate after change, run tests, file inspection, diagnose failures)
- **references/patterns.md** — Build/test sequences, timeout reference, output truncation tips
- **references/best-practices.md** — Rules, anti-patterns, result interpretation, JPA-specific inspection issues

## Integration with Other Skills

**Before testing**, use **intellij-implementation** to make code changes.

**After test failures**, use **intellij-exploration** to read the failing test and production code, then **intellij-implementation** to fix it.
