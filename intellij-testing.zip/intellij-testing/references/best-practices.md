# IntelliJ Testing — Best Practices

---

## Core Rules

| Rule | Why |
|---|---|
| Always call `build_project` before running tests | Tests fail on compilation errors; clean build state is required |
| Always call `get_run_configurations` before `execute_run_configuration` | Config names are case-sensitive; guessing causes "not found" errors |
| Prefer `execute_run_configuration` over `execute_terminal_command` | IDE-integrated, captures output correctly, respects environment setup |
| Use `truncateMode: "START"` when running tests | Test summaries and failures appear at the END of Maven/Gradle output |
| If unexpected build errors: retry with `rebuild: true` | Stale artifacts cause false positives; full rebuild clears them |
| Use `get_file_problems` after creating entities | IDE inspections detect JPA-specific issues that compilation misses |

---

## Anti-Patterns

### ❌ Running tests without building first
```
# WRONG
execute_run_configuration("All Tests")
# Tests may fail due to compilation errors unrelated to the actual test logic

# CORRECT
build_project() → check errors: [] → execute_run_configuration("All Tests")
```

### ❌ Guessing run configuration names
```
# WRONG
execute_run_configuration(configurationName: "all tests")
# Will fail if actual name is "All Tests" (case-sensitive!)

# CORRECT
get_run_configurations() → identify exact name → execute_run_configuration(...)
```

### ❌ Not using truncateMode for test output
```
# WRONG
execute_run_configuration("All Tests")
# If output is large, the test summary at the end gets cut off

# CORRECT
execute_run_configuration("All Tests", truncateMode: "START", maxLinesCount: 300)
# Shows the end of output where test results appear
```

### ❌ Immediately concluding there's a real error without full rebuild
```
# WRONG
build_project()
→ "cannot find symbol" error
→ immediately try to fix code

# CORRECT
build_project(rebuild: true)
# Stale artifacts are common after entity changes — full rebuild may resolve it
```

---

## Tool Selection Guide

```
Validate compilation?
  └── build_project               (always first, always after changes)

Need full clean rebuild?
  └── build_project(rebuild: true)

Run tests or app?
  ├── First: get_run_configurations   → find exact config name
  └── Then:  execute_run_configuration(configurationName: "...")

Check file for IDE warnings/errors?
  └── get_file_problems(filePath: "...")

Maven/Gradle command not in run configs?
  └── execute_terminal_command(command: "mvn ...")
```

---

## Interpreting Results

### Build results

| Output | Meaning | Action |
|---|---|---|
| `errors: []` | Compilation success | Proceed to tests |
| `errors: [{severity: "ERROR", ...}]` | Compilation failure | Fix using intellij-implementation |
| `timedOut: true` | Build took too long | Retry with higher `timeout` |

### Test results

| Output | Meaning | Action |
|---|---|---|
| `exitCode: 0` + "Failures: 0" | All tests pass | Success |
| `exitCode: ≠ 0` + "Failures: N" | Tests failed | Read failure details, fix, re-run |
| `exitCode: null` | Timed out | Increase `timeout`, or check if app hangs |
| `UnsatisfiedDependencyException` | Missing `@MockBean` or Spring bean | Add mock or fix test context |
| `LazyInitializationException` | LAZY relation in test without `@Transactional` | Add `@Transactional` to test method |

### File problems results

| Severity | Meaning | Action |
|---|---|---|
| `ERROR` | Must fix — code won't compile or runtime breaks | Fix immediately |
| `WARNING` | Should investigate | Review, may indicate bug |
| `WEAK_WARNING` | Optional improvement | Low priority |

---

## JPA-Specific Issues from `get_file_problems`

| Problem | What it means |
|---|---|
| "Entity class must have a no-argument constructor" | Add `@NoArgsConstructor` (Lombok) or write no-arg constructor |
| "Missing @Id annotation" | Entity must have exactly one `@Id` field |
| "Incorrect owning/inverse relationship" | Check `mappedBy` placement and `@JoinColumn` usage |
| "Field injection is not recommended" | Use constructor injection instead of `@Autowired` field |
| "@Transactional on private method" | Spring AOP cannot intercept private methods — make it package/public |

---

## When to Use `execute_terminal_command`

Use as fallback when no run configuration exists:

```
mvn test -Dtest=ClassName                    → specific test class
mvn test -Dtest=ClassName#methodName         → specific test method
mvn verify -P integration-test               → integration test profile
mvn test jacoco:report                       → run tests with coverage
mvn dependency:resolve                       → resolve dependencies
./gradlew test --tests "com.example.*"       → Gradle filtered tests
```

Always use `truncateMode: "START"` and appropriate `timeout` for test commands.
