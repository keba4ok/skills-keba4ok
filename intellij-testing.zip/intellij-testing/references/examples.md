# IntelliJ Testing — Examples

End-to-end examples for common build, test, and validation tasks.

---

## Example 1: Validate Code Changes After Implementation

**Task:** After adding a new field to an entity, make sure everything compiles.

```
1. Build the project
   build_project(projectPath: "/path/to/project")

   Success:
   → {"errors": [], "timedOut": false}

   Failure:
   → {"errors": [{"severity": "ERROR", "description": "cannot find symbol: class Category",
                   "filePath": "src/.../Product.java", "line": 15}]}

2. If errors: fix using intellij-implementation tools, then rebuild
   build_project(projectPath: "/path/to/project")

3. If unexpected errors persist: full rebuild
   build_project(rebuild: true, projectPath: "/path/to/project")
```

---

## Example 2: Run Unit Tests

**Task:** Run all unit tests after making code changes.

```
1. Build first (ensure clean compilation)
   build_project(projectPath: "/path/to/project")
   → errors: [] (must pass before running tests)

2. Find available test configurations
   get_run_configurations(projectPath: "/path/to/project")
   → configurations: [
       {name: "All Tests", commandLine: "mvn test"},
       {name: "UserServiceTest", commandLine: "mvn test -Dtest=UserServiceTest"}
     ]

3. Run tests
   execute_run_configuration(
     configurationName: "All Tests",
     timeout: 120000,
     truncateMode: "START",
     maxLinesCount: 300,
     projectPath: "/path/to/project"
   )

   Success:
   → exitCode: 0, output contains "Tests run: 42, Failures: 0, Errors: 0"

   Failure:
   → exitCode: 1, output contains "Tests run: 42, Failures: 2, Errors: 0"
   → Read failure details (class + method + assertion message)
```

---

## Example 3: Run a Specific Test Class

**Task:** Run only `OrderServiceTest` to verify a specific fix.

```
1. Find configurations
   get_run_configurations(projectPath: "/path/to/project")

2a. If specific config exists:
    execute_run_configuration(
      configurationName: "OrderServiceTest",
      timeout: 60000,
      projectPath: "/path/to/project"
    )

2b. If no specific config:
    execute_terminal_command(
      command: "mvn test -Dtest=OrderServiceTest",
      timeout: 60000,
      truncateMode: "START",
      maxLinesCount: 200,
      projectPath: "/path/to/project"
    )
```

---

## Example 4: Check a File for IDE Inspection Issues

**Task:** After creating a new `Product` entity, check it for JPA annotation issues.

```
1. Check entity file for problems
   get_file_problems(
     filePath: "src/main/java/com/example/domain/Product.java",
     errorsOnly: false,
     timeout: 20000,
     projectPath: "/path/to/project"
   )

   Example output:
   → errors: [
       {severity: "ERROR", description: "Entity class must have a no-argument constructor",
        line: 8, lineContent: "public class Product {"}
     ]

2. Fix the issue using intellij-implementation
   → create_or_update_entity_attribute or replace_text_in_file

3. Build to confirm fix
   build_project(projectPath: "/path/to/project")
```

---

## Example 5: Diagnose Build Failure

**Task:** Build is failing after recent entity changes.

```
1. Run build
   build_project(projectPath: "/path/to/project")
   → errors: [{severity: "ERROR", description: "incompatible types: String cannot be converted to Long",
               filePath: "src/.../UserService.java", line: 34, lineContent: "Long id = getUserId();"}]

2. Navigate to the error location (intellij-exploration)
   get_file_text_by_path(
     pathInProject: "src/main/java/com/example/service/UserService.java",
     projectPath: "/path/to/project"
   )
   → Read lines around line 34

3. Fix the issue (intellij-implementation)
   replace_text_in_file(
     pathInProject: "src/main/java/com/example/service/UserService.java",
     oldText: "Long id = getUserId();",
     newText: "String id = getUserId();",
     projectPath: "/path/to/project"
   )

4. Build again to confirm
   build_project(projectPath: "/path/to/project")
   → errors: []
```

---

## Example 6: Run Integration Tests with Maven Profile

**Task:** Run integration tests defined in a separate Maven profile.

```
1. Check if integration test run config exists
   get_run_configurations(projectPath: "/path/to/project")
   → No integration test config found

2. Fall back to terminal command
   execute_terminal_command(
     command: "mvn verify -P integration-test",
     timeout: 300000,
     truncateMode: "START",
     maxLinesCount: 300,
     projectPath: "/path/to/project"
   )

   Success: command_exit_code: 0, "BUILD SUCCESS"
   Failure: command_exit_code: 1, look for "FAILED" or "ERROR" in output
```
