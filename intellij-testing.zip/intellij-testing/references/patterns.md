# IntelliJ Testing — Patterns

Common build, test, and validation workflows for quick reference.

---

## Standard Build-Test Sequence

```
After any code change:

build_project()
  ├── errors: []    → proceed to tests
  └── errors: [...]  → fix using intellij-implementation → rebuild

get_run_configurations()   (find exact config names)

execute_run_configuration(configurationName: "...")
  ├── exitCode: 0   → success
  └── exitCode: ≠ 0 → read output for failure details → fix → re-run

get_file_problems(filePath: "...")   (optional: check specific files)
```

---

## Build Patterns

### Incremental build (after code change)
```
build_project(projectPath: "...")
```

### Full rebuild (when seeing unexpected errors or stale artifacts)
```
build_project(rebuild: true, projectPath: "...")
```

### Build → check compilation only
```
build_project()
  → {"errors": []}   → compilation success
  → {"errors": [...]} → compilation errors to fix
```

---

## Test Execution Patterns

### Run all tests
```
get_run_configurations()                         → find "All Tests" or similar
  → execute_run_configuration(
       configurationName: "All Tests",
       timeout: 300000,
       truncateMode: "START",
       maxLinesCount: 300
     )
```

### Run specific test class
```
get_run_configurations()                         → check if specific config exists

If exists:
  execute_run_configuration(configurationName: "ClassName")

If not:
  execute_terminal_command(command: "mvn test -Dtest=ClassName")
```

### Run specific test method
```
execute_terminal_command(
  command: "mvn test -Dtest=UserServiceTest#testFindById",
  timeout: 60000,
  truncateMode: "START"
)
```

### Run integration tests
```
execute_terminal_command(
  command: "mvn verify -P integration-test",
  timeout: 300000,
  truncateMode: "START",
  maxLinesCount: 300
)
```

### Run with coverage
```
execute_terminal_command(
  command: "mvn test jacoco:report",
  timeout: 180000,
  truncateMode: "START"
)
```

---

## Inspection Patterns

### Check new entity for JPA issues
```
get_file_problems(
  filePath: "src/main/java/com/example/domain/EntityName.java",
  errorsOnly: false,
  timeout: 20000
)
```

### Check service for injection issues
```
get_file_problems(
  filePath: "src/main/java/com/example/service/ServiceName.java",
  errorsOnly: true,
  timeout: 20000
)
```

---

## Failure Diagnosis Patterns

### Build failure diagnosis
```
build_project()
  → read errors[]: {filePath, line, column, description}
    → get_file_text_by_path(filePath) (in intellij-exploration)
      → fix with intellij-implementation
        → build_project() again
```

### Test failure diagnosis
```
execute_run_configuration("All Tests", truncateMode: "START")
  → find failing test: "expected:<X> but was:<Y>" or stack trace
    → find test class: find_files_by_name_keyword("TestClassName")
      → get_file_text_by_path(testFile)
        → find production code: find_files_by_name_keyword("ProductionClass")
          → fix with intellij-implementation
            → build_project() → execute_run_configuration() again
```

---

## Timeout Reference

| Scenario | Timeout |
|---|---|
| Unit tests | 60 000 ms (1 min) |
| Integration tests | 180 000 ms (3 min) |
| Full test suite | 300 000 ms (5 min) |
| App startup | 120 000 ms (2 min) |
| Maven build | 120 000 ms |
| File inspection | 15 000–30 000 ms |

---

## Output Truncation Tips

```
truncateMode: "START" + maxLinesCount: 300
→ See the END of output (test summary, BUILD SUCCESS/FAILURE) — USE THIS FOR TESTS

truncateMode: "END" + maxLinesCount: 300
→ See the BEGINNING of output (compilation start, module list)

No truncation (omit both)
→ See full output up to default limit — use for small/fast builds only
```
