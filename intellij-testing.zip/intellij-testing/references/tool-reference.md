# Tool Reference - IntelliJ Testing

Comprehensive documentation for all 5 build, run, and validation tools.

---

## build_project

### Purpose
Triggers IntelliJ's build system, waits for completion, and returns structured compilation errors. The central validation tool — **MANDATORY after every code change**.

### When to Use
- **After ANY code modification** — entity changes, file edits, refactoring
- After modifying build files (`pom.xml`, `build.gradle`, `settings.gradle`)
- **Before running tests** — never run tests against uncompiled code
- When an unexpected runtime error appears and you suspect a compilation issue
- As the mandatory final step in any implementation workflow
- When switching between branches or after pulling changes

### Parameters

#### rebuild (optional)
- **Type:** Boolean
- **Default:** false (incremental build)
- **Description:** Force full clean rebuild vs incremental compilation
- **When to set `true`:**
  - After structural changes (adding new modules, changing dependencies)
  - When incremental build reports unexpected errors that seem wrong
  - After updating `pom.xml` or `build.gradle` significantly
  - When classes seem to exist but build says they don't (stale artifact)
  - First build after opening a project

#### timeout (optional)
- **Type:** Integer (milliseconds)
- **Default:** Tool decides
- **Guidance by project size:**
  - Small project (< 50 classes): 30000ms
  - Medium project (50–200 classes): 60000ms
  - Large project (200+ classes): 120000–300000ms
  - Full rebuild always: add 50% more time

#### projectPath (recommended)
- **Type:** String
- **Description:** Project root absolute path
- **Important:** ALWAYS pass if known — reduces ambiguity

### Return Value

**Clean build (no errors):**
```json
{
  "errors": [],
  "timedOut": false
}
```

**Build with compilation errors:**
```json
{
  "errors": [
    {
      "severity": "ERROR",
      "description": "cannot find symbol: class Order",
      "filePath": "src/main/java/com/example/domain/User.java",
      "line": 15,
      "column": 12,
      "lineContent": "    private List<Order> orders;"
    },
    {
      "severity": "WARNING",
      "description": "Unchecked or unsafe operations",
      "filePath": "src/main/java/com/example/service/UserService.java",
      "line": 28,
      "column": 32,
      "lineContent": "        List items = repository.findAll();"
    }
  ],
  "timedOut": false
}
```

**Timed out build:**
```json
{
  "errors": [],
  "timedOut": true
}
```
→ If timed out: retry with a higher `timeout` value or `rebuild: true`

### Error Diagnosis Guide

| Error Description | Root Cause | Resolution |
|---|---|---|
| `cannot find symbol: class X` | Missing import, class doesn't exist, or wrong package | Add import statement; verify class name and package |
| `cannot find symbol: method X` | Wrong method name or parameters | Check method signature with `get_symbol_info` |
| `incompatible types: X cannot be converted to Y` | Type mismatch | Fix the return type or variable type |
| `package X does not exist` | Missing dependency or wrong import | Add dependency to pom.xml or fix import path |
| `duplicate class` | Two classes with identical FQN | Rename or delete one of them |
| `reached end of file while parsing` | Missing closing brace `}` | Fix the file structure |
| `annotation type not applicable` | Wrong annotation usage context | Check annotation's `@Target` |
| `@Entity: javax vs jakarta` | Mixed Spring Boot 2.x and 3.x imports | Align all JPA imports (javax for Boot 2, jakarta for Boot 3) |

### Usage Examples

**Example 1: Standard post-implementation build**
```
After create_jpa_entity or replace_text_in_file completes:
{ "projectPath": "/path/to/project" }
→ errors: [] → proceed to testing
→ errors: [...] → fix each error, then build again
```

**Example 2: Full rebuild after dependency change**
```
After updating pom.xml with new dependency:
{ "rebuild": true, "projectPath": "/path/to/project", "timeout": 180000 }
```

**Example 3: Build before running tests**
```
Always sequence: build_project → execute_run_configuration("Tests")
Never run execute_run_configuration without successful build first.
```

**Example 4: Diagnosing unexpected errors**
```
When: build shows errors that don't make sense after correct code changes
Action: { "rebuild": true, "projectPath": "/path/to/project" }
Reason: Stale .class files from previous failed builds can cause false errors
```

---

## get_run_configurations

### Purpose
Returns all available run configurations with name, command, working directory, and environment — **always call before `execute_run_configuration`**.

### When to Use
- **Always call FIRST** before executing any run configuration
- Discovering what test suites exist (unit tests, integration tests, full suite)
- Finding the exact configuration name to pass to `execute_run_configuration`
- Understanding how the application and tests are configured to run
- Checking for custom environment variables in run configurations

### Parameters

#### projectPath (recommended)
- **Type:** String

### Return Value
```json
{
  "configurations": [
    {
      "name": "FeatureServiceApplication",
      "description": "Spring Boot application launcher",
      "commandLine": null,
      "workingDirectory": "/path/to/project",
      "environment": {
        "SPRING_PROFILES_ACTIVE": "dev"
      }
    },
    {
      "name": "All Tests",
      "description": "Run complete test suite",
      "commandLine": "mvn test",
      "workingDirectory": "/path/to/project",
      "environment": null
    },
    {
      "name": "UserServiceTest",
      "description": "Unit tests for UserService",
      "commandLine": null,
      "workingDirectory": null,
      "environment": null
    },
    {
      "name": "Integration Tests",
      "description": "Spring Boot integration tests",
      "commandLine": "mvn verify -P integration",
      "workingDirectory": "/path/to/project",
      "environment": { "SPRING_PROFILES_ACTIVE": "test" }
    }
  ]
}
```

### Usage Examples

**Example 1: Discover before executing**
```
Input: "Run the tests"
Step 1: get_run_configurations() → see available configurations
Step 2: Identify relevant config (e.g., "All Tests" or "Unit Tests")
Step 3: execute_run_configuration(configurationName: "All Tests")
```

**Example 2: Find application config**
```
Input: "Start the application"
Step 1: get_run_configurations()
Step 2: Find config named e.g. "FeatureServiceApplication" or "Run Application"
Step 3: execute_run_configuration(configurationName: "FeatureServiceApplication")
```

---

## execute_run_configuration

### Purpose
Executes a named run configuration (test suite, application launcher, build task) and waits for completion — **primary tool for running tests and applications**.

### When to Use
- Running unit tests
- Running integration tests
- Starting the Spring Boot application
- Running any defined build or run task
- **Always call `get_run_configurations` first** to find the exact configuration name
- **Prefer this over `execute_terminal_command`** when a configuration exists

### Parameters

#### configurationName (required)
- **Type:** String
- **Description:** Exact name of the run configuration (CASE-SENSITIVE)
- **Get this from:** `get_run_configurations` output — copy the `name` field exactly
- **Examples:** `"All Tests"`, `"UserServiceTest"`, `"FeatureServiceApplication"`

#### timeout (optional)
- **Type:** Integer (milliseconds)
- **Default:** Tool decides
- **Guidance by scenario:**

| Scenario | Suggested Timeout |
|---|---|
| Single unit test class | 60000 (1 min) |
| Small unit test suite | 120000 (2 min) |
| Full unit test suite | 300000 (5 min) |
| Integration tests | 300000–600000 (5–10 min) |
| Application startup | 120000 (2 min) |
| Full build + test | 600000 (10 min) |

#### maxLinesCount (optional)
- **Type:** Integer
- **Default:** Tool limit (usually 2000 lines)
- **Tip:** Use `500` for focused test output, omit for full output

#### truncateMode (optional)
- **Type:** Enum: `"START"` | `"MIDDLE"` | `"END"` | `"NONE"`
- **Guidance:**
  - `"START"` — see beginning of output (build start, test setup)
  - `"END"` — see end of output (final test count, error summary) — **most useful for tests**
  - `"NONE"` — full output (may be very large)
- **Recommended for tests:** `"START"` with `maxLinesCount: 300` to see the failure detail without the full output

#### projectPath (recommended)
- **Type:** String

### Return Value
```json
{
  "exitCode": 0,
  "timedOut": false,
  "output": "...\n[INFO] Tests run: 42, Failures: 0, Errors: 0, Skipped: 0\n[INFO] BUILD SUCCESS\n..."
}
```

**Exit codes:**
- `0` — success (all tests passed, app started)
- `1` — test failures or build errors
- `null` — process terminated unexpectedly or timed out

### Interpreting Test Output

**Maven Surefire output:**
```
Tests run: 15, Failures: 2, Errors: 0, Skipped: 1
→ Failures: 2 means assertions failed (expected vs actual mismatch)
→ Errors: 0 means no exceptions during test setup/teardown

Failing test details:
  UserServiceTest.testFindById:42 expected:<1> but was:<null>
  → Method: testFindById, Line: 42, Problem: got null instead of 1
```

**Spring Boot startup output:**
```
Started FeatureServiceApplication in 4.567 seconds → success
APPLICATION FAILED TO START → startup failure, check stack trace below
```

**Common failure patterns:**

| Output Pattern | Meaning |
|---|---|
| `AssertionError: expected:<X> but was:<Y>` | Test assertion failed |
| `NullPointerException` in test | Test data not properly set up |
| `UnsatisfiedDependencyException` | Spring context missing a bean — check @MockBean setup |
| `DataIntegrityViolationException` | Test data violates DB constraints |
| `LazyInitializationException` | LAZY relationship accessed outside transaction in test |
| `NoSuchBeanDefinitionException` | Missing @Service, @Repository, or @Component |
| `BUILD FAILURE` with `There are test failures` | Tests ran but some failed — check individual test names |
| `BUILD FAILURE` with `Compilation failure` | Code doesn't compile — run build_project first |

### Usage Examples

**Example 1: Run all unit tests**
```
Step 1: get_run_configurations() → find "All Tests" or "Unit Tests"
Step 2:
{
  "configurationName": "All Tests",
  "timeout": 300000,
  "truncateMode": "START",
  "maxLinesCount": 200,
  "projectPath": "/path/to/project"
}
```

**Example 2: Run specific test class**
```
Step 1: get_run_configurations() → find "UserServiceTest"
Step 2:
{
  "configurationName": "UserServiceTest",
  "timeout": 60000,
  "projectPath": "/path/to/project"
}
```

**Example 3: Start the application**
```
Step 1: get_run_configurations() → find application config
Step 2:
{
  "configurationName": "FeatureServiceApplication",
  "timeout": 120000,
  "truncateMode": "START",
  "maxLinesCount": 100,
  "projectPath": "/path/to/project"
}
Check output for: "Started ... in X.XX seconds"
```

---

## get_file_problems

### Purpose
Analyzes a specific file using IntelliJ's full inspection engine and returns all detected errors and warnings — IDE-level code analysis without opening the file.

### When to Use
- Checking a newly created entity for annotation errors
- Validating a service class after adding dependencies
- Finding code quality issues after an edit
- Checking for unused imports or variables
- Analyzing JPA mapping issues that build doesn't catch
- Checking for potential NullPointerExceptions or type issues
- **Always use instead of manually reviewing code for issues**

### Parameters

#### filePath (required)
- **Type:** String
- **Description:** Path relative to project root
- **Examples:**
  - `"src/main/java/com/example/domain/User.java"`
  - `"src/main/java/com/example/service/UserService.java"`
  - `"src/test/java/com/example/UserServiceTest.java"`

#### errorsOnly (optional)
- **Type:** Boolean
- **Default:** false (returns errors AND warnings)
- **When to set `true`:** Only care about critical issues, not style warnings

#### timeout (optional)
- **Type:** Integer (milliseconds)
- **Default:** Tool decides
- **Note:** Inspections can be slow for complex files; allow 15000–30000ms

#### projectPath (recommended)
- **Type:** String

### Return Value
```json
{
  "filePath": "src/main/java/com/example/domain/User.java",
  "errors": [
    {
      "severity": "ERROR",
      "description": "Entity class must have a public or protected no-argument constructor",
      "lineContent": "public class User {",
      "line": 12,
      "column": 1
    },
    {
      "severity": "WARNING",
      "description": "Field 'orders' may produce 'NullPointerException'",
      "lineContent": "    private List<Order> orders;",
      "line": 35,
      "column": 5
    }
  ],
  "timedOut": false
}
```

### Severity Levels

| Severity | Meaning | Action Required |
|---|---|---|
| `ERROR` | Critical issue — code may not compile or will fail at runtime | Must fix |
| `WARNING` | Potential issue — may cause bugs or bad practice | Should investigate |
| `WEAK_WARNING` | Style or minor issue | Optional |
| `INFO` | Informational | Optional |

### Common IntelliJ Inspection Issues

**JPA-specific errors:**
| Problem | Description | Fix |
|---|---|---|
| `Entity class must have a no-arg constructor` | JPA requirement | Add `@NoArgsConstructor` (Lombok) or explicit constructor |
| `@Entity annotation required` | Missing @Entity | Add @Entity to class |
| `@Id annotation required` | No primary key | Add @Id field |
| `Owning side of relationship` | Missing `mappedBy` or `joinColumn` | Check relationship configuration |
| `Circular @OneToOne` | Potential circular reference | Add `mappedBy` on one side |

**Spring-specific warnings:**
| Problem | Description | Fix |
|---|---|---|
| `Field injection is not recommended` | Using @Autowired on field | Use constructor injection |
| `Bean not found for @Autowired` | Missing bean definition | Add @Service/@Repository/@Component |
| `@Transactional on private method` | Spring AOP limitation | Make method public or package-private |

### Usage Examples

**Example 1: Check entity after creation**
```
Input: After creating User entity:
{
  "filePath": "src/main/java/com/example/domain/User.java",
  "projectPath": "/path/to/project"
}
→ Review errors for missing no-arg constructor, @Id issues, relationship configuration errors
```

**Example 2: Errors only for a service**
```
{
  "filePath": "src/main/java/com/example/service/OrderService.java",
  "errorsOnly": true,
  "projectPath": "/path/to/project"
}
→ Focus only on critical compilation and Spring errors
```

**Example 3: Check test file**
```
{
  "filePath": "src/test/java/com/example/UserServiceTest.java",
  "projectPath": "/path/to/project"
}
→ Check for test setup issues, missing @MockBean, assertion errors
```

---

## execute_terminal_command

### Purpose
Executes shell commands in the IDE's integrated terminal — use as a fallback for test/build commands not covered by `execute_run_configuration`.

### When to Use
- Running tests for a specific Maven module: `mvn test -pl module-name`
- Running tests with specific parameters: `mvn test -Dtest=UserTest#testMethod`
- Running Gradle tasks: `./gradlew test --tests "*.UserTest"`
- Generating test reports: `mvn jacoco:report`
- Running Spring Boot with a specific profile: `mvn spring-boot:run -Dspring-boot.run.profiles=test`
- **ALWAYS prefer `execute_run_configuration` when a matching config exists**

### Parameters

#### command (required)
- **Type:** String
- **Examples for testing:**
  - `"mvn test"` — run all Maven tests
  - `"mvn test -Dtest=UserServiceTest"` — specific test class
  - `"mvn test -Dtest=UserServiceTest#testFindById"` — specific test method
  - `"mvn verify"` — run including integration tests
  - `"./gradlew test"` — Gradle tests
  - `"./gradlew test --tests 'com.example.*'"` — filtered Gradle tests
  - `"mvn test jacoco:report"` — tests + coverage report

#### executeInShell (optional)
- **Type:** Boolean
- **Default:** false
- **When to use:** Commands using shell features like pipes or environment variables

#### reuseExistingTerminalWindow (optional)
- **Type:** Boolean
- **Default:** false
- **When to use:** Subsequent commands in the same terminal session

#### timeout (optional)
- **Type:** Integer (milliseconds)
- **Default:** 30000ms
- **Always increase for test runs:**
  - Unit tests: 120000ms
  - Integration tests: 300000ms
  - Full suite: 600000ms

#### maxLinesCount (optional)
- **Type:** Integer
- **Default:** 2000
- **Tip:** Test output can be very long; use `200`–`500` with `truncateMode: "START"` to see the summary

#### truncateMode (optional)
- **Type:** Enum: `"START"` | `"MIDDLE"` | `"END"` | `"NONE"`
- **Recommended for test runs:** `"START"` to see test counts and failure details (which appear at the end of Maven output)

#### projectPath (recommended)
- **Type:** String

### Return Value
```json
{
  "command_output": "[INFO] Tests run: 10, Failures: 0, Errors: 0, Skipped: 0\n[INFO] BUILD SUCCESS",
  "command_exit_code": 0,
  "is_timed_out": false
}
```

### Exit Code Reference

| Exit Code | Meaning |
|---|---|
| `0` | Success — all tests passed |
| `1` | Test failures or build errors |
| `2` | Usage error (wrong command syntax) |
| `null` | Process killed or timed out |

### Usage Examples

**Example 1: Run a specific test class (no matching run config)**
```
{
  "command": "mvn test -Dtest=UserServiceTest -pl service-module",
  "timeout": 120000,
  "truncateMode": "START",
  "maxLinesCount": 100,
  "projectPath": "/path/to/project"
}
```

**Example 2: Run a specific test method**
```
{
  "command": "mvn test -Dtest=UserServiceTest#testFindById",
  "timeout": 60000,
  "projectPath": "/path/to/project"
}
```

**Example 3: Run tests with coverage**
```
{
  "command": "mvn test jacoco:report",
  "timeout": 300000,
  "truncateMode": "START",
  "maxLinesCount": 200,
  "projectPath": "/path/to/project"
}
```

**Example 4: Run Spring Boot integration tests**
```
{
  "command": "mvn verify -P integration-tests",
  "timeout": 600000,
  "truncateMode": "START",
  "maxLinesCount": 300,
  "projectPath": "/path/to/project"
}
```

---

## Standard Testing Workflows

### Workflow 1: Validate After Code Change (Minimum)
```
1. build_project()
   → Must pass (exit with no errors) before proceeding
   → If errors: fix with intellij-implementation tools, then rebuild

2. execute_run_configuration("unit-test-config")
   → Call get_run_configurations first to find config name
   → Check exit code and output
```

### Workflow 2: Full Test Cycle
```
1. build_project()                           → compile
2. execute_run_configuration("All Tests")    → unit tests
3. execute_run_configuration("Integration")  → integration tests
4. execute_terminal_command("mvn jacoco:report")  → coverage (optional)
```

### Workflow 3: Debug a Specific Test Failure
```
1. execute_run_configuration("FailingTestClass")  → reproduce failure
2. Read output → identify failing test method and error
3. get_file_text_by_path("test/FailingTest.java")  → read test
4. get_file_text_by_path("main/ProductionCode.java")  → read production code
5. get_file_problems("main/ProductionCode.java")  → check for IDE issues
6. Fix with intellij-implementation tools
7. build_project()  → validate fix compiles
8. execute_run_configuration("FailingTestClass")  → verify fix
```

### Workflow 4: New Entity Validation
```
1. create_jpa_entity(...)                    → create entity
2. build_project()                           → compile check
3. get_file_problems("path/to/Entity.java")  → IDE inspection
4. create_spring_data_repository(...)        → create repository
5. build_project()                           → compile check
6. execute_run_configuration("All Tests")    → ensure nothing broken
```

---

## Tool Selection Guide

```
Validate code compiles?
  └── build_project (always first — mandatory after any change)

Need full clean rebuild?
  └── build_project(rebuild: true)

Discover available test/app configs?
  └── get_run_configurations → always call before execute_run_configuration

Run a defined test suite or application?
  └── execute_run_configuration(configurationName: "exact-name-from-get_run_configurations")

Check a specific file for warnings and errors?
  └── get_file_problems(filePath: "relative/path/to/file.java")

Run a Maven/Gradle command not in run configs?
  └── execute_terminal_command(command: "mvn test -Dtest=...", timeout: ...)
```

---

## Best Practices

1. **Always `build_project` before running tests** — catches compilation errors before test failures
2. **Always `get_run_configurations` before `execute_run_configuration`** — config names are case-sensitive
3. **On unexpected build errors, try `rebuild: true`** — eliminates stale artifact issues
4. **Use `truncateMode: "START"` with `maxLinesCount`** — test result summaries appear at the end of output
5. **Check `get_file_problems` after creating JPA entities** — catches annotation and mapping issues build misses
6. **Check `exitCode`, not just output text** — `exitCode: 0` means success regardless of verbose output
7. **Increase `timeout` for integration tests** — they involve database setup and can take minutes
