---
name: jpa-implementation
description: >
  Creation and modification tools for JPA entities and Spring Data repositories in Spring
  Boot projects. Use this skill when the user wants to: create new JPA entities; add,
  modify, or remove entity attributes or fields; create entity relationships (@OneToMany,
  @ManyToOne, @ManyToMany, @OneToOne); implement entity inheritance; add composite keys
  or embedded objects; create Spring Data JPA repositories; implement optimistic locking
  with @Version; add audit fields; configure indexes; or add cascade/fetch strategies.
  Triggers on: create entity, add field, add relationship, remove field, create repository,
  @Version, optimistic locking, inheritance, or any structural modification to entities.
---

# JPA & Spring Data Implementation

Creation and modification tools for JPA entities and Spring Data repositories in Spring Boot projects.

---

## CRITICAL: MANDATORY TOOL USAGE POLICY

**YOU MUST USE MCP TOOLS FOR ALL JPA IMPLEMENTATION TASKS. THIS IS NON-NEGOTIABLE.**

- **NEVER** write `@Entity` class files manually using `create_new_file` or text editing — use `mcp__jetbrains__create_jpa_entity`
- **NEVER** add or modify JPA entity fields by editing the Java file directly — use `mcp__jetbrains__create_or_update_entity_attribute`
- **NEVER** remove entity fields by editing the Java file directly — use `mcp__jetbrains__delete_entity_attribute`
- **NEVER** create a Spring Data repository interface manually — use `mcp__jetbrains__create_spring_data_repository`
- **NEVER** proceed without first exploring — always call `mcp__jetbrains__find_jpa_entities` and `mcp__jetbrains__get_jpa_entity_by_name` before any modification
- **NEVER** create an entity without verifying it doesn't already exist via `mcp__jetbrains__find_jpa_entities`
- **NEVER** create a repository without verifying it doesn't already exist via `mcp__jetbrains__find_spring_data_repositories`
- **ALWAYS** use the fully qualified entity name (`com.example.domain.User`) for `entityFqn` parameters — never the simple class name alone
- **ALWAYS** call `mcp__jetbrains__build_project` after every entity or repository operation to validate compilation

The MCP tools handle JPA annotation placement, relationship integrity, database mapping consistency, and IDE synchronization automatically. Manual editing bypasses all of these safeguards and introduces errors.

---

## When to Use This Skill

Use this skill when users want to:
- Create new JPA entities with @Entity annotation
- Add attributes or fields to existing entities
- Modify entity attributes or relationships
- Remove entity attributes or fields
- Create entity relationships (@OneToMany, @ManyToOne, @ManyToMany, @OneToOne)
- Implement entity inheritance hierarchies
- Add composite keys or embedded objects
- Create Spring Data JPA repositories
- Implement optimistic locking with @Version
- Add audit fields (createdAt, updatedAt)
- Configure indexes or named queries
- Add cascade operations or fetch strategies

## Trigger Keywords

- "create [entity name] entity"
- "add a [field name] field to [entity]"
- "add [attribute] attribute"
- "create a relationship between [entity1] and [entity2]"
- "add @OneToMany/@ManyToOne/@ManyToMany/@OneToOne"
- "remove [field] from [entity]"
- "delete [attribute]"
- "create repository for [entity]"
- "generate [Entity]Repository"
- "add composite key"
- "implement inheritance"
- "add optimistic locking"
- "add version field"

## Available Tools

This skill provides access to these MCP tools. **They must be called via the `mcp__jetbrains__` prefix.**

| Tool | Purpose | When to Call |
|---|---|---|
| `mcp__jetbrains__create_jpa_entity` | Create a complete JPA entity class | When a new entity is needed — NEVER manually write the file |
| `mcp__jetbrains__create_or_update_entity_attribute` | Add a new field or modify an existing one | When adding/modifying any entity attribute — NEVER edit the file directly |
| `mcp__jetbrains__delete_entity_attribute` | Remove a field from an entity | When removing any entity attribute — NEVER edit the file directly |
| `mcp__jetbrains__create_spring_data_repository` | Generate a Spring Data repository interface | When creating a repository — NEVER manually write the interface |

## Reference Files

- **references/tool-reference.md** - Detailed documentation for each tool
- **references/examples.md** - Complete implementation examples
- **references/patterns.md** - Common implementation patterns
- **references/attribute-configurations.md** - Reference for all attribute types
- **references/relationship-guide.md** - Complete guide for entity relationships
- **references/best-practices.md** - JPA and Spring Data best practices

## Prerequisites

Before using this skill:
1. **Explore first** using **jpa-exploration** skill
2. Understand existing entity structure
3. Check project conventions
4. Verify entity/repository doesn't already exist

## Next Steps

After implementation:
- Use **jpa-exploration** to verify changes
- Run tests to ensure functionality
- Update documentation
