# Best Practices - JPA & Spring Data

Comprehensive best practices for JPA entity and Spring Data repository implementation.

## Table of Contents

1. [Entity Design](#entity-design)
2. [Relationship Configuration](#relationship-configuration)
3. [Performance Optimization](#performance-optimization)
4. [Data Integrity](#data-integrity)
5. [Testing](#testing)
6. [Common Pitfalls](#common-pitfalls)

---

## Entity Design

### 1. Use Meaningful Names

**DO:**
```java
@Entity
public class Order { }  // Clear business domain name

@Entity
public class OrderItem { }
```

**DON'T:**
```java
@Entity
public class Ord { }  // Abbreviated

@Entity
public class OrderEntity { }  // Technical suffix
```

**Why:** Clear names improve code readability and express business concepts.

---

### 2. Singular Entity Names

**DO:**
```java
@Entity
public class User { }  // Singular

@Entity
@Table(name = "users")  // Table plural
public class Product { }
```

**DON'T:**
```java
@Entity
public class Users { }  // Plural entity name
```

**Why:** Entities represent single instances, tables represent collections.

---

### 3. Use Wrapper Types for Non-ID Columns

**DO:**
```java
private Long id;  // Wrapper (can be null)
private Integer age;  // Wrapper
private Boolean active;  // Wrapper
```

**DON'T:**
```java
private long id;  // Primitive (can't be null)
private int age;  // Primitive
private boolean active;  // Primitive
```

**Why:** Wrappers distinguish between "not set" (null) and "set to zero" (0).

---

### 4. Always Specify Column Properties

**DO:**
```json
{
  "name": "email",
  "type": "String",
  "columnProperties": {
    "unique": true,
    "nullable": false,
    "length": 100
  }
}
```

**DON'T:**
```json
{
  "name": "email",
  "type": "String"
  // Missing constraints
}
```

**Why:** Explicit constraints prevent data integrity issues.

---

### 5. Use Appropriate Data Types

| Java Type | Use For |
|-----------|---------|
| `Long` | IDs, large numbers |
| `Integer` | Counts, small numbers |
| `BigDecimal` | Money, precise decimals |
| `String` | Text |
| `LocalDateTime` | Timestamps |
| `LocalDate` | Dates only |
| `Boolean` | True/false |
| `Enum` | Fixed set of values |

**Money Example:**
```json
{
  "name": "price",
  "type": "BigDecimal",
  "columnProperties": {
    "precision": 19,
    "scale": 2,
    "nullable": false
  }
}
```

**Why:** `BigDecimal` prevents rounding errors in financial calculations.

---

### 6. Immutable ID Generation

**DO:**
```json
{
  "name": "id",
  "type": "Long",
  "isId": true,
  "idGenerationProperties": {
    "generatedStrategy": "IDENTITY"
  }
}
```

**Why:** Let database generate IDs, never set manually.

---

### 7. Audit Fields Pattern

**DO:**
```java
@MappedSuperclass
public abstract class AuditableEntity {
    @Column(nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column
    private LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
}
```

**Why:** Standardize audit tracking across all entities.

---

## Relationship Configuration

### 8. Always Configure Both Sides (Bidirectional)

**DO:**
```java
// User entity
@OneToMany(mappedBy = "user")
private List<Order> orders;

// Order entity
@ManyToOne
@JoinColumn(name = "user_id")
private User user;
```

**DON'T:**
```java
// Only one side configured
@OneToMany
private List<Order> orders;
// Order doesn't reference User
```

**Why:** Bidirectional relationships need both sides for proper ORM behavior.

---

### 9. Set Owning Side Correctly

**Rules:**
- **ManyToOne side is always owning side**
- **Side with @JoinColumn is owning**
- **Side with foreign key is owning**

**Example:**
```java
// Order (owning side) - has FK
@ManyToOne
@JoinColumn(name = "user_id")  ← Owning
private User user;

// User (inverse side) - no FK
@OneToMany(mappedBy = "user")  ← Inverse
private List<Order> orders;
```

---

### 10. Use LAZY Fetch for Collections

**DO:**
```json
{
  "name": "orders",
  "type": "List<Order>",
  "relationshipProperties": {
    "relationship": "OneToMany",
    "fetch": "LAZY"  ← Always LAZY for collections
  }
}
```

**DON'T:**
```json
{
  "relationshipProperties": {
    "fetch": "EAGER"  ← Never EAGER for collections
  }
}
```

**Why:** EAGER collections cause N+1 problems and load too much data.

---

### 11. Use Appropriate Cascade Types

| Scenario | Cascade Type |
|----------|--------------|
| Parent owns children completely | CASCADE.ALL + orphanRemoval |
| Save/update together, delete separately | CASCADE.PERSIST, MERGE |
| Independent entities | No cascade |
| Lookup data (Category, Status) | No cascade |

**Composition (Order → OrderItem):**
```json
{
  "relationshipProperties": {
    "cascade": "ALL",
    "orphanRemoval": true
  }
}
```

**Aggregation (Product → Category):**
```json
{
  "relationshipProperties": {
    // No cascade - independent entities
  }
}
```

---

### 12. Initialize Collections

**DO:**
```java
@OneToMany(mappedBy = "user")
private List<Order> orders = new ArrayList<>();  ← Initialize
```

**DON'T:**
```java
@OneToMany(mappedBy = "user")
private List<Order> orders;  // null
```

**Why:** Prevents NullPointerException when adding items.

---

### 13. Use Set for ManyToMany

**DO:**
```java
@ManyToMany
private Set<Role> roles = new HashSet<>();  ← Set prevents duplicates
```

**DON'T:**
```java
@ManyToMany
private List<Role> roles;  // List allows duplicates
```

**Why:** Sets naturally represent unique relationships.

---

### 14. Avoid Circular References in toString/equals/hashCode

**DON'T:**
```java
@Entity
public class User {
    @OneToMany(mappedBy = "user")
    private List<Order> orders;

    @Override
    public String toString() {
        return "User{orders=" + orders + "}";  ← Circular!
    }
}
```

**DO:**
```java
@Override
public String toString() {
    return "User{id=" + id + ", username=" + username + "}";
}
```

**Why:** Circular references cause StackOverflowError.

---

## Performance Optimization

### 15. Add Indexes on Foreign Keys

**DO:**
```json
{
  "indexes": [
    {
      "name": "idx_order_user_id",
      "columnList": ["user_id"],
      "unique": false
    }
  ]
}
```

**Why:** Foreign key columns are frequently used in joins and WHERE clauses.

---

### 16. Add Indexes on Frequent Query Columns

**DO:**
```json
{
  "indexes": [
    {
      "name": "idx_user_email",
      "columnList": ["email"],
      "unique": true
    },
    {
      "name": "idx_order_date",
      "columnList": ["order_date"],
      "unique": false
    }
  ]
}
```

**Why:** Indexes dramatically speed up queries on those columns.

---

### 17. Use Pagination for Large Result Sets

**DO:**
```java
public interface UserRepository extends JpaRepository<User, Long> {
    Page<User> findByActive(Boolean active, Pageable pageable);
}

// Usage
Pageable pageable = PageRequest.of(0, 20);  // Page 0, 20 items
Page<User> users = userRepository.findByActive(true, pageable);
```

**Why:** Prevents loading thousands of entities into memory.

---

### 18. Use Projections for Read-Only Data

**DO:**
```java
public interface UserSummary {
    String getUsername();
    String getEmail();
}

public interface UserRepository extends JpaRepository<User, Long> {
    List<UserSummary> findAllProjectedBy();
}
```

**Why:** Loads only needed fields, not entire entity.

---

### 19. Use JOIN FETCH for Eager Loading When Needed

**DO:**
```java
@Query("SELECT u FROM User u JOIN FETCH u.orders WHERE u.id = :id")
User findByIdWithOrders(@Param("id") Long id);
```

**Why:** Avoids N+1 problem when you know you need related data.

---

### 20. Avoid Multiple EAGER Relationships

**DON'T:**
```java
@Entity
public class User {
    @OneToMany(fetch = FetchType.EAGER)  ← Bad
    private List<Order> orders;

    @ManyToMany(fetch = FetchType.EAGER)  ← Bad
    private Set<Role> roles;

    @OneToOne(fetch = FetchType.EAGER)  ← Bad
    private Profile profile;
}
```

**Why:** Causes cartesian product - exponentially large result sets.

---

## Data Integrity

### 21. Use nullable=false for Required Fields

**DO:**
```json
{
  "name": "email",
  "columnProperties": {
    "nullable": false  ← Required
  }
}
```

**Why:** Database enforces NOT NULL constraint.

---

### 22. Use unique=true for Unique Fields

**DO:**
```json
{
  "name": "username",
  "columnProperties": {
    "unique": true
  }
}
```

**Why:** Database enforces uniqueness, prevents duplicates.

---

### 23. Use Optimistic Locking for Concurrent Updates

**DO:**
```json
{
  "name": "version",
  "type": "Long",
  "columnProperties": {
    "version": true
  }
}
```

**Why:** Prevents lost updates when multiple users edit same entity.

---

### 24. Set Appropriate String Lengths

**DO:**
```json
{
  "name": "username",
  "columnProperties": {
    "length": 50  ← Reasonable limit
  }
}
```

**DON'T:**
```json
{
  "name": "username",
  "columnProperties": {
    "length": 10000  ← Excessive
  }
}
```

**Why:** Appropriate lengths prevent abuse and optimize storage.

---

### 25. Use LOB for Large Text

**DO:**
```json
{
  "name": "content",
  "type": "String",
  "columnProperties": {
    "lob": true  ← For large text
  }
}
```

**When:** Text can be very long (articles, descriptions, etc.)

**Why:** Stores as CLOB/TEXT instead of VARCHAR.

---

## Testing

### 26. Test Repository Layer

**DO:**
```java
@DataJpaTest
@AutoConfigureTestDatabase(replace = Replace.NONE)
public class UserRepositoryTest {

    @Autowired
    private UserRepository userRepository;

    @Test
    public void testSaveUser() {
        User user = new User();
        user.setUsername("testuser");
        user.setEmail("test@example.com");

        User saved = userRepository.save(user);

        assertNotNull(saved.getId());
        assertEquals("testuser", saved.getUsername());
    }
}
```

---

### 27. Test Relationships

**DO:**
```java
@Test
public void testUserOrderRelationship() {
    User user = new User();
    user.setUsername("john");

    Order order = new Order();
    order.setUser(user);
    user.getOrders().add(order);

    userRepository.save(user);

    User found = userRepository.findById(user.getId()).get();
    assertEquals(1, found.getOrders().size());
}
```

---

### 28. Test Cascade Operations

**DO:**
```java
@Test
public void testCascadeDelete() {
    // Create user with order
    User user = createUserWithOrders();
    Long userId = user.getId();

    // Delete user
    userRepository.deleteById(userId);

    // Verify orders also deleted (if CASCADE.REMOVE)
    assertEquals(0, orderRepository.findByUserId(userId).size());
}
```

---

### 29. Test Optimistic Locking

**DO:**
```java
@Test(expected = OptimisticLockException.class)
public void testOptimisticLocking() {
    User user = userRepository.findById(1L).get();

    User user2 = userRepository.findById(1L).get();

    user.setEmail("email1@example.com");
    userRepository.save(user);

    user2.setEmail("email2@example.com");
    userRepository.save(user2);  // Should throw exception
}
```

---

## Common Pitfalls

### 30. Don't Use @JoinColumn and mappedBy Together

**WRONG:**
```java
@OneToMany(mappedBy = "user")
@JoinColumn(name = "user_id")  ← Wrong! Can't have both
private List<Order> orders;
```

**CORRECT:**
```java
@OneToMany(mappedBy = "user")  ← Only mappedBy
private List<Order> orders;
```

---

### 31. Don't Forget @Column on @Id

**WRONG:**
```java
@Id
private Long id;  // No generation strategy
```

**CORRECT:**
```java
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private Long id;
```

---

### 32. Don't Mix Entity Logic with UI/API

**WRONG:**
```java
@Entity
public class User {
    private String password;  // Plain text in DB

    public void setPassword(String password) {
        this.password = password;  // No hashing
    }
}
```

**CORRECT:**
```java
@Entity
public class User {
    private String passwordHash;  // Hashed

    // Business logic in service layer
}
```

---

### 33. Don't Ignore Database Constraints

**WRONG:**
```java
// No constraint, but assumption in code
private String status;  // Expecting only "ACTIVE" or "INACTIVE"
```

**CORRECT:**
```java
@Enumerated(EnumType.STRING)
@Column(length = 20, nullable = false)
private UserStatus status;  // Enum enforces valid values
```

---

### 34. Don't Use CascadeType.ALL Carelessly

**WRONG:**
```java
@ManyToOne(cascade = CascadeType.ALL)  ← Never on ManyToOne!
private Category category;
// Deleting Product would delete Category!
```

**CORRECT:**
```java
@ManyToOne  // No cascade
private Category category;
```

---

### 35. Don't Forget Transaction Management

**WRONG:**
```java
public void updateUser(Long id, String email) {
    User user = userRepository.findById(id).get();
    user.setEmail(email);
    // No save, not in transaction - changes lost
}
```

**CORRECT:**
```java
@Transactional
public void updateUser(Long id, String email) {
    User user = userRepository.findById(id).get();
    user.setEmail(email);
    // Changes flushed at end of transaction
}
```

---

## Checklist

### Entity Creation Checklist

- [ ] Entity name is singular and meaningful
- [ ] ID field with generation strategy
- [ ] All required fields have `nullable=false`
- [ ] String fields have appropriate lengths
- [ ] Unique fields have `unique=true`
- [ ] Money fields use `BigDecimal` with precision/scale
- [ ] Date fields use `LocalDateTime` or `LocalDate`
- [ ] Collections initialized in declaration
- [ ] No circular references in toString()

### Relationship Checklist

- [ ] Both sides configured for bidirectional
- [ ] Owning side has `@JoinColumn`
- [ ] Inverse side has `mappedBy`
- [ ] Collections use `LAZY` fetch
- [ ] Cascade type appropriate for relationship
- [ ] ManyToMany uses `Set` not `List`
- [ ] Required relationships have `nullable=false`
- [ ] Indexes added on foreign key columns

### Performance Checklist

- [ ] LAZY fetch for all collections
- [ ] Indexes on foreign keys
- [ ] Indexes on frequently queried columns
- [ ] No multiple EAGER relationships
- [ ] Pagination used for large result sets
- [ ] Projections considered for read-only queries
- [ ] JOIN FETCH used when relationships needed

### Data Integrity Checklist

- [ ] Required fields have `nullable=false`
- [ ] Unique fields have `unique=true`
- [ ] Optimistic locking added where needed
- [ ] String lengths appropriate
- [ ] Large text uses `lob=true`
- [ ] Enums used for fixed values
- [ ] Constraints match business rules

### Testing Checklist

- [ ] Repository tests written
- [ ] Relationship tests written
- [ ] Cascade behavior tested
- [ ] Optimistic locking tested
- [ ] Integration tests with real database
- [ ] Edge cases covered

---

## Summary

**Golden Rules:**

1. **Explore first** - Always understand existing structure
2. **LAZY by default** - Especially for collections
3. **Cascade carefully** - Understand implications
4. **Index frequently** - Foreign keys and query columns
5. **Test thoroughly** - Relationships and cascades
6. **Follow conventions** - Naming, package structure
7. **Verify changes** - Use exploration tools
8. **Document decisions** - Why certain design choices made

**Remember:**
- Simple is better than complex
- Explicit is better than implicit
- Performance matters, but correctness first
- Test early, test often
