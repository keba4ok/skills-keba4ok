# Implementation Patterns

Common implementation patterns and workflows for JPA entities and Spring Data repositories.

## Table of Contents

1. [Entity Creation Patterns](#entity-creation-patterns)
2. [Relationship Patterns](#relationship-patterns)
3. [Repository Patterns](#repository-patterns)
4. [Domain Modeling Patterns](#domain-modeling-patterns)
5. [Maintenance Patterns](#maintenance-patterns)

---

## Entity Creation Patterns

### Pattern 1: Basic Entity Creation

**When to use:** Creating a new simple entity without relationships.

**Steps:**
1. Create entity with ID and basic attributes
2. Create repository
3. Verify

**Example:**
```
1. create_jpa_entity(
     entityName: "Category",
     attributes: [id, name, description]
   )

2. create_spring_data_repository(
     repositoryClassName: "CategoryRepository",
     entityName: "Category"
   )

3. Verify with exploration tools
```

---

### Pattern 2: Entity with Value Objects

**When to use:** Entity contains embedded objects (Address, Money, etc.).

**Steps:**
1. Create @Embeddable value object
2. Create entity with @Embedded field
3. Use attributeOverrides if multiple instances

**Example:**
```
1. Create Address as @Embeddable (manual or separate entity)

2. create_or_update_entity_attribute(
     entityFqn: "com.example.User",
     name: "homeAddress",
     type: "Address",
     embeddedProperties: {
       embedded: true,
       attributeOverrides: [...]
     }
   )
```

---

### Pattern 3: Entity with Audit Fields

**When to use:** Need tracking of creation/modification.

**Steps:**
1. Create @MappedSuperclass with audit fields
2. Create entities extending audit base
3. Optionally add JPA listeners

**Example:**
```
1. create_jpa_entity(
     entityName: "AuditableEntity",
     mappedSuperclass: true,
     attributes: [createdAt, updatedAt, createdBy, updatedBy]
   )

2. create_jpa_entity(
     entityName: "Product",
     superclass: "AuditableEntity",
     attributes: [id, name, price]
   )
```

---

### Pattern 4: Entity with Optimistic Locking

**When to use:** Need to prevent lost updates in concurrent scenarios.

**Steps:**
1. Create entity
2. Add @Version field
3. JPA automatically handles optimistic locking

**Example:**
```
create_or_update_entity_attribute(
  entityFqn: "com.example.Product",
  name: "version",
  type: "Long",
  columnProperties: {
    version: true
  }
)
```

---

## Relationship Patterns

### Pattern 5: Parent-Child (Composition)

**When to use:** Child can't exist without parent (Order → OrderItem).

**Characteristics:**
- Bidirectional OneToMany/ManyToOne
- CASCADE.ALL on parent
- orphanRemoval = true
- Child FK not nullable

**Steps:**
```
1. Create parent entity
2. Create child entity
3. Add OneToMany to parent (with cascade ALL, orphanRemoval)
4. Add ManyToOne to child (with nullable false)
```

**Example:**
```
// Parent (Order)
create_or_update_entity_attribute(
  name: "items",
  type: "List<OrderItem>",
  relationshipProperties: {
    relationship: "OneToMany",
    mappedBy: "order",
    cascade: "ALL",
    orphanRemoval: true
  }
)

// Child (OrderItem)
create_or_update_entity_attribute(
  name: "order",
  type: "Order",
  relationshipProperties: {
    relationship: "ManyToOne",
    joinColumn: "order_id"
  },
  columnProperties: {
    nullable: false
  }
)
```

---

### Pattern 6: Aggregation (Weak Relationship)

**When to use:** Entities can exist independently (Product → Category).

**Characteristics:**
- Bidirectional OneToMany/ManyToOne
- No cascade or selective cascade
- Child FK nullable or not depending on requirements
- Both entities independent

**Steps:**
```
1. Create both entities independently
2. Add OneToMany to "one" side (no cascade)
3. Add ManyToOne to "many" side
```

**Example:**
```
// Category
create_or_update_entity_attribute(
  name: "products",
  type: "Set<Product>",
  relationshipProperties: {
    relationship: "OneToMany",
    mappedBy: "category"
    // No cascade
  }
)

// Product
create_or_update_entity_attribute(
  name: "category",
  type: "Category",
  relationshipProperties: {
    relationship: "ManyToOne",
    joinColumn: "category_id"
  }
)
```

---

### Pattern 7: Many-to-Many (Simple)

**When to use:** Many-to-many without extra data (User ←→ Role).

**Characteristics:**
- Bidirectional ManyToMany
- Join table managed by JPA
- No explicit join entity
- Use Set to avoid duplicates

**Steps:**
```
1. Create both entities
2. Add ManyToMany to owning side (with @JoinTable)
3. Add ManyToMany to inverse side (with mappedBy)
```

**Example:**
```
// Owning side (User)
create_or_update_entity_attribute(
  name: "roles",
  type: "Set<Role>",
  relationshipProperties: {
    relationship: "ManyToMany",
    joinTable: "user_roles",
    joinColumn: "user_id",
    inverseJoinColumn: "role_id"
  }
)

// Inverse side (Role)
create_or_update_entity_attribute(
  name: "users",
  type: "Set<User>",
  relationshipProperties: {
    relationship: "ManyToMany",
    mappedBy: "roles"
  }
)
```

---

### Pattern 8: Many-to-Many with Extra Data

**When to use:** Many-to-many needs additional fields (User ←→ Role with assignedDate).

**Characteristics:**
- Create explicit join entity
- Two ManyToOne from join entity
- Two OneToMany from original entities
- Composite key in join entity

**Steps:**
```
1. Create join entity with composite key
2. Add ManyToOne relationships to both entities
3. Add OneToMany from original entities to join entity
```

**Example:**
```
// Create UserRole join entity
create_jpa_entity(
  entityName: "UserRole",
  compositeId: true,
  attributes: [userId, roleId, assignedDate]
)

// Add relationships to join entity
create_or_update_entity_attribute(
  entityFqn: "UserRole",
  name: "user",
  type: "User",
  relationshipProperties: {
    relationship: "ManyToOne",
    joinColumn: "user_id"
  }
)

// Add collection to User
create_or_update_entity_attribute(
  entityFqn: "User",
  name: "userRoles",
  type: "List<UserRole>",
  relationshipProperties: {
    relationship: "OneToMany",
    mappedBy: "user"
  }
)
```

---

### Pattern 9: Self-Referencing

**When to use:** Entity references itself (Employee → Manager).

**Characteristics:**
- OneToMany/ManyToOne on same entity
- Nullable foreign key (root has no parent)

**Steps:**
```
1. Create entity
2. Add ManyToOne self-reference
3. Add OneToMany collection
```

**Example:**
```
// Manager reference (ManyToOne)
create_or_update_entity_attribute(
  entityFqn: "Employee",
  name: "manager",
  type: "Employee",
  relationshipProperties: {
    relationship: "ManyToOne",
    joinColumn: "manager_id"
  }
)

// Subordinates (OneToMany)
create_or_update_entity_attribute(
  entityFqn: "Employee",
  name: "subordinates",
  type: "List<Employee>",
  relationshipProperties: {
    relationship: "OneToMany",
    mappedBy: "manager"
  }
)
```

---

### Pattern 10: One-to-One (Separate Tables)

**When to use:** One entity has exactly one related entity (User → UserProfile).

**Characteristics:**
- Bidirectional OneToOne
- Foreign key on owning side
- Optional: shared primary key

**Steps:**
```
1. Create both entities
2. Add OneToOne to owning side (with @JoinColumn)
3. Add OneToOne to inverse side (with mappedBy)
```

**Example:**
```
// Owning side (User)
create_or_update_entity_attribute(
  entityFqn: "User",
  name: "profile",
  type: "UserProfile",
  relationshipProperties: {
    relationship: "OneToOne",
    joinColumn: "profile_id",
    cascade: "ALL",
    orphanRemoval: true
  }
)

// Inverse side (UserProfile)
create_or_update_entity_attribute(
  entityFqn: "UserProfile",
  name: "user",
  type: "User",
  relationshipProperties: {
    relationship: "OneToOne",
    mappedBy: "profile"
  }
)
```

---

## Repository Patterns

### Pattern 11: Basic Repository

**When to use:** Standard CRUD operations sufficient.

**Steps:**
```
create_spring_data_repository(
  repositoryClassName: "UserRepository",
  entityName: "User",
  baseRepositoryClass: "JpaRepository"
)
```

**Result:** All CRUD + pagination/sorting methods available.

---

### Pattern 12: Repository per Aggregate

**When to use:** Following DDD principles.

**Guidelines:**
- One repository per aggregate root
- No repositories for child entities
- Access children through parent

**Example:**
```
✓ OrderRepository (for Order aggregate)
✗ No OrderItemRepository (access through Order)

✓ CartRepository (for Cart aggregate)
✗ No CartItemRepository (access through Cart)
```

---

### Pattern 13: Read-Only Repository

**When to use:** Entity should not be modified through repository.

**Manual configuration needed:**
```java
public interface ReportRepository extends Repository<Report, Long> {
    List<Report> findAll();
    Optional<Report> findById(Long id);
    // No save, delete methods
}
```

---

## Domain Modeling Patterns

### Pattern 14: Single Table Inheritance

**When to use:** Few subclasses, performance important, subclass attributes similar.

**Steps:**
```
1. Create base entity with inheritance
2. Create subclasses with discriminator values
```

**Example:**
```
// Base
create_jpa_entity(
  entityName: "Payment",
  inheritanceType: "SINGLE_TABLE",
  discriminatorColumn: "payment_type",
  attributes: [id, amount, date]
)

// Subclass
create_jpa_entity(
  entityName: "CreditCardPayment",
  superclass: "Payment",
  discriminatorValue: "CREDIT_CARD",
  attributes: [cardNumber, expiryDate]
)
```

**Pros:**
- Fast queries (no joins)
- Simple schema

**Cons:**
- Nullable subclass columns
- Large table

---

### Pattern 15: Joined Table Inheritance

**When to use:** Many subclasses, different attributes, normalization important.

**Steps:**
```
create_jpa_entity(
  entityName: "Vehicle",
  inheritanceType: "JOINED",
  attributes: [id, brand, model]
)

create_jpa_entity(
  entityName: "Car",
  superclass: "Vehicle",
  attributes: [numDoors, trunkSize]
)
```

**Pros:**
- Normalized
- No nullable columns

**Cons:**
- Slower (requires joins)
- Complex queries

---

### Pattern 16: Table Per Class

**When to use:** Rarely - subclasses very different, no polymorphic queries.

**Steps:**
```
create_jpa_entity(
  entityName: "Person",
  inheritanceType: "TABLE_PER_CLASS",
  attributes: [id, name]
)
```

**Pros:**
- Each class has own table

**Cons:**
- Polymorphic queries very slow
- Duplicate columns

---

## Maintenance Patterns

### Pattern 17: Adding Field to Existing Entity

**Steps:**
1. Explore entity to understand structure
2. Add field
3. Verify

**Example:**
```
1. get_jpa_entity_by_name("User")  // Explore

2. create_or_update_entity_attribute(
     entityFqn: "com.example.User",
     name: "phoneNumber",
     type: "String",
     columnProperties: {length: 20}
   )

3. get_jpa_entity_by_name("User")  // Verify
```

---

### Pattern 18: Adding Relationship to Existing Entities

**Steps:**
1. Explore both entities
2. Add relationship to owning side
3. Add relationship to inverse side
4. Verify both

**Example:**
```
1. get_jpa_entity_by_name("User")
2. get_jpa_entity_by_name("Order")

3. create_or_update_entity_attribute(
     entityFqn: "Order",
     name: "user",
     type: "User",
     relationshipProperties: {
       relationship: "ManyToOne",
       joinColumn: "user_id"
     }
   )

4. create_or_update_entity_attribute(
     entityFqn: "User",
     name: "orders",
     type: "List<Order>",
     relationshipProperties: {
       relationship: "OneToMany",
       mappedBy: "user"
     }
   )

5. Verify both entities
```

---

### Pattern 19: Removing Field

**Steps:**
1. Explore entity
2. Remove field
3. Verify

**Example:**
```
1. get_jpa_entity_by_name("User")

2. delete_entity_attribute(
     entityFqn: "com.example.User",
     name: "deprecatedField"
   )

3. get_jpa_entity_by_name("User")
```

---

### Pattern 20: Refactoring Relationship

**Steps:**
1. Explore current structure
2. Remove old relationship (if changing type)
3. Add new relationship
4. Update related entity
5. Verify

**Example:** Changing User → Orders from unidirectional to bidirectional

```
1. Explore User and Order

2. Add orders to User (if not exists)

3. Add user to Order (if not exists)

4. Verify both directions
```

---

## Pattern Selection Guide

| Need | Pattern |
|------|---------|
| Simple entity | Basic Entity Creation |
| Entity with address | Entity with Value Objects |
| Track changes | Entity with Audit Fields |
| Prevent lost updates | Entity with Optimistic Locking |
| Order → Items | Parent-Child (Composition) |
| Product → Category | Aggregation (Weak Relationship) |
| User ←→ Role (simple) | Many-to-Many (Simple) |
| User ←→ Role (with date) | Many-to-Many with Extra Data |
| Employee → Manager | Self-Referencing |
| User → Profile | One-to-One |
| Different payment types | Single Table Inheritance |
| Vehicle types | Joined Table Inheritance |
| Standard CRUD | Basic Repository |
| DDD design | Repository per Aggregate |
| Add field | Adding Field Pattern |
| Add relationship | Adding Relationship Pattern |
| Remove field | Removing Field Pattern |

---

## Quick Decision Trees

### Choosing Relationship Type

```
Are there many A and many B?
├─ YES → ManyToMany
│   └─ Need extra data?
│       ├─ YES → Create join entity
│       └─ NO → Simple ManyToMany
└─ NO → One side is "one"
    └─ One A, many B?
        ├─ YES → OneToMany/ManyToOne
        └─ NO → OneToOne
```

### Choosing Cascade Type

```
Can child exist without parent?
├─ NO → Composition
│   └─ Use CASCADE.ALL + orphanRemoval
└─ YES → Aggregation
    └─ Independent entities
        └─ Use no cascade or selective cascade
```

### Choosing Inheritance Strategy

```
How many subclasses?
├─ Few (2-3) → SINGLE_TABLE
└─ Many (4+) → JOINED

Are attributes very different?
├─ YES → JOINED
└─ NO → SINGLE_TABLE

Performance critical?
├─ YES → SINGLE_TABLE
└─ NO → JOINED (better normalization)
```

---

## Anti-Patterns to Avoid

1. **EAGER collections** - Always use LAZY for OneToMany, ManyToMany
2. **CASCADE.REMOVE everywhere** - Can accidentally delete important data
3. **Bidirectional without mappedBy** - Causes FK conflicts
4. **Multiple EAGER relationships** - Cartesian product problem
5. **No indexes on FK columns** - Performance issues
6. **Ignoring fetch strategies** - N+1 query problems
7. **Not using composite keys properly** - @IdClass issues
8. **Forgetting nullable=false** - Required fields left optional

---

## Best Practice Patterns

1. **Explore before implementing** - Always understand existing structure
2. **Configure both sides** - For bidirectional relationships
3. **LAZY by default** - Especially for collections
4. **Cascade carefully** - Understand the implications
5. **Verify after changes** - Use exploration tools
6. **Follow conventions** - Naming, package structure
7. **Add indexes** - On foreign keys and frequent queries
8. **Use version fields** - When concurrent updates possible
