# Attribute Configurations Reference

Complete reference for all types of entity attributes with concrete examples.

## Table of Contents

1. [Basic Attributes](#basic-attributes)
2. [Primary Keys](#primary-keys)
3. [String Attributes](#string-attributes)
4. [Numeric Attributes](#numeric-attributes)
5. [Date/Time Attributes](#datetime-attributes)
6. [Boolean Attributes](#boolean-attributes)
7. [Relationship Attributes](#relationship-attributes)
8. [Collection Attributes](#collection-attributes)
9. [Embedded Attributes](#embedded-attributes)
10. [Special Attributes](#special-attributes)

---

## Basic Attributes

### Simple String Field

```json
{
  "name": "name",
  "type": "String",
  "isId": false,
  "columnProperties": {},
  "idGenerationProperties": {},
  "relationshipProperties": {},
  "collectionProperties": {},
  "embeddedProperties": {}
}
```

**Generated:**
```java
@Column
private String name;
```

---

### Required String Field

```json
{
  "name": "username",
  "type": "String",
  "isId": false,
  "columnProperties": {
    "nullable": false
  },
  "idGenerationProperties": {},
  "relationshipProperties": {},
  "collectionProperties": {},
  "embeddedProperties": {}
}
```

**Generated:**
```java
@Column(nullable = false)
private String username;
```

---

### Unique String Field

```json
{
  "name": "email",
  "type": "String",
  "isId": false,
  "columnProperties": {
    "unique": true,
    "nullable": false,
    "length": 255
  },
  "idGenerationProperties": {},
  "relationshipProperties": {},
  "collectionProperties": {},
  "embeddedProperties": {}
}
```

**Generated:**
```java
@Column(unique = true, nullable = false, length = 255)
private String email;
```

---

## Primary Keys

### Auto-Increment ID (MySQL/PostgreSQL)

```json
{
  "name": "id",
  "type": "Long",
  "isId": true,
  "columnProperties": {},
  "idGenerationProperties": {
    "generatedStrategy": "IDENTITY"
  },
  "relationshipProperties": {},
  "collectionProperties": {},
  "embeddedProperties": {}
}
```

**Generated:**
```java
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private Long id;
```

---

### Sequence-Based ID (Oracle/PostgreSQL)

```json
{
  "name": "id",
  "type": "Long",
  "isId": true,
  "columnProperties": {},
  "idGenerationProperties": {
    "generatedStrategy": "SEQUENCE",
    "sequenceName": "user_id_seq",
    "initialValue": 1,
    "allocationSize": 50
  },
  "relationshipProperties": {},
  "collectionProperties": {},
  "embeddedProperties": {}
}
```

**Generated:**
```java
@Id
@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "user_gen")
@SequenceGenerator(name = "user_gen", sequenceName = "user_id_seq",
                   initialValue = 1, allocationSize = 50)
private Long id;
```

---

### UUID Primary Key

```json
{
  "name": "id",
  "type": "UUID",
  "isId": true,
  "columnProperties": {},
  "idGenerationProperties": {
    "generatedStrategy": "UUID"
  },
  "relationshipProperties": {},
  "collectionProperties": {},
  "embeddedProperties": {}
}
```

**Generated:**
```java
@Id
@GeneratedValue(strategy = GenerationType.UUID)
private UUID id;
```

---

### Composite Key (Multiple @Id)

```json
[
  {
    "name": "userId",
    "type": "Long",
    "isId": true,
    "columnProperties": {},
    "idGenerationProperties": {},
    "relationshipProperties": {},
    "collectionProperties": {},
    "embeddedProperties": {}
  },
  {
    "name": "roleId",
    "type": "Long",
    "isId": true,
    "columnProperties": {},
    "idGenerationProperties": {},
    "relationshipProperties": {},
    "collectionProperties": {},
    "embeddedProperties": {}
  }
]
```

**Generated:**
```java
@Id
private Long userId;

@Id
private Long roleId;
```

Note: Requires @IdClass or @EmbeddedId at entity level

---

## String Attributes

### Limited Length String

```json
{
  "name": "title",
  "type": "String",
  "isId": false,
  "columnProperties": {
    "length": 100,
    "nullable": false
  },
  "idGenerationProperties": {},
  "relationshipProperties": {},
  "collectionProperties": {},
  "embeddedProperties": {}
}
```

**Generated:**
```java
@Column(length = 100, nullable = false)
private String title;
```

---

### Large Text (LOB)

```json
{
  "name": "description",
  "type": "String",
  "isId": false,
  "columnProperties": {
    "lob": true
  },
  "idGenerationProperties": {},
  "relationshipProperties": {},
  "collectionProperties": {},
  "embeddedProperties": {}
}
```

**Generated:**
```java
@Lob
@Column
private String description;
```

**Database:** CLOB or TEXT column

---

### Custom Column Definition

```json
{
  "name": "status",
  "type": "String",
  "isId": false,
  "columnProperties": {
    "columnDefinition": "VARCHAR(20) DEFAULT 'ACTIVE'"
  },
  "idGenerationProperties": {},
  "relationshipProperties": {},
  "collectionProperties": {},
  "embeddedProperties": {}
}
```

**Generated:**
```java
@Column(columnDefinition = "VARCHAR(20) DEFAULT 'ACTIVE'")
private String status;
```

---

## Numeric Attributes

### Integer Field

```json
{
  "name": "age",
  "type": "Integer",
  "isId": false,
  "columnProperties": {},
  "idGenerationProperties": {},
  "relationshipProperties": {},
  "collectionProperties": {},
  "embeddedProperties": {}
}
```

**Generated:**
```java
@Column
private Integer age;
```

---

### Decimal/Money Field

```json
{
  "name": "price",
  "type": "BigDecimal",
  "isId": false,
  "columnProperties": {
    "precision": 19,
    "scale": 2,
    "nullable": false
  },
  "idGenerationProperties": {},
  "relationshipProperties": {},
  "collectionProperties": {},
  "embeddedProperties": {}
}
```

**Generated:**
```java
@Column(precision = 19, scale = 2, nullable = false)
private BigDecimal price;
```

**Database:** DECIMAL(19,2) - stores values like 1234567890123456.99

---

### Long Field

```json
{
  "name": "viewCount",
  "type": "Long",
  "isId": false,
  "columnProperties": {
    "nullable": false
  },
  "idGenerationProperties": {},
  "relationshipProperties": {},
  "collectionProperties": {},
  "embeddedProperties": {}
}
```

**Generated:**
```java
@Column(nullable = false)
private Long viewCount;
```

---

## Date/Time Attributes

### LocalDateTime Field

```json
{
  "name": "createdAt",
  "type": "LocalDateTime",
  "isId": false,
  "columnProperties": {
    "nullable": false,
    "updatable": false
  },
  "idGenerationProperties": {},
  "relationshipProperties": {},
  "collectionProperties": {},
  "embeddedProperties": {}
}
```

**Generated:**
```java
@Column(nullable = false, updatable = false)
private LocalDateTime createdAt;
```

**Note:** updatable=false makes it immutable after first save

---

### LocalDate Field

```json
{
  "name": "birthDate",
  "type": "LocalDate",
  "isId": false,
  "columnProperties": {},
  "idGenerationProperties": {},
  "relationshipProperties": {},
  "collectionProperties": {},
  "embeddedProperties": {}
}
```

**Generated:**
```java
@Column
private LocalDate birthDate;
```

---

### Legacy Date with Temporal

```json
{
  "name": "createdDate",
  "type": "Date",
  "isId": false,
  "columnProperties": {
    "temporal": "TIMESTAMP",
    "nullable": false
  },
  "idGenerationProperties": {},
  "relationshipProperties": {},
  "collectionProperties": {},
  "embeddedProperties": {}
}
```

**Generated:**
```java
@Temporal(TemporalType.TIMESTAMP)
@Column(nullable = false)
private Date createdDate;
```

**Temporal Types:**
- DATE: Year, month, day
- TIME: Hour, minute, second
- TIMESTAMP: Full date and time

---

### Instant Field

```json
{
  "name": "lastLoginAt",
  "type": "Instant",
  "isId": false,
  "columnProperties": {},
  "idGenerationProperties": {},
  "relationshipProperties": {},
  "collectionProperties": {},
  "embeddedProperties": {}
}
```

**Generated:**
```java
@Column
private Instant lastLoginAt;
```

---

## Boolean Attributes

### Boolean Field

```json
{
  "name": "active",
  "type": "Boolean",
  "isId": false,
  "columnProperties": {
    "nullable": false
  },
  "idGenerationProperties": {},
  "relationshipProperties": {},
  "collectionProperties": {},
  "embeddedProperties": {}
}
```

**Generated:**
```java
@Column(nullable = false)
private Boolean active;
```

---

## Relationship Attributes

### ManyToOne (Owning Side)

```json
{
  "name": "category",
  "type": "Category",
  "isId": false,
  "columnProperties": {},
  "idGenerationProperties": {},
  "relationshipProperties": {
    "relationship": "ManyToOne",
    "joinColumn": "category_id",
    "fetch": "LAZY"
  },
  "collectionProperties": {},
  "embeddedProperties": {}
}
```

**Generated:**
```java
@ManyToOne(fetch = FetchType.LAZY)
@JoinColumn(name = "category_id")
private Category category;
```

**Database:** Foreign key column `category_id`

---

### OneToMany (Inverse Side)

```json
{
  "name": "orders",
  "type": "List<Order>",
  "isId": false,
  "columnProperties": {},
  "idGenerationProperties": {},
  "relationshipProperties": {
    "relationship": "OneToMany",
    "mappedBy": "user",
    "fetch": "LAZY",
    "cascade": "ALL",
    "orphanRemoval": true
  },
  "collectionProperties": {},
  "embeddedProperties": {}
}
```

**Generated:**
```java
@OneToMany(mappedBy = "user",
           fetch = FetchType.LAZY,
           cascade = CascadeType.ALL,
           orphanRemoval = true)
private List<Order> orders;
```

**Note:** No foreign key on this side - it's in Order table

---

### ManyToMany (Owning Side)

```json
{
  "name": "roles",
  "type": "Set<Role>",
  "isId": false,
  "columnProperties": {},
  "idGenerationProperties": {},
  "relationshipProperties": {
    "relationship": "ManyToMany",
    "joinTable": "user_roles",
    "joinColumn": "user_id",
    "inverseJoinColumn": "role_id",
    "fetch": "LAZY"
  },
  "collectionProperties": {},
  "embeddedProperties": {}
}
```

**Generated:**
```java
@ManyToMany(fetch = FetchType.LAZY)
@JoinTable(
    name = "user_roles",
    joinColumns = @JoinColumn(name = "user_id"),
    inverseJoinColumns = @JoinColumn(name = "role_id")
)
private Set<Role> roles;
```

**Database:** Creates join table `user_roles(user_id, role_id)`

---

### ManyToMany (Inverse Side)

```json
{
  "name": "users",
  "type": "Set<User>",
  "isId": false,
  "columnProperties": {},
  "idGenerationProperties": {},
  "relationshipProperties": {
    "relationship": "ManyToMany",
    "mappedBy": "roles",
    "fetch": "LAZY"
  },
  "collectionProperties": {},
  "embeddedProperties": {}
}
```

**Generated:**
```java
@ManyToMany(mappedBy = "roles", fetch = FetchType.LAZY)
private Set<User> users;
```

---

### OneToOne (Owning Side)

```json
{
  "name": "profile",
  "type": "UserProfile",
  "isId": false,
  "columnProperties": {},
  "idGenerationProperties": {},
  "relationshipProperties": {
    "relationship": "OneToOne",
    "joinColumn": "profile_id",
    "fetch": "LAZY",
    "cascade": "ALL",
    "orphanRemoval": true
  },
  "collectionProperties": {},
  "embeddedProperties": {}
}
```

**Generated:**
```java
@OneToOne(fetch = FetchType.LAZY,
          cascade = CascadeType.ALL,
          orphanRemoval = true)
@JoinColumn(name = "profile_id")
private UserProfile profile;
```

---

### OneToOne (Inverse Side)

```json
{
  "name": "user",
  "type": "User",
  "isId": false,
  "columnProperties": {},
  "idGenerationProperties": {},
  "relationshipProperties": {
    "relationship": "OneToOne",
    "mappedBy": "profile",
    "fetch": "LAZY"
  },
  "collectionProperties": {},
  "embeddedProperties": {}
}
```

**Generated:**
```java
@OneToOne(mappedBy = "profile", fetch = FetchType.LAZY)
private User user;
```

---

## Collection Attributes

### Element Collection (Basic Types)

```json
{
  "name": "phoneNumbers",
  "type": "Set<String>",
  "isId": false,
  "columnProperties": {},
  "idGenerationProperties": {},
  "relationshipProperties": {},
  "collectionProperties": {
    "elementCollection": true,
    "collectionTable": "user_phone_numbers"
  },
  "embeddedProperties": {}
}
```

**Generated:**
```java
@ElementCollection
@CollectionTable(name = "user_phone_numbers",
                 joinColumns = @JoinColumn(name = "user_id"))
@Column(name = "phone_number")
private Set<String> phoneNumbers;
```

**Database:** Creates table `user_phone_numbers(user_id, phone_number)`

---

### Element Collection (Embeddables)

```json
{
  "name": "addresses",
  "type": "List<Address>",
  "isId": false,
  "columnProperties": {},
  "idGenerationProperties": {},
  "relationshipProperties": {},
  "collectionProperties": {
    "elementCollection": true,
    "collectionTable": "user_addresses"
  },
  "embeddedProperties": {}
}
```

**Generated:**
```java
@ElementCollection
@CollectionTable(name = "user_addresses",
                 joinColumns = @JoinColumn(name = "user_id"))
private List<Address> addresses;
```

**Note:** Address must be @Embeddable

---

## Embedded Attributes

### Simple Embedded Object

```json
{
  "name": "address",
  "type": "Address",
  "isId": false,
  "columnProperties": {},
  "idGenerationProperties": {},
  "relationshipProperties": {},
  "collectionProperties": {},
  "embeddedProperties": {
    "embedded": true
  }
}
```

**Generated:**
```java
@Embedded
private Address address;
```

**Note:** Address fields stored in same table as entity

---

### Embedded with Attribute Overrides

```json
{
  "name": "homeAddress",
  "type": "Address",
  "isId": false,
  "columnProperties": {},
  "idGenerationProperties": {},
  "relationshipProperties": {},
  "collectionProperties": {},
  "embeddedProperties": {
    "embedded": true,
    "attributeOverrides": [
      {
        "attributeName": "street",
        "column": "home_street"
      },
      {
        "attributeName": "city",
        "column": "home_city"
      },
      {
        "attributeName": "zipCode",
        "column": "home_zip_code"
      }
    ]
  }
}
```

**Generated:**
```java
@Embedded
@AttributeOverrides({
    @AttributeOverride(name = "street", column = @Column(name = "home_street")),
    @AttributeOverride(name = "city", column = @Column(name = "home_city")),
    @AttributeOverride(name = "zipCode", column = @Column(name = "home_zip_code"))
})
private Address homeAddress;
```

**Use case:** Multiple embedded objects of same type

---

## Special Attributes

### Version Field (Optimistic Locking)

```json
{
  "name": "version",
  "type": "Long",
  "isId": false,
  "columnProperties": {
    "version": true
  },
  "idGenerationProperties": {},
  "relationshipProperties": {},
  "collectionProperties": {},
  "embeddedProperties": {}
}
```

**Generated:**
```java
@Version
private Long version;
```

**Purpose:** Optimistic locking - prevents lost updates

---

### Read-Only Field

```json
{
  "name": "createdBy",
  "type": "String",
  "isId": false,
  "columnProperties": {
    "insertable": true,
    "updatable": false
  },
  "idGenerationProperties": {},
  "relationshipProperties": {},
  "collectionProperties": {},
  "embeddedProperties": {}
}
```

**Generated:**
```java
@Column(insertable = true, updatable = false)
private String createdBy;
```

**Behavior:** Set on creation, never updated

---

### Transient Field (Not Persisted)

Not configured through tool - add manually:

```java
@Transient
private String calculatedField;
```

---

## Complete Examples

### User Entity with Mixed Attributes

```json
{
  "entityName": "User",
  "attributes": [
    {
      "name": "id",
      "type": "Long",
      "isId": true,
      "idGenerationProperties": {
        "generatedStrategy": "IDENTITY"
      }
    },
    {
      "name": "username",
      "type": "String",
      "isId": false,
      "columnProperties": {
        "unique": true,
        "nullable": false,
        "length": 50
      }
    },
    {
      "name": "email",
      "type": "String",
      "isId": false,
      "columnProperties": {
        "unique": true,
        "nullable": false
      }
    },
    {
      "name": "createdAt",
      "type": "LocalDateTime",
      "isId": false,
      "columnProperties": {
        "nullable": false,
        "updatable": false
      }
    },
    {
      "name": "active",
      "type": "Boolean",
      "isId": false,
      "columnProperties": {
        "nullable": false
      }
    },
    {
      "name": "orders",
      "type": "List<Order>",
      "isId": false,
      "relationshipProperties": {
        "relationship": "OneToMany",
        "mappedBy": "user",
        "fetch": "LAZY"
      }
    },
    {
      "name": "version",
      "type": "Long",
      "isId": false,
      "columnProperties": {
        "version": true
      }
    }
  ]
}
```

---

### Product Entity

```json
{
  "entityName": "Product",
  "attributes": [
    {
      "name": "id",
      "type": "Long",
      "isId": true,
      "idGenerationProperties": {
        "generatedStrategy": "IDENTITY"
      }
    },
    {
      "name": "name",
      "type": "String",
      "isId": false,
      "columnProperties": {
        "nullable": false,
        "length": 200
      }
    },
    {
      "name": "description",
      "type": "String",
      "isId": false,
      "columnProperties": {
        "lob": true
      }
    },
    {
      "name": "price",
      "type": "BigDecimal",
      "isId": false,
      "columnProperties": {
        "precision": 19,
        "scale": 2,
        "nullable": false
      }
    },
    {
      "name": "category",
      "type": "Category",
      "isId": false,
      "relationshipProperties": {
        "relationship": "ManyToOne",
        "joinColumn": "category_id",
        "fetch": "LAZY"
      }
    },
    {
      "name": "tags",
      "type": "Set<String>",
      "isId": false,
      "collectionProperties": {
        "elementCollection": true,
        "collectionTable": "product_tags"
      }
    }
  ]
}
```

---

## Quick Reference Table

| Type | Configuration Key | Common Values |
|------|------------------|---------------|
| Primary Key | isId: true | + idGenerationProperties |
| Required | columnProperties.nullable | false |
| Unique | columnProperties.unique | true |
| Length Limit | columnProperties.length | 50, 100, 255 |
| Large Text | columnProperties.lob | true |
| Decimal | columnProperties.precision/scale | 19/2 for money |
| Read-Only | columnProperties.updatable | false |
| Version | columnProperties.version | true |
| Relationship | relationshipProperties.relationship | OneToMany, ManyToOne, etc. |
| Fetch Type | relationshipProperties.fetch | LAZY, EAGER |
| Cascade | relationshipProperties.cascade | ALL, PERSIST, MERGE |
| Join Column | relationshipProperties.joinColumn | "entity_id" |
| Mapped By | relationshipProperties.mappedBy | "fieldName" |
| Element Collection | collectionProperties.elementCollection | true |
| Embedded | embeddedProperties.embedded | true |
