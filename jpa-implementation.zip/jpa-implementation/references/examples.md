# Implementation Examples

Complete, real-world examples of implementing JPA entities and Spring Data repositories.

## Table of Contents

1. [Simple Entity Creation](#simple-entity-creation)
2. [Entity with Relationships](#entity-with-relationships)
3. [Complete E-Commerce Domain](#complete-e-commerce-domain)
4. [Inheritance Hierarchy](#inheritance-hierarchy)
5. [Composite Keys](#composite-keys)
6. [Audit Entity Pattern](#audit-entity-pattern)
7. [Repository Creation](#repository-creation)

---

## Example 1: Simple Entity Creation

### Scenario
Create a basic User entity with email and username.

### Step-by-Step

**Step 1: Create User entity**

```
User: "Create a User entity with id, username, and email"

Tool: create_jpa_entity
Parameters:
{
  "entityName": "User",
  "entityPackage": "com.example.domain",
  "language": "Java",
  "projectPath": "/Users/dev/myapp",
  "attributes": [
    {
      "name": "id",
      "type": "Long",
      "isId": true,
      "columnProperties": {},
      "idGenerationProperties": {
        "generatedStrategy": "IDENTITY"
      },
      "relationshipProperties": {},
      "collectionProperties": {},
      "embeddedProperties": {}
    },
    {
      "name": "username",
      "type": "String",
      "isId": false,
      "columnProperties": {
        "unique": true,
        "nullable": false,
        "length": 50
      },
      "idGenerationProperties": {},
      "relationshipProperties": {},
      "collectionProperties": {},
      "embeddedProperties": {}
    },
    {
      "name": "email",
      "type": "String",
      "isId": false,
      "columnProperties": {
        "unique": true,
        "nullable": false,
        "length": 100
      },
      "idGenerationProperties": {},
      "relationshipProperties": {},
      "collectionProperties": {},
      "embeddedProperties": {}
    }
  ]
}
```

**Result:**

```java
package com.example.domain;

import jakarta.persistence.*;

@Entity
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false, length = 50)
    private String username;

    @Column(unique = true, nullable = false, length = 100)
    private String email;

    // Getters and setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
```

**Step 2: Create repository**

```
User: "Create a repository for User"

Tool: create_spring_data_repository
Parameters:
{
  "repositoryClassName": "UserRepository",
  "entityName": "User",
  "packageName": "com.example.repository",
  "baseRepositoryClass": "JpaRepository",
  "projectPath": "/Users/dev/myapp"
}
```

**Result:**

```java
package com.example.repository;

import com.example.domain.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, Long> {
}
```

---

## Example 2: Entity with Relationships

### Scenario
Create Order entity that belongs to User and has OrderItems.

### Step-by-Step

**Step 1: Create Order entity**

```
Tool: create_jpa_entity
{
  "entityName": "Order",
  "entityPackage": "com.example.domain",
  "projectPath": "/Users/dev/myapp",
  "attributes": [
    {
      "name": "id",
      "type": "Long",
      "isId": true,
      "idGenerationProperties": {
        "generatedStrategy": "IDENTITY"
      }
    },
    {
      "name": "orderDate",
      "type": "LocalDateTime",
      "isId": false,
      "columnProperties": {
        "nullable": false,
        "updatable": false
      }
    },
    {
      "name": "totalAmount",
      "type": "BigDecimal",
      "isId": false,
      "columnProperties": {
        "precision": 19,
        "scale": 2,
        "nullable": false
      }
    },
    {
      "name": "status",
      "type": "String",
      "isId": false,
      "columnProperties": {
        "length": 20,
        "nullable": false
      }
    }
  ]
}
```

**Step 2: Add relationship to User**

```
Tool: create_or_update_entity_attribute
{
  "entityFqn": "com.example.domain.Order",
  "name": "user",
  "type": "User",
  "isId": false,
  "columnProperties": {
    "nullable": false
  },
  "relationshipProperties": {
    "relationship": "ManyToOne",
    "joinColumn": "user_id",
    "fetch": "LAZY"
  }
}
```

**Step 3: Add orders collection to User**

```
Tool: create_or_update_entity_attribute
{
  "entityFqn": "com.example.domain.User",
  "name": "orders",
  "type": "List<Order>",
  "isId": false,
  "relationshipProperties": {
    "relationship": "OneToMany",
    "mappedBy": "user",
    "fetch": "LAZY",
    "cascade": "ALL",
    "orphanRemoval": true
  }
}
```

**Step 4: Create OrderItem entity**

```
Tool: create_jpa_entity
{
  "entityName": "OrderItem",
  "entityPackage": "com.example.domain",
  "projectPath": "/Users/dev/myapp",
  "attributes": [
    {
      "name": "id",
      "type": "Long",
      "isId": true,
      "idGenerationProperties": {
        "generatedStrategy": "IDENTITY"
      }
    },
    {
      "name": "quantity",
      "type": "Integer",
      "isId": false,
      "columnProperties": {
        "nullable": false
      }
    },
    {
      "name": "price",
      "type": "BigDecimal",
      "isId": false,
      "columnProperties": {
        "precision": 19,
        "scale": 2,
        "nullable": false
      }
    }
  ]
}
```

**Step 5: Add relationships for OrderItem**

```
// Add order reference
Tool: create_or_update_entity_attribute
{
  "entityFqn": "com.example.domain.OrderItem",
  "name": "order",
  "type": "Order",
  "relationshipProperties": {
    "relationship": "ManyToOne",
    "joinColumn": "order_id"
  },
  "columnProperties": {
    "nullable": false
  }
}

// Add items collection to Order
Tool: create_or_update_entity_attribute
{
  "entityFqn": "com.example.domain.Order",
  "name": "items",
  "type": "List<OrderItem>",
  "relationshipProperties": {
    "relationship": "OneToMany",
    "mappedBy": "order",
    "fetch": "LAZY",
    "cascade": "ALL",
    "orphanRemoval": true
  }
}
```

**Final Result:**

```java
@Entity
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String username;

    @OneToMany(mappedBy = "user",
               fetch = FetchType.LAZY,
               cascade = CascadeType.ALL,
               orphanRemoval = true)
    private List<Order> orders = new ArrayList<>();
}

@Entity
@Table(name = "orders")
public class Order {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, updatable = false)
    private LocalDateTime orderDate;

    @Column(precision = 19, scale = 2, nullable = false)
    private BigDecimal totalAmount;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @OneToMany(mappedBy = "order",
               fetch = FetchType.LAZY,
               cascade = CascadeType.ALL,
               orphanRemoval = true)
    private List<OrderItem> items = new ArrayList<>();
}

@Entity
public class OrderItem {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private Integer quantity;

    @Column(precision = 19, scale = 2, nullable = false)
    private BigDecimal price;

    @ManyToOne
    @JoinColumn(name = "order_id", nullable = false)
    private Order order;
}
```

---

## Example 3: Complete E-Commerce Domain

### Scenario
Build a complete e-commerce domain model with Products, Categories, and Shopping Cart.

### Entities Needed

1. Category
2. Product
3. User
4. Cart
5. CartItem

### Implementation

**Step 1: Create Category**

```
Tool: create_jpa_entity
{
  "entityName": "Category",
  "entityPackage": "com.example.domain",
  "projectPath": "/Users/dev/shop",
  "attributes": [
    {
      "name": "id",
      "type": "Long",
      "isId": true,
      "idGenerationProperties": {"generatedStrategy": "IDENTITY"}
    },
    {
      "name": "name",
      "type": "String",
      "isId": false,
      "columnProperties": {"unique": true, "nullable": false, "length": 100}
    },
    {
      "name": "description",
      "type": "String",
      "isId": false,
      "columnProperties": {"length": 500}
    }
  ]
}
```

**Step 2: Create Product with Category relationship**

```
Tool: create_jpa_entity
{
  "entityName": "Product",
  "entityPackage": "com.example.domain",
  "projectPath": "/Users/dev/shop",
  "attributes": [
    {
      "name": "id",
      "type": "Long",
      "isId": true,
      "idGenerationProperties": {"generatedStrategy": "IDENTITY"}
    },
    {
      "name": "name",
      "type": "String",
      "isId": false,
      "columnProperties": {"nullable": false, "length": 200}
    },
    {
      "name": "description",
      "type": "String",
      "isId": false,
      "columnProperties": {"lob": true}
    },
    {
      "name": "price",
      "type": "BigDecimal",
      "isId": false,
      "columnProperties": {"precision": 19, "scale": 2, "nullable": false}
    },
    {
      "name": "stockQuantity",
      "type": "Integer",
      "isId": false,
      "columnProperties": {"nullable": false}
    }
  ]
}

// Add category relationship
Tool: create_or_update_entity_attribute
{
  "entityFqn": "com.example.domain.Product",
  "name": "category",
  "type": "Category",
  "relationshipProperties": {
    "relationship": "ManyToOne",
    "joinColumn": "category_id",
    "fetch": "LAZY"
  }
}

// Add products to Category
Tool: create_or_update_entity_attribute
{
  "entityFqn": "com.example.domain.Category",
  "name": "products",
  "type": "Set<Product>",
  "relationshipProperties": {
    "relationship": "OneToMany",
    "mappedBy": "category",
    "fetch": "LAZY"
  }
}
```

**Step 3: Create Cart**

```
Tool: create_jpa_entity
{
  "entityName": "Cart",
  "entityPackage": "com.example.domain",
  "projectPath": "/Users/dev/shop",
  "attributes": [
    {
      "name": "id",
      "type": "Long",
      "isId": true,
      "idGenerationProperties": {"generatedStrategy": "IDENTITY"}
    },
    {
      "name": "createdAt",
      "type": "LocalDateTime",
      "isId": false,
      "columnProperties": {"nullable": false, "updatable": false}
    }
  ]
}

// Link to User (OneToOne)
Tool: create_or_update_entity_attribute
{
  "entityFqn": "com.example.domain.Cart",
  "name": "user",
  "type": "User",
  "relationshipProperties": {
    "relationship": "OneToOne",
    "joinColumn": "user_id",
    "fetch": "LAZY"
  },
  "columnProperties": {"nullable": false}
}

// Add cart to User
Tool: create_or_update_entity_attribute
{
  "entityFqn": "com.example.domain.User",
  "name": "cart",
  "type": "Cart",
  "relationshipProperties": {
    "relationship": "OneToOne",
    "mappedBy": "user",
    "cascade": "ALL",
    "orphanRemoval": true,
    "fetch": "LAZY"
  }
}
```

**Step 4: Create CartItem**

```
Tool: create_jpa_entity
{
  "entityName": "CartItem",
  "entityPackage": "com.example.domain",
  "projectPath": "/Users/dev/shop",
  "attributes": [
    {
      "name": "id",
      "type": "Long",
      "isId": true,
      "idGenerationProperties": {"generatedStrategy": "IDENTITY"}
    },
    {
      "name": "quantity",
      "type": "Integer",
      "isId": false,
      "columnProperties": {"nullable": false}
    }
  ]
}

// Link to Cart
Tool: create_or_update_entity_attribute
{
  "entityFqn": "com.example.domain.CartItem",
  "name": "cart",
  "type": "Cart",
  "relationshipProperties": {
    "relationship": "ManyToOne",
    "joinColumn": "cart_id"
  }
}

// Link to Product
Tool: create_or_update_entity_attribute
{
  "entityFqn": "com.example.domain.CartItem",
  "name": "product",
  "type": "Product",
  "relationshipProperties": {
    "relationship": "ManyToOne",
    "joinColumn": "product_id"
  }
}

// Add items to Cart
Tool: create_or_update_entity_attribute
{
  "entityFqn": "com.example.domain.Cart",
  "name": "items",
  "type": "List<CartItem>",
  "relationshipProperties": {
    "relationship": "OneToMany",
    "mappedBy": "cart",
    "cascade": "ALL",
    "orphanRemoval": true,
    "fetch": "LAZY"
  }
}
```

**Step 5: Create Repositories**

```
// CategoryRepository
Tool: create_spring_data_repository
{
  "repositoryClassName": "CategoryRepository",
  "entityName": "Category",
  "projectPath": "/Users/dev/shop"
}

// ProductRepository
Tool: create_spring_data_repository
{
  "repositoryClassName": "ProductRepository",
  "entityName": "Product",
  "projectPath": "/Users/dev/shop"
}

// CartRepository
Tool: create_spring_data_repository
{
  "repositoryClassName": "CartRepository",
  "entityName": "Cart",
  "projectPath": "/Users/dev/shop"
}

// CartItemRepository (optional, managed through Cart)
Tool: create_spring_data_repository
{
  "repositoryClassName": "CartItemRepository",
  "entityName": "CartItem",
  "projectPath": "/Users/dev/shop"
}
```

**Domain Model Summary:**

```
User (1) ←→ (1) Cart
                 ↓
             CartItem (Many)
                 ↓
             Product (Many)
                 ↓
             Category (1)
```

---

## Example 4: Inheritance Hierarchy

### Scenario
Create a payment system with different payment types: CreditCard, PayPal, BankTransfer.

### Implementation

**Step 1: Create base Payment entity**

```
Tool: create_jpa_entity
{
  "entityName": "Payment",
  "entityPackage": "com.example.domain",
  "projectPath": "/Users/dev/myapp",
  "inheritanceType": "SINGLE_TABLE",
  "discriminatorColumn": "payment_type",
  "discriminatorType": "STRING",
  "attributes": [
    {
      "name": "id",
      "type": "Long",
      "isId": true,
      "idGenerationProperties": {"generatedStrategy": "IDENTITY"}
    },
    {
      "name": "amount",
      "type": "BigDecimal",
      "isId": false,
      "columnProperties": {"precision": 19, "scale": 2, "nullable": false}
    },
    {
      "name": "paymentDate",
      "type": "LocalDateTime",
      "isId": false,
      "columnProperties": {"nullable": false}
    },
    {
      "name": "status",
      "type": "String",
      "isId": false,
      "columnProperties": {"length": 20, "nullable": false}
    }
  ]
}
```

**Step 2: Create CreditCard subclass**

```
Tool: create_jpa_entity
{
  "entityName": "CreditCardPayment",
  "entityPackage": "com.example.domain",
  "projectPath": "/Users/dev/myapp",
  "superclass": "Payment",
  "discriminatorValue": "CREDIT_CARD",
  "attributes": [
    {
      "name": "cardNumber",
      "type": "String",
      "isId": false,
      "columnProperties": {"length": 19}
    },
    {
      "name": "cardHolderName",
      "type": "String",
      "isId": false,
      "columnProperties": {"length": 100}
    },
    {
      "name": "expiryDate",
      "type": "String",
      "isId": false,
      "columnProperties": {"length": 5}
    }
  ]
}
```

**Step 3: Create PayPal subclass**

```
Tool: create_jpa_entity
{
  "entityName": "PayPalPayment",
  "entityPackage": "com.example.domain",
  "projectPath": "/Users/dev/myapp",
  "superclass": "Payment",
  "discriminatorValue": "PAYPAL",
  "attributes": [
    {
      "name": "email",
      "type": "String",
      "isId": false,
      "columnProperties": {"length": 100}
    },
    {
      "name": "transactionId",
      "type": "String",
      "isId": false,
      "columnProperties": {"length": 50}
    }
  ]
}
```

**Result:**

```java
@Entity
@Table(name = "payments")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "payment_type", discriminatorType = DiscriminatorType.STRING)
public abstract class Payment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(precision = 19, scale = 2, nullable = false)
    private BigDecimal amount;

    @Column(nullable = false)
    private LocalDateTime paymentDate;

    @Column(length = 20, nullable = false)
    private String status;
}

@Entity
@DiscriminatorValue("CREDIT_CARD")
public class CreditCardPayment extends Payment {
    @Column(length = 19)
    private String cardNumber;

    @Column(length = 100)
    private String cardHolderName;

    @Column(length = 5)
    private String expiryDate;
}

@Entity
@DiscriminatorValue("PAYPAL")
public class PayPalPayment extends Payment {
    @Column(length = 100)
    private String email;

    @Column(length = 50)
    private String transactionId;
}
```

**Database:**

```sql
CREATE TABLE payments (
    id BIGINT PRIMARY KEY,
    payment_type VARCHAR(31),  -- Discriminator
    amount DECIMAL(19,2),
    payment_date TIMESTAMP,
    status VARCHAR(20),
    -- CreditCard fields (nullable)
    card_number VARCHAR(19),
    card_holder_name VARCHAR(100),
    expiry_date VARCHAR(5),
    -- PayPal fields (nullable)
    email VARCHAR(100),
    transaction_id VARCHAR(50)
);
```

---

## Example 5: Composite Keys

### Scenario
Create a UserRole join table entity with composite key (userId, roleId) plus assignedDate.

### Implementation

**Step 1: Create UserRole with composite key**

```
Tool: create_jpa_entity
{
  "entityName": "UserRole",
  "entityPackage": "com.example.domain",
  "projectPath": "/Users/dev/myapp",
  "compositeId": true,
  "attributes": [
    {
      "name": "userId",
      "type": "Long",
      "isId": true
    },
    {
      "name": "roleId",
      "type": "Long",
      "isId": true
    },
    {
      "name": "assignedDate",
      "type": "LocalDateTime",
      "isId": false,
      "columnProperties": {"nullable": false, "updatable": false}
    }
  ]
}
```

**Step 2: Add entity relationships**

```
// Add user reference
Tool: create_or_update_entity_attribute
{
  "entityFqn": "com.example.domain.UserRole",
  "name": "user",
  "type": "User",
  "relationshipProperties": {
    "relationship": "ManyToOne",
    "joinColumn": "user_id"
  }
}

// Add role reference
Tool: create_or_update_entity_attribute
{
  "entityFqn": "com.example.domain.UserRole",
  "name": "role",
  "type": "Role",
  "relationshipProperties": {
    "relationship": "ManyToOne",
    "joinColumn": "role_id"
  }
}
```

**Result:**

```java
@Entity
@Table(name = "user_roles")
public class UserRole {
    @Id
    private Long userId;

    @Id
    private Long roleId;

    @ManyToOne
    @JoinColumn(name = "user_id", insertable = false, updatable = false)
    private User user;

    @ManyToOne
    @JoinColumn(name = "role_id", insertable = false, updatable = false)
    private Role role;

    @Column(nullable = false, updatable = false)
    private LocalDateTime assignedDate;
}
```

---

## Example 6: Audit Entity Pattern

### Scenario
Create entities with audit fields (createdAt, updatedAt, createdBy, updatedBy).

### Implementation

**Step 1: Create base audit entity (MappedSuperclass)**

```
Tool: create_jpa_entity
{
  "entityName": "AuditableEntity",
  "entityPackage": "com.example.domain.base",
  "projectPath": "/Users/dev/myapp",
  "mappedSuperclass": true,
  "attributes": [
    {
      "name": "createdAt",
      "type": "LocalDateTime",
      "isId": false,
      "columnProperties": {"nullable": false, "updatable": false}
    },
    {
      "name": "updatedAt",
      "type": "LocalDateTime",
      "isId": false
    },
    {
      "name": "createdBy",
      "type": "String",
      "isId": false,
      "columnProperties": {"length": 50, "updatable": false}
    },
    {
      "name": "updatedBy",
      "type": "String",
      "isId": false,
      "columnProperties": {"length": 50}
    }
  ]
}
```

**Step 2: Create entity extending audit base**

```
Tool: create_jpa_entity
{
  "entityName": "Product",
  "entityPackage": "com.example.domain",
  "projectPath": "/Users/dev/myapp",
  "superclass": "AuditableEntity",
  "attributes": [
    {
      "name": "id",
      "type": "Long",
      "isId": true,
      "idGenerationProperties": {"generatedStrategy": "IDENTITY"}
    },
    {
      "name": "name",
      "type": "String",
      "isId": false,
      "columnProperties": {"nullable": false}
    },
    {
      "name": "price",
      "type": "BigDecimal",
      "isId": false,
      "columnProperties": {"precision": 19, "scale": 2}
    }
  ]
}
```

**Result:**

```java
@MappedSuperclass
public abstract class AuditableEntity {
    @Column(nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column
    private LocalDateTime updatedAt;

    @Column(length = 50, updatable = false)
    private String createdBy;

    @Column(length = 50)
    private String updatedBy;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
}

@Entity
public class Product extends AuditableEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    @Column(precision = 19, scale = 2)
    private BigDecimal price;
}
```

---

## Key Takeaways

1. **Start Simple:** Create basic entity first, add relationships later
2. **Relationships:** Always configure both sides for bidirectional
3. **Cascade:** Use carefully - ALL for composition, specific for others
4. **Fetch:** Default to LAZY for collections
5. **Verification:** Always verify with exploration tools after creation
6. **Repository:** Create after entity is complete
7. **Audit Fields:** Use @MappedSuperclass for common fields
8. **Composite Keys:** Require careful planning, consider alternatives

---

## Common Workflows

**New Entity:**
1. Create entity with basic attributes
2. Add relationships
3. Create repository
4. Verify with exploration tools

**Existing Entity Modification:**
1. Explore current structure
2. Add/modify attributes
3. Update related entities
4. Verify changes

**Complete Domain:**
1. Design entity diagram
2. Create entities one by one
3. Add relationships step by step
4. Create repositories for all
5. Verify complete structure
