# Tool Reference - JPA Implementation

Comprehensive documentation for all implementation tools.

## create_jpa_entity

### Purpose
Create complete JPA entities with Spring Data integration including @Entity annotation, primary keys, database table mappings, and persistence annotations.

### When to Use
- Creating new domain entities
- Establishing new entity hierarchies
- Implementing complex data structures
- Creating join table entities
- Building composite key entities

### Full Parameter Reference

#### entityName (required)
- **Type:** String
- **Description:** Entity class name
- **Examples:** `"User"`, `"Product"`, `"OrderItem"`
- **Conventions:**
  - Use PascalCase (capital first letter)
  - Singular noun (User, not Users)
  - Meaningful business domain name
  - Avoid technical suffixes (Entity, Model)

#### entityPackage (optional)
- **Type:** String
- **Description:** Target package for entity
- **Examples:**
  - `"com.example.domain"`
  - `"com.myapp.entities"`
  - `"persistence.model"`
- **Auto-detection:** If omitted, tool detects from:
  - Existing entities location
  - Project structure
  - Prompts user if ambiguous

#### language (optional)
- **Type:** Enum ["Java", "Kotlin"]
- **Default:** Java
- **Description:** Programming language for entity
- **When to specify:** Kotlin projects or mixed Java/Kotlin

#### moduleName (optional)
- **Type:** String
- **Description:** Target module for multi-module projects
- **Examples:** `"domain-module"`, `"core-service"`
- **When to use:** Multi-module Spring Boot projects

#### tableName (optional)
- **Type:** String
- **Description:** Database table name
- **Examples:** `"users"`, `"product_catalog"`, `"order_items"`
- **Auto-generation:** If omitted:
  - Uses naming strategy (usually camelCase → snake_case)
  - User → users
  - OrderItem → order_items

#### attributes (optional)
- **Type:** Array of attribute objects
- **Description:** Entity fields with JPA annotations
- **Structure:** See "Attribute Configuration" section below

#### inheritanceType (optional)
- **Type:** String
- **Values:** "SINGLE_TABLE", "JOINED", "TABLE_PER_CLASS"
- **Description:** JPA inheritance strategy
- **Use with:** Entity hierarchies

#### discriminatorColumn (optional)
- **Type:** String
- **Description:** Column name for inheritance discrimination
- **Examples:** `"entity_type"`, `"dtype"`, `"user_type"`
- **Use with:** SINGLE_TABLE or JOINED inheritance

#### discriminatorType (optional)
- **Type:** String
- **Values:** "STRING", "CHAR", "INTEGER"
- **Default:** STRING
- **Description:** Type of discriminator value

#### discriminatorValue (optional)
- **Type:** String
- **Description:** Discriminator value for this specific entity
- **Examples:** `"CUSTOMER"`, `"ADMIN"`, `"PREMIUM"`
- **Use with:** Subclasses in inheritance hierarchy

#### superclass (optional)
- **Type:** String
- **Description:** Parent entity class name
- **Examples:** `"BaseEntity"`, `"AbstractUser"`
- **Use with:** Entity inheritance

#### mappedSuperclass (optional)
- **Type:** Boolean
- **Default:** false
- **Description:** Mark as @MappedSuperclass instead of @Entity
- **Use for:** Base classes with common fields (not entities themselves)

#### compositeId (optional)
- **Type:** Boolean
- **Default:** false
- **Description:** Use composite primary key
- **Use for:** Multi-column primary keys

#### indexes (optional)
- **Type:** Array of index objects
- **Description:** Database indexes for performance
- **Structure:**
  ```json
  {
    "name": "idx_user_email",
    "columnList": ["email"],
    "unique": true,
    "constraint": false
  }
  ```

#### namedQueries (optional)
- **Type:** Array of named query objects
- **Description:** Predefined JPQL queries
- **Structure:**
  ```json
  {
    "name": "User.findByEmail",
    "query": "SELECT u FROM User u WHERE u.email = :email"
  }
  ```

#### projectPath (recommended)
- **Type:** String
- **Description:** Project root path
- **Important:** ALWAYS pass if known - reduces ambiguous calls

---

## Attribute Configuration

### Basic Attribute Structure

```json
{
  "name": "attributeName",
  "type": "String",
  "isId": false,
  "column": "column_name",
  "columnProperties": {},
  "idGenerationProperties": {},
  "relationshipProperties": {},
  "collectionProperties": {},
  "embeddedProperties": {}
}
```

### Required Attribute Fields

#### name (required)
- **Type:** String
- **Description:** Field/attribute name
- **Examples:** `"firstName"`, `"email"`, `"createdAt"`
- **Convention:** camelCase

#### type (required)
- **Type:** String
- **Description:** Java/Kotlin type
- **Examples:**
  - Primitives/Wrappers: `"String"`, `"Long"`, `"Integer"`, `"Boolean"`
  - Dates: `"LocalDateTime"`, `"LocalDate"`, `"Date"`, `"Instant"`
  - Decimals: `"BigDecimal"`, `"Double"`
  - Collections: `"List<Order>"`, `"Set<Role>"`, `"Map<String, String>"`
  - Entities: `"User"`, `"Category"`, `"com.example.Product"`

#### isId (required)
- **Type:** Boolean
- **Description:** Mark as primary key
- **Values:**
  - `true` - Primary key field
  - `false` - Regular field

### Optional Attribute Fields

#### column (optional)
- **Type:** String
- **Description:** Database column name
- **Examples:** `"first_name"`, `"created_at"`, `"user_id"`
- **Auto-generation:** If omitted, uses naming strategy

---

### columnProperties Object

Configuration for database column characteristics.

```json
{
  "nullable": true/false,
  "length": 255,
  "unique": true/false,
  "columnDefinition": "VARCHAR(100)",
  "precision": 19,
  "scale": 2,
  "insertable": true/false,
  "updatable": true/false,
  "lob": true/false,
  "temporal": "DATE"/"TIME"/"TIMESTAMP",
  "version": true/false
}
```

#### nullable
- **Type:** Boolean
- **Default:** true
- **Description:** Can column be NULL?
- **Example:** `"nullable": false` for required fields

#### length
- **Type:** Integer
- **Default:** 255 (for strings)
- **Description:** Maximum string length
- **Example:** `"length": 100` for shorter strings

#### unique
- **Type:** Boolean
- **Default:** false
- **Description:** Unique constraint
- **Example:** `"unique": true` for email, username

#### columnDefinition
- **Type:** String
- **Description:** Custom SQL column definition
- **Example:** `"columnDefinition": "TEXT"` for large strings

#### precision
- **Type:** Integer
- **Description:** Total digits (for decimals)
- **Example:** `"precision": 19` for money values

#### scale
- **Type:** Integer
- **Description:** Decimal places
- **Example:** `"scale": 2` for currency (19.2)

#### insertable
- **Type:** Boolean
- **Default:** true
- **Description:** Include in INSERT statements?
- **Example:** `"insertable": false` for read-only fields

#### updatable
- **Type:** Boolean
- **Default:** true
- **Description:** Include in UPDATE statements?
- **Example:** `"updatable": false` for immutable fields

#### lob
- **Type:** Boolean
- **Default:** false
- **Description:** Large object (CLOB/BLOB)
- **Example:** `"lob": true` for large text or binary data

#### temporal
- **Type:** String
- **Values:** "DATE", "TIME", "TIMESTAMP"
- **Description:** How to map Date/Calendar
- **Example:** `"temporal": "TIMESTAMP"` for Date fields

#### version
- **Type:** Boolean
- **Default:** false
- **Description:** Optimistic locking version field
- **Example:** `"version": true` for version column

---

### idGenerationProperties Object

Configuration for primary key generation.

```json
{
  "generatedStrategy": "IDENTITY",
  "sequenceName": "user_seq",
  "initialValue": 1,
  "allocationSize": 50,
  "generatorName": "user_gen",
  "pkColumnName": "pk_column",
  "valueColumnName": "pk_value"
}
```

#### generatedStrategy (required for IDs)
- **Type:** Enum
- **Values:**
  - `"AUTO"` - Let JPA choose
  - `"IDENTITY"` - Database auto-increment (MySQL, PostgreSQL)
  - `"SEQUENCE"` - Database sequence (Oracle, PostgreSQL)
  - `"TABLE"` - Separate ID table
  - `"UUID"` - Generate UUID
- **Recommendations:**
  - MySQL/MariaDB: IDENTITY
  - PostgreSQL: IDENTITY or SEQUENCE
  - Oracle: SEQUENCE
  - Cross-database: UUID or TABLE

#### sequenceName (for SEQUENCE)
- **Type:** String
- **Description:** Database sequence name
- **Example:** `"sequenceName": "user_id_seq"`

#### initialValue (for SEQUENCE)
- **Type:** Integer
- **Default:** 1
- **Description:** Starting value for sequence

#### allocationSize (for SEQUENCE)
- **Type:** Integer
- **Default:** 50
- **Description:** How many IDs to pre-allocate

#### generatorName (for TABLE)
- **Type:** String
- **Description:** Name of ID generator

#### pkColumnName (for TABLE)
- **Type:** String
- **Description:** Column name in ID table

#### valueColumnName (for TABLE)
- **Type:** String
- **Description:** Value column in ID table

---

### relationshipProperties Object

Configuration for entity relationships.

```json
{
  "relationship": "OneToMany",
  "joinColumn": "user_id",
  "mappedBy": "user",
  "cascade": "ALL",
  "fetch": "LAZY",
  "orphanRemoval": true,
  "joinTable": "user_roles",
  "inverseJoinColumn": "role_id"
}
```

#### relationship (required for relationships)
- **Type:** Enum
- **Values:**
  - `"OneToOne"` - 1:1 relationship
  - `"OneToMany"` - 1:N relationship
  - `"ManyToOne"` - N:1 relationship
  - `"ManyToMany"` - N:M relationship

#### joinColumn (for owning side)
- **Type:** String
- **Description:** Foreign key column name
- **Example:** `"joinColumn": "user_id"`
- **Use with:** ManyToOne, OneToOne (owning), ManyToMany

#### mappedBy (for inverse side)
- **Type:** String
- **Description:** Field name on owning side
- **Example:** `"mappedBy": "user"`
- **Use with:** OneToMany, OneToOne (inverse), ManyToMany (inverse)

#### cascade
- **Type:** String
- **Values:**
  - `"ALL"` - All operations cascade
  - `"PERSIST"` - Only persist
  - `"MERGE"` - Only merge
  - `"REMOVE"` - Only remove
  - `"REFRESH"` - Only refresh
  - `"DETACH"` - Only detach
  - Combination: `"PERSIST, MERGE"`
- **Recommendations:**
  - Parent-child: ALL or "PERSIST, MERGE"
  - Independent entities: NONE
  - Be careful with REMOVE

#### fetch
- **Type:** Enum
- **Values:**
  - `"LAZY"` - Load when accessed
  - `"EAGER"` - Load immediately
- **Defaults:**
  - OneToMany: LAZY
  - ManyToOne: EAGER
  - ManyToMany: LAZY
  - OneToOne: EAGER
- **Recommendations:**
  - Collections (OneToMany, ManyToMany): Always LAZY
  - ManyToOne: LAZY (unless always needed)
  - OneToOne: Depends on usage

#### orphanRemoval (for OneToMany, OneToOne)
- **Type:** Boolean
- **Default:** false
- **Description:** Delete child when removed from parent
- **Example:** `"orphanRemoval": true` for composition

#### joinTable (for ManyToMany)
- **Type:** String
- **Description:** Join table name
- **Example:** `"joinTable": "user_roles"`

#### inverseJoinColumn (for ManyToMany)
- **Type:** String
- **Description:** Other side's join column
- **Example:** `"inverseJoinColumn": "role_id"`

---

### collectionProperties Object

Configuration for element collections.

```json
{
  "elementCollection": true,
  "collectionTable": "user_phone_numbers"
}
```

#### elementCollection
- **Type:** Boolean
- **Description:** Mark as @ElementCollection
- **Use for:** Collections of basic types or embeddables

#### collectionTable
- **Type:** String
- **Description:** Collection table name
- **Example:** `"collectionTable": "user_phone_numbers"`

---

### embeddedProperties Object

Configuration for embedded objects.

```json
{
  "embedded": true,
  "attributeOverrides": [
    {
      "attributeName": "street",
      "column": "addr_street"
    }
  ]
}
```

#### embedded
- **Type:** Boolean
- **Description:** Mark as @Embedded
- **Use for:** Value objects

#### attributeOverrides
- **Type:** Array of override objects
- **Description:** Customize embedded column names
- **Structure:**
  ```json
  {
    "attributeName": "fieldInEmbeddable",
    "column": "column_in_entity_table"
  }
  ```

---

## create_or_update_entity_attribute

### Purpose
Add new attributes or modify existing ones in JPA entities.

### Parameters

Same as attribute configuration in `create_jpa_entity`, plus:

#### entityFqn (required)
- **Type:** String
- **Description:** Full qualified name of target entity
- **Examples:**
  - `"com.example.domain.User"`
  - `"com.myapp.entities.Product"`
- **Format:** Must be full package + class name

---

## delete_entity_attribute

### Purpose
Remove attributes from JPA entities.

### Parameters

#### entityFqn (required)
- **Type:** String
- **Description:** Full qualified name of target entity
- **Example:** `"com.example.domain.User"`

#### name (required)
- **Type:** String
- **Description:** Attribute name to remove
- **Example:** `"deprecatedField"`

#### projectPath (recommended)
- **Type:** String
- **Description:** Project root path

### Use Cases
- Removing deprecated fields
- Cleaning up unused relationships
- Refactoring entity structure
- Database schema evolution

---

## create_spring_data_repository

### Purpose
Generate Spring Data JPA repository interfaces.

### Parameters

#### repositoryClassName (required)
- **Type:** String
- **Description:** Repository interface name
- **Examples:**
  - `"UserRepository"`
  - `"ProductRepository"`
  - `"OrderItemRepository"`
- **Convention:** `{Entity}Repository`

#### entityName (required)
- **Type:** String
- **Description:** Target entity name or FQN
- **Examples:**
  - `"User"` (if unique)
  - `"com.example.domain.Product"` (if ambiguous)

#### packageName (optional)
- **Type:** String
- **Description:** Repository package location
- **Examples:**
  - `"com.example.repository"`
  - `"com.myapp.data.repositories"`
- **Auto-detection:** If omitted:
  - Detects from entity package
  - Follows existing repository structure
  - Prompts if ambiguous

#### sourceRootType (optional)
- **Type:** String
- **Values:** "source", "test"
- **Default:** "source"
- **Description:** Create in main or test source root

#### moduleName (optional)
- **Type:** String
- **Description:** Target module (multi-module projects)
- **Example:** `"data-module"`

#### baseRepositoryClass (optional)
- **Type:** String
- **Values:**
  - `"JpaRepository"` (most common)
  - `"CrudRepository"` (basic CRUD)
  - `"PagingAndSortingRepository"` (with pagination)
  - `"ListCrudRepository"` (returns List instead of Iterable)
- **Default:** Follows project convention or JpaRepository
- **Description:** Base interface to extend

#### projectPath (recommended)
- **Type:** String
- **Description:** Project root path

---

## Return Values

### create_jpa_entity

Returns:
```json
{
  "status": "Success" | "Ask user" | "Failure",
  "message": "Entity created successfully",
  "nextSuggestedActions": "Create repository for User entity",
  "resultFiles": [
    {
      "name": "User.java",
      "path": "/src/main/java/com/example/domain/User.java",
      "content": "package com.example.domain...",
      "description": "User entity with basic fields"
    }
  ]
}
```

### create_or_update_entity_attribute

Returns same structure as `create_jpa_entity`

### delete_entity_attribute

Returns:
```json
{
  "name": "User.java",
  "path": "/src/main/java/com/example/domain/User.java",
  "content": "Updated entity content...",
  "description": "Removed attribute from User"
}
```

### create_spring_data_repository

Returns:
```json
{
  "file": {
    "name": "UserRepository.java",
    "path": "/src/main/java/com/example/repository/UserRepository.java",
    "content": "package com.example.repository...",
    "entity": "User",
    "description": "Repository for User entity"
  }
}
```

---

## Error Handling

### Status: "Ask user"
Tool needs clarification:
- Ambiguous entity name (multiple matches)
- Unclear package selection
- Module selection needed
- Confirmation required

**Response:** Provide requested information and retry

### Status: "Failure"
Operation failed:
- Entity not found
- Invalid configuration
- Project structure issues
- Compilation errors

**Response:** Check error message, fix issue, retry

---

## Best Practices

1. **Always pass projectPath**
   - Reduces ambiguity
   - Speeds up execution
   - More accurate results

2. **Use exploration first**
   - Check if entity exists
   - Understand conventions
   - Analyze related entities

3. **Follow naming conventions**
   - Entity: PascalCase singular nouns
   - Attributes: camelCase
   - Tables: snake_case
   - Columns: snake_case

4. **Relationship guidelines**
   - Always configure both sides
   - Use LAZY for collections
   - Be careful with CASCADE
   - Set proper owning side

5. **ID generation**
   - IDENTITY for MySQL/PostgreSQL
   - SEQUENCE for Oracle
   - UUID for distributed systems

6. **Verify after creation**
   - Use exploration tools
   - Check generated files
   - Test compilation
