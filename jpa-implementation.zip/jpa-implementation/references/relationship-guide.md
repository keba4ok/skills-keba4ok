# Entity Relationship Guide

Complete guide to implementing JPA entity relationships with concrete examples and best practices.

## Table of Contents

1. [Relationship Types Overview](#relationship-types-overview)
2. [OneToMany / ManyToOne](#onetomany--manytoone)
3. [ManyToMany](#manytomany)
4. [OneToOne](#onetoone)
5. [Bidirectional vs Unidirectional](#bidirectional-vs-unidirectional)
6. [Cascade Operations](#cascade-operations)
7. [Fetch Strategies](#fetch-strategies)
8. [Common Patterns](#common-patterns)
9. [Troubleshooting](#troubleshooting)

---

## Relationship Types Overview

| Relationship | Description | Example |
|--------------|-------------|---------|
| **OneToMany** | One entity has many related entities | User → Orders |
| **ManyToOne** | Many entities reference one entity | Order → User |
| **ManyToMany** | Many entities relate to many entities | Users ←→ Roles |
| **OneToOne** | One entity relates to exactly one other | User ←→ UserProfile |

### Key Concepts

**Owning Side:**
- Contains the foreign key (database level)
- Has `@JoinColumn` annotation
- Controls the relationship

**Inverse Side:**
- Doesn't have foreign key
- Has `mappedBy` attribute
- References the field on owning side

---

## OneToMany / ManyToOne

### Pattern: Parent-Child Relationship

Most common relationship type. Parent has many children, each child has one parent.

**Example: User and Orders**

```
User (Parent - One side)
  ↓ has many
Orders (Child - Many side) ← Owning side (has FK)
```

---

### Step 1: Create Parent Entity (User)

```
Tool: create_jpa_entity or create_or_update_entity_attribute

{
  "entityFqn": "com.example.User",
  "name": "orders",
  "type": "List<Order>",
  "isId": false,
  "relationshipProperties": {
    "relationship": "OneToMany",
    "mappedBy": "user",
    "fetch": "LAZY",
    "cascade": "ALL",
    "orphanRemoval": true
  }
}
```

**Generated Java:**
```java
@Entity
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToMany(mappedBy = "user",
               fetch = FetchType.LAZY,
               cascade = CascadeType.ALL,
               orphanRemoval = true)
    private List<Order> orders = new ArrayList<>();
}
```

**Key Points:**
- `mappedBy = "user"` - References `user` field in Order
- This is the **inverse side** (no FK here)
- Uses `List<Order>` - collection type
- `orphanRemoval = true` - Delete order when removed from user

---

### Step 2: Create Child Entity (Order)

```
Tool: create_or_update_entity_attribute

{
  "entityFqn": "com.example.Order",
  "name": "user",
  "type": "User",
  "isId": false,
  "relationshipProperties": {
    "relationship": "ManyToOne",
    "joinColumn": "user_id",
    "fetch": "LAZY"
  },
  "columnProperties": {
    "nullable": false
  }
}
```

**Generated Java:**
```java
@Entity
@Table(name = "orders")
public class Order {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;
}
```

**Key Points:**
- `@JoinColumn(name = "user_id")` - Foreign key column
- This is the **owning side** (has FK)
- Uses single `User` - not a collection
- `nullable = false` - Order must have a user

---

### Database Structure

```sql
-- users table
CREATE TABLE users (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(255),
    email VARCHAR(255)
);

-- orders table
CREATE TABLE orders (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    order_date TIMESTAMP,
    total_amount DECIMAL(19,2),
    user_id BIGINT NOT NULL,  ← Foreign key
    FOREIGN KEY (user_id) REFERENCES users(id)
);
```

---

### Variations

#### 1. Without Cascade (Independent Deletion)

```json
{
  "name": "orders",
  "type": "List<Order>",
  "relationshipProperties": {
    "relationship": "OneToMany",
    "mappedBy": "user",
    "fetch": "LAZY"
    // No cascade - orders persist when user deleted
  }
}
```

**Use when:** Orders should remain even if user deleted

---

#### 2. With Specific Cascades

```json
{
  "name": "orders",
  "type": "List<Order>",
  "relationshipProperties": {
    "relationship": "OneToMany",
    "mappedBy": "user",
    "fetch": "LAZY",
    "cascade": "PERSIST, MERGE"
    // Only persist and merge cascade
  }
}
```

**Use when:** Want to save/update together, but not delete together

---

#### 3. Unidirectional OneToMany

Only parent knows about children (rare pattern).

```json
{
  "name": "orders",
  "type": "List<Order>",
  "relationshipProperties": {
    "relationship": "OneToMany",
    "joinColumn": "user_id",  ← joinColumn instead of mappedBy
    "fetch": "LAZY"
  }
}
```

**Note:** No `user` field in Order entity. Less efficient, rarely used.

---

## ManyToMany

### Pattern: Users and Roles

Many users can have many roles, and many roles can be assigned to many users.

```
Users ←→ Roles
```

Requires a **join table** to store the relationships.

---

### Step 1: Create Owning Side (User)

```
Tool: create_or_update_entity_attribute

{
  "entityFqn": "com.example.User",
  "name": "roles",
  "type": "Set<Role>",
  "isId": false,
  "relationshipProperties": {
    "relationship": "ManyToMany",
    "joinTable": "user_roles",
    "joinColumn": "user_id",
    "inverseJoinColumn": "role_id",
    "fetch": "LAZY",
    "cascade": "PERSIST, MERGE"
  }
}
```

**Generated Java:**
```java
@Entity
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToMany(fetch = FetchType.LAZY,
                cascade = {CascadeType.PERSIST, CascadeType.MERGE})
    @JoinTable(
        name = "user_roles",
        joinColumns = @JoinColumn(name = "user_id"),
        inverseJoinColumns = @JoinColumn(name = "role_id")
    )
    private Set<Role> roles = new HashSet<>();
}
```

**Key Points:**
- Uses `Set<Role>` - prevents duplicates
- `@JoinTable` - Defines join table
- `joinColumns` - FK to User
- `inverseJoinColumns` - FK to Role
- This is the **owning side**

---

### Step 2: Create Inverse Side (Role)

```
Tool: create_or_update_entity_attribute

{
  "entityFqn": "com.example.Role",
  "name": "users",
  "type": "Set<User>",
  "isId": false,
  "relationshipProperties": {
    "relationship": "ManyToMany",
    "mappedBy": "roles",
    "fetch": "LAZY"
  }
}
```

**Generated Java:**
```java
@Entity
public class Role {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToMany(mappedBy = "roles", fetch = FetchType.LAZY)
    private Set<User> users = new HashSet<>();
}
```

**Key Points:**
- `mappedBy = "roles"` - References `roles` field in User
- This is the **inverse side**
- No `@JoinTable` here

---

### Database Structure

```sql
-- users table
CREATE TABLE users (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(255)
);

-- roles table
CREATE TABLE roles (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(50)
);

-- join table
CREATE TABLE user_roles (
    user_id BIGINT,
    role_id BIGINT,
    PRIMARY KEY (user_id, role_id),
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (role_id) REFERENCES roles(id)
);
```

---

### ManyToMany with Extra Columns

**Problem:** Standard `@ManyToMany` can't have extra fields in join table.

**Solution:** Create explicit join entity.

**Example: User-Role with assigned date**

#### Step 1: Create Join Entity

```
Tool: create_jpa_entity

{
  "entityName": "UserRole",
  "compositeId": true,
  "attributes": [
    {
      "name": "userId",
      "type": "Long",
      "isId": true
    },
    {
      "name": "roleId",
      "type": "Long",
      "isId": true
    },
    {
      "name": "assignedDate",
      "type": "LocalDateTime",
      "isId": false,
      "columnProperties": {
        "nullable": false
      }
    }
  ]
}
```

Then add relationships:

```
// Add user field to UserRole
{
  "entityFqn": "com.example.UserRole",
  "name": "user",
  "type": "User",
  "relationshipProperties": {
    "relationship": "ManyToOne",
    "joinColumn": "user_id"
  }
}

// Add role field to UserRole
{
  "entityFqn": "com.example.UserRole",
  "name": "role",
  "type": "Role",
  "relationshipProperties": {
    "relationship": "ManyToOne",
    "joinColumn": "role_id"
  }
}
```

#### Step 2: Update User and Role

```
// In User
{
  "name": "userRoles",
  "type": "List<UserRole>",
  "relationshipProperties": {
    "relationship": "OneToMany",
    "mappedBy": "user"
  }
}

// In Role
{
  "name": "userRoles",
  "type": "List<UserRole>",
  "relationshipProperties": {
    "relationship": "OneToMany",
    "mappedBy": "role"
  }
}
```

**Result:** Three entities managing many-to-many with extra data.

---

## OneToOne

### Pattern: User and UserProfile

One user has exactly one profile, and each profile belongs to one user.

```
User ←→ UserProfile
```

---

### Approach 1: Unidirectional (User → Profile)

Only User knows about Profile.

```
Tool: create_or_update_entity_attribute

{
  "entityFqn": "com.example.User",
  "name": "profile",
  "type": "UserProfile",
  "isId": false,
  "relationshipProperties": {
    "relationship": "OneToOne",
    "joinColumn": "profile_id",
    "fetch": "LAZY",
    "cascade": "ALL",
    "orphanRemoval": true
  }
}
```

**Generated:**
```java
@Entity
public class User {
    @Id
    private Long id;

    @OneToOne(fetch = FetchType.LAZY,
              cascade = CascadeType.ALL,
              orphanRemoval = true)
    @JoinColumn(name = "profile_id", unique = true)
    private UserProfile profile;
}
```

**Database:** FK `profile_id` in `users` table

**No field in UserProfile entity**

---

### Approach 2: Bidirectional (User ←→ Profile)

Both know about each other.

#### Step 1: User (Owning Side)

```json
{
  "entityFqn": "com.example.User",
  "name": "profile",
  "type": "UserProfile",
  "relationshipProperties": {
    "relationship": "OneToOne",
    "joinColumn": "profile_id",
    "fetch": "LAZY",
    "cascade": "ALL"
  }
}
```

#### Step 2: UserProfile (Inverse Side)

```json
{
  "entityFqn": "com.example.UserProfile",
  "name": "user",
  "type": "User",
  "relationshipProperties": {
    "relationship": "OneToOne",
    "mappedBy": "profile",
    "fetch": "LAZY"
  }
}
```

**Generated:**
```java
@Entity
public class User {
    @OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    @JoinColumn(name = "profile_id", unique = true)
    private UserProfile profile;
}

@Entity
public class UserProfile {
    @OneToOne(mappedBy = "profile", fetch = FetchType.LAZY)
    private User user;
}
```

---

### Approach 3: Shared Primary Key

Profile uses User's ID as its primary key.

```java
@Entity
public class UserProfile {
    @Id
    private Long id;  // Same value as User.id

    @OneToOne
    @MapsId
    @JoinColumn(name = "id")
    private User user;
}
```

**Note:** Requires manual configuration (not fully supported by tool yet)

---

## Bidirectional vs Unidirectional

### Bidirectional Relationship

Both sides know about each other.

**Advantages:**
- Navigate from either side
- Convenient queries from both directions
- Complete object graph

**Disadvantages:**
- More complex to maintain
- Both entities coupled
- Must keep both sides in sync

**When to use:**
- Need navigation from both sides
- Strongly coupled entities
- Complex queries from both directions

---

### Unidirectional Relationship

Only one side knows about the other.

**Advantages:**
- Simpler
- Less coupling
- Easier to maintain

**Disadvantages:**
- Can only navigate one direction
- Harder to query from other side

**When to use:**
- Clear ownership
- Only need one-way navigation
- Independent entities

---

## Cascade Operations

Controls whether operations on parent propagate to children.

### CascadeType Values

| Type | Effect |
|------|--------|
| **PERSIST** | When saving parent, save children |
| **MERGE** | When updating parent, update children |
| **REMOVE** | When deleting parent, delete children |
| **REFRESH** | When refreshing parent, refresh children |
| **DETACH** | When detaching parent, detach children |
| **ALL** | All of the above |

### Examples

#### No Cascade (Independent)

```json
{
  "relationshipProperties": {
    "relationship": "ManyToOne",
    "joinColumn": "category_id"
    // No cascade
  }
}
```

**Effect:** Deleting Category doesn't delete Products.

---

#### Cascade ALL (Full Propagation)

```json
{
  "relationshipProperties": {
    "relationship": "OneToMany",
    "mappedBy": "order",
    "cascade": "ALL",
    "orphanRemoval": true
  }
}
```

**Effect:**
- Save Order → Save OrderItems
- Update Order → Update OrderItems
- Delete Order → Delete OrderItems
- Remove item from collection → Delete from DB (orphanRemoval)

---

#### Cascade PERSIST and MERGE (Safe)

```json
{
  "relationshipProperties": {
    "relationship": "OneToMany",
    "mappedBy": "user",
    "cascade": "PERSIST, MERGE"
  }
}
```

**Effect:**
- Save User → Save Orders
- Update User → Update Orders
- Delete User → Orders NOT deleted (must delete manually)

---

### Guidelines

**Use CASCADE.ALL when:**
- True composition (part-of relationship)
- Children can't exist without parent
- Example: Order → OrderItems

**Use CASCADE.PERSIST, MERGE when:**
- Want to save/update together
- But allow independent deletion
- Example: User → Orders (keep orders if user deleted)

**Use NO CASCADE when:**
- Independent entities
- Example: Product → Category

---

## Fetch Strategies

### LAZY vs EAGER

| Strategy | Behavior | Use Case |
|----------|----------|----------|
| **LAZY** | Load on access | Collections, optional data |
| **EAGER** | Load immediately | Always-needed data |

### Default Fetch Types

- `@OneToMany`: LAZY
- `@ManyToOne`: EAGER
- `@ManyToMany`: LAZY
- `@OneToOne`: EAGER

### Recommendations

**Always LAZY for:**
- Collections (OneToMany, ManyToMany)
- Large data
- Optional relationships

**Consider LAZY for:**
- ManyToOne (unless always needed)
- OneToOne (unless always needed)

**EAGER only when:**
- Data always used together
- Small data size
- No performance impact

---

### Solving LAZY Problems

#### Problem: LazyInitializationException

```
Exception: failed to lazily initialize a collection of role: User.orders
```

**Solutions:**

**1. @Transactional**
```java
@Transactional
public User getUserWithOrders(Long id) {
    User user = userRepository.findById(id).orElse(null);
    user.getOrders().size(); // Initialize within transaction
    return user;
}
```

**2. JOIN FETCH**
```java
@Query("SELECT u FROM User u JOIN FETCH u.orders WHERE u.id = :id")
User findByIdWithOrders(@Param("id") Long id);
```

**3. EntityGraph**
```java
@EntityGraph(attributePaths = {"orders"})
User findById(Long id);
```

---

## Common Patterns

### Pattern 1: Parent-Child with Composition

**Scenario:** Order has OrderItems. Items can't exist without Order.

```json
// Order entity
{
  "name": "items",
  "type": "List<OrderItem>",
  "relationshipProperties": {
    "relationship": "OneToMany",
    "mappedBy": "order",
    "cascade": "ALL",
    "orphanRemoval": true,
    "fetch": "LAZY"
  }
}

// OrderItem entity
{
  "name": "order",
  "type": "Order",
  "relationshipProperties": {
    "relationship": "ManyToOne",
    "joinColumn": "order_id"
  },
  "columnProperties": {
    "nullable": false
  }
}
```

**Characteristics:**
- CASCADE.ALL
- orphanRemoval = true
- nullable = false on child

---

### Pattern 2: Aggregation (Weak Relationship)

**Scenario:** Product belongs to Category. Category can exist without Products.

```json
// Category entity
{
  "name": "products",
  "type": "List<Product>",
  "relationshipProperties": {
    "relationship": "OneToMany",
    "mappedBy": "category",
    "fetch": "LAZY"
    // No cascade
  }
}

// Product entity
{
  "name": "category",
  "type": "Category",
  "relationshipProperties": {
    "relationship": "ManyToOne",
    "joinColumn": "category_id",
    "fetch": "LAZY"
  }
}
```

**Characteristics:**
- No cascade
- Both can exist independently
- LAZY fetch

---

### Pattern 3: Self-Referencing

**Scenario:** Employee has manager (also an Employee).

```json
// Manager (OneToMany)
{
  "name": "subordinates",
  "type": "List<Employee>",
  "relationshipProperties": {
    "relationship": "OneToMany",
    "mappedBy": "manager",
    "fetch": "LAZY"
  }
}

// Manager reference (ManyToOne)
{
  "name": "manager",
  "type": "Employee",
  "relationshipProperties": {
    "relationship": "ManyToOne",
    "joinColumn": "manager_id",
    "fetch": "LAZY"
  }
}
```

---

## Troubleshooting

### Issue: LazyInitializationException

**Cause:** Accessing LAZY collection outside transaction

**Solution:** Use JOIN FETCH, @Transactional, or EntityGraph

---

### Issue: N+1 Query Problem

**Symptom:** One query for parent + N queries for each child

**Solution:** Use JOIN FETCH or EntityGraph

---

### Issue: Cartesian Product

**Symptom:** Multiple EAGER collections cause huge result sets

**Solution:** Change to LAZY, use multiple queries, or use EntityGraph

---

### Issue: CascadeType.REMOVE Deleting Too Much

**Symptom:** Deleting parent deletes children unexpectedly

**Solution:** Remove CASCADE.REMOVE or use specific cascades

---

### Issue: Orphan Removal Not Working

**Symptom:** Removed children still in database

**Solution:** Ensure orphanRemoval=true on parent side (OneToMany)

---

## Quick Reference Checklist

**When creating bidirectional relationship:**
- [ ] Configure both sides
- [ ] Set `mappedBy` on inverse side
- [ ] Set `@JoinColumn` on owning side
- [ ] Choose appropriate cascade
- [ ] Use LAZY for collections
- [ ] Test both directions

**When choosing owning side:**
- [ ] ManyToOne side owns
- [ ] Side with @JoinColumn owns
- [ ] Side with foreign key owns

**When using cascade:**
- [ ] Composition → CASCADE.ALL
- [ ] Aggregation → CASCADE.PERSIST, MERGE
- [ ] Independent → No cascade

**When choosing fetch type:**
- [ ] Collections → LAZY
- [ ] Always-needed → EAGER
- [ ] Optional → LAZY
