---
name: spring-boot-intellij
description: >
  Complete toolkit for Spring Boot development in IntelliJ IDEA: project navigation, file
  editing, JPA entity and repository management, building, and testing — all 29 tools in
  one skill. Use this skill for any Spring Boot development task in IntelliJ: exploring
  project structure or files; finding, reading, and editing source files; creating or
  modifying JPA entities and entity attributes; creating Spring Data repositories; renaming
  symbols across the project; building, running tests, and validating code. Triggers on:
  project structure, find files, search text, read file, create entity, add field, add
  relationship, create repository, rename symbol, replace text, reformat, build project,
  compile, run tests, run [ConfigName], check compilation, check file problems.
---

# Spring Boot IntelliJ — Complete Tool Skill

Full toolkit for Spring Boot development in IntelliJ IDEA: project navigation, file editing, JPA entity and repository management, building, and testing.

---

## CRITICAL: MANDATORY TOOL USAGE POLICY

**YOU MUST USE MCP TOOLS FOR EVERY OPERATION. THIS IS NON-NEGOTIABLE.**

### Navigation & Discovery
- **NEVER** use `ls`, `dir`, or `find` in terminal — use `mcp__jetbrains__list_directory_tree`
- **NEVER** use `grep` or `rg` to search file contents — use `mcp__jetbrains__search_in_files_by_text` or `mcp__jetbrains__search_in_files_by_regex`
- **NEVER** use `find` to locate files — use `mcp__jetbrains__find_files_by_name_keyword` (fast, index-based) or `mcp__jetbrains__find_files_by_glob`
- **NEVER** use `cat`, `head`, or `tail` to read files — use `mcp__jetbrains__get_file_text_by_path`
- **ALWAYS** call `mcp__jetbrains__list_directory_tree` to understand project layout before any task

### JPA Exploration
- **NEVER** read `@Entity` files manually to understand entity structure — use `mcp__jetbrains__find_jpa_entities` or `mcp__jetbrains__get_jpa_entity_by_name`
- **NEVER** search for `@Entity` annotations with text/regex search — use `mcp__jetbrains__find_jpa_entities`
- **NEVER** locate repository interfaces by file reading — use `mcp__jetbrains__find_spring_data_repositories`
- **ALWAYS** call `mcp__jetbrains__find_jpa_entities` before creating any entity
- **ALWAYS** call `mcp__jetbrains__get_jpa_entity_by_name` before modifying any entity
- **ALWAYS** call `mcp__jetbrains__find_spring_data_repositories` before creating any repository

### JPA Implementation
- **NEVER** write `@Entity` class files manually — use `mcp__jetbrains__create_jpa_entity`
- **NEVER** add, modify, or remove entity fields by direct file editing — use `mcp__jetbrains__create_or_update_entity_attribute` or `mcp__jetbrains__delete_entity_attribute`
- **NEVER** create a Spring Data repository interface by hand — use `mcp__jetbrains__create_spring_data_repository`

### File Editing
- **NEVER** use `sed`, `awk`, or shell redirects for file edits — use `mcp__jetbrains__replace_text_in_file`
- **NEVER** use `echo > file` or shell heredocs to create files — use `mcp__jetbrains__create_new_file`
- **NEVER** use text search-and-replace to rename a symbol — use `mcp__jetbrains__rename_refactoring` (IDE-aware, updates all references)
- **ALWAYS** call `mcp__jetbrains__reformat_file` after creating or significantly editing any file

### Build & Test
- **NEVER** skip build validation after code changes — always call `mcp__jetbrains__build_project`
- **NEVER** run tests or the application without first calling `mcp__jetbrains__get_run_configurations` to find the exact config name
- **ALWAYS** call `mcp__jetbrains__build_project` before running any test
- **ALWAYS** prefer `mcp__jetbrains__execute_run_configuration` over raw `mvn`/`gradle` commands when a config exists

---

## When to Use This Skill

Use this skill for any Spring Boot development task in IntelliJ IDEA:

**Exploration & Navigation**
- Exploring project structure, modules, packages, dependencies
- Finding files by name or content pattern
- Reading and understanding source files
- Locating JPA entities and Spring Data repositories
- Understanding symbol declarations and types
- Reverse-engineering entities from database tables

**Implementation & Editing**
- Creating new source files, configs, test files
- Editing existing files with targeted replacements
- Renaming symbols across the entire project
- Creating JPA entities with full annotation support
- Adding, modifying, or removing entity attributes
- Creating Spring Data repository interfaces

**Build & Validation**
- Building the project and checking compilation errors
- Running test suites or the Spring Boot application
- Checking individual files for IDE inspection issues
- Running Maven/Gradle commands

---

## Trigger Keywords

**Navigation:** "project structure", "what files exist", "find [file]", "search for [text]", "read [file]", "show me [file]", "what modules", "what dependencies", "open [file] in editor"

**JPA Exploration:** "show me all entities", "what entities exist", "find entities in [package]", "show me the [Entity] entity", "analyze [Entity]", "find repositories", "does [Entity]Repository exist", "reverse engineer from [table]"

**JPA Implementation:** "create [Entity] entity", "add [field] to [Entity]", "add relationship between", "add @OneToMany/@ManyToOne", "remove [field] from [Entity]", "create repository for [Entity]", "add @Version", "add optimistic locking"

**File Editing:** "create a new [file]", "edit [file]", "replace [text] in [file]", "rename [symbol]", "reformat [file]"

**Build & Test:** "build the project", "compile", "run tests", "run [ConfigName]", "check for errors in [file]", "check compilation", "does it compile", "rebuild"

---

## All Available Tools

All tools use the `mcp__jetbrains__` prefix. 29 tools across 6 categories.

### A — Navigation & Discovery

| Tool | Purpose | Replaces |
|---|---|---|
| `mcp__jetbrains__list_directory_tree` | Tree view of a directory | `ls`, `tree` |
| `mcp__jetbrains__find_files_by_name_keyword` | Find files by partial name (index-based, fastest) | `find -name` |
| `mcp__jetbrains__find_files_by_glob` | Find files by glob pattern | `find` with glob |
| `mcp__jetbrains__get_all_open_file_paths` | Currently open editor files | — |
| `mcp__jetbrains__get_project_modules` | All project modules with types | — |
| `mcp__jetbrains__get_project_dependencies` | All library dependencies | — |
| `mcp__jetbrains__get_repositories` | VCS root paths | — |
| `mcp__jetbrains__get_run_configurations` | All run configurations with details | — |
| `mcp__jetbrains__open_file_in_editor` | Open a file in the IDE editor | — |

### B — File Content & Code Intelligence

| Tool | Purpose | Replaces |
|---|---|---|
| `mcp__jetbrains__get_file_text_by_path` | Read file content | `cat`, `head`, `tail` |
| `mcp__jetbrains__search_in_files_by_text` | Substring search across project | `grep` |
| `mcp__jetbrains__search_in_files_by_regex` | Regex search across project | `grep -E`, `rg` |
| `mcp__jetbrains__get_symbol_info` | Declaration and docs for a symbol at position | Quick Documentation |

### C — File Creation & Editing

| Tool | Purpose | Replaces |
|---|---|---|
| `mcp__jetbrains__create_new_file` | Create a new file with optional content | `echo >`, heredoc |
| `mcp__jetbrains__replace_text_in_file` | Targeted find-and-replace in a file | `sed`, `awk` |
| `mcp__jetbrains__rename_refactoring` | Rename symbol + update all references | text search-replace |
| `mcp__jetbrains__reformat_file` | Apply IDE code formatting rules | — |

### D — JPA Entity Discovery

| Tool | Purpose | When |
|---|---|---|
| `mcp__jetbrains__find_jpa_entities` | Discover all @Entity classes | Before creating any entity |
| `mcp__jetbrains__get_jpa_entity_by_name` | Full entity details (attributes, relationships) | Before modifying any entity |
| `mcp__jetbrains__find_spring_data_repositories` | Discover all repositories | Before creating any repository |
| `mcp__jetbrains__reverse_engineering_jpa_entity_by_name` | Generate entity from DB table | Legacy/database-first work |

### E — JPA Entity & Repository Creation

| Tool | Purpose | Never Do Instead |
|---|---|---|
| `mcp__jetbrains__create_jpa_entity` | Create a complete @Entity class | Write file manually |
| `mcp__jetbrains__create_or_update_entity_attribute` | Add or modify an entity field | Edit Java file directly |
| `mcp__jetbrains__delete_entity_attribute` | Remove a field from an entity | Edit Java file directly |
| `mcp__jetbrains__create_spring_data_repository` | Generate a repository interface | Write interface manually |

### F — Build, Run & Validate

| Tool | Purpose | When |
|---|---|---|
| `mcp__jetbrains__build_project` | Build project, return compilation errors | After EVERY code change |
| `mcp__jetbrains__execute_run_configuration` | Run a named configuration (tests/app) | After get_run_configurations |
| `mcp__jetbrains__get_file_problems` | IDE inspections on a specific file | After creating/editing files |
| `mcp__jetbrains__execute_terminal_command` | Run shell commands in IDE terminal | When no run config exists |

---

## Reference Files

- **references/tool-reference-a-navigation.md** — Category A: 9 navigation & discovery tools
- **references/tool-reference-b-content.md** — Category B: 4 file content & code intelligence tools
- **references/tool-reference-c-editing.md** — Category C: 4 file creation & editing tools
- **references/tool-reference-d-jpa-discovery.md** — Category D: 4 JPA entity discovery tools
- **references/tool-reference-e-jpa-creation.md** — Category E: 4 JPA entity & repository creation tools
- **references/tool-reference-f-build-test.md** — Category F: 4 build, run & validate tools + quick selection reference
- **references/patterns.md** — 20+ workflow patterns combining tools across categories
- **references/examples.md** — End-to-end task examples (entity creation, debugging, editing, testing)
- **references/best-practices.md** — Universal rules, category-specific rules, anti-patterns, troubleshooting

---

## Workflow Overview

```
Any Task
   │
   ▼
EXPLORE (Group A + B + D)
list_directory_tree → understand layout
find_files_by_name_keyword → locate files
find_jpa_entities → check domain model
get_jpa_entity_by_name → analyze entity
find_spring_data_repositories → check repos
   │
   ▼
IMPLEMENT (Group C + E)
create_jpa_entity / create_or_update_entity_attribute
create_new_file / replace_text_in_file / rename_refactoring
create_spring_data_repository
reformat_file
   │
   ▼
VALIDATE (Group F)
build_project → compilation check (MANDATORY)
get_file_problems → inspection check
get_run_configurations → find test config
execute_run_configuration → run tests
```
