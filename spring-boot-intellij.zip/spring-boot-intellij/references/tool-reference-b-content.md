# Category B: File Content & Code Intelligence

Tools for reading file content and understanding code semantics. All tools use the `mcp__jetbrains__` prefix.

**Rule:** NEVER use `cat`, `head`, `tail`, `grep`, `rg` — always use these tools.

---

## mcp__jetbrains__get_file_text_by_path

**Purpose:** Reads file content by project-relative path. Primary file reading tool.
**Replaces:** `cat`, `head`, `tail` — never use those.

| Parameter | Type | Required | Description |
|---|---|---|---|
| `pathInProject` | String | Yes | Relative to project root. Example: `src/main/java/com/example/domain/User.java` |
| `truncateMode` | Enum | No | `START` (see end), `END` (see beginning), `MIDDLE`, `NONE`. |
| `maxLinesCount` | Integer | No | Limit lines returned. Use `50–100` for quick preview. |
| `projectPath` | String | Recommended | Always pass if known. |

**Returns:** Raw file content as string. Error for binary files.

**Critical:** Always read a file with this tool before calling `replace_text_in_file` — you need the exact text.

**Examples:**
```
Read Java class:   { "pathInProject": "src/main/java/com/example/service/UserService.java" }
Read config:       { "pathInProject": "src/main/resources/application.yml" }
Read pom.xml:      { "pathInProject": "pom.xml", "maxLinesCount": 80, "truncateMode": "END" }
```

---

## mcp__jetbrains__search_in_files_by_text

**Purpose:** Fast text substring search across project files using IntelliJ's index.
**Replaces:** `grep`, `rg` for plain text — never use those.

| Parameter | Type | Required | Description |
|---|---|---|---|
| `searchText` | String | Yes | Exact substring to find. |
| `directoryToSearch` | String | No | Restrict to subdirectory (relative to root). |
| `fileMask` | String | No | Filter by file type: `*.java`, `*.yml`. |
| `caseSensitive` | Boolean | No | Default: false. |
| `maxUsageCount` | Integer | No | Cap results. |
| `timeout` | Integer | No | Milliseconds. |
| `projectPath` | String | Recommended | Always pass if known. |

**Returns:**
```json
{
  "entries": [{ "filePath": "src/.../UserService.java", "lineNumber": 42, "lineText": "    ||@Transactional|| readOnly..." }],
  "probablyHasMoreMatchingEntries": false
}
```
Note: `||text||` marks the matched portion.

**Examples:**
```
Find annotation usages:  { "searchText": "@Transactional", "fileMask": "*.java" }
Find method calls:       { "searchText": "userRepository.findBy", "directoryToSearch": "src/main/java" }
Find config keys:        { "searchText": "spring.datasource", "fileMask": "*.yml" }
```

---

## mcp__jetbrains__search_in_files_by_regex

**Purpose:** Regex pattern search across project files using IntelliJ's search engine.
**Replaces:** `grep -E`, `rg` with patterns — never use those.

| Parameter | Type | Required | Description |
|---|---|---|---|
| `regexPattern` | String | Yes | Regular expression. |
| `directoryToSearch` | String | No | Restrict to subdirectory. |
| `fileMask` | String | No | Filter by file type. |
| `caseSensitive` | Boolean | No | Default: false. |
| `maxUsageCount` | Integer | No | Cap results. |
| `timeout` | Integer | No | Milliseconds. |
| `projectPath` | String | Recommended | Always pass if known. |

**Returns:** Same shape as `search_in_files_by_text`.

**Examples:**
```
LAZY relationships:   { "regexPattern": "fetch.*LAZY", "fileMask": "*.java" }
All @Id fields:       { "regexPattern": "@Id\\s", "fileMask": "*.java" }
Method signatures:    { "regexPattern": "public.*find.*By.*\\(", "fileMask": "*.java" }
```

---

## mcp__jetbrains__get_symbol_info

**Purpose:** Returns declaration, type, and documentation for the symbol at a specific file position — equivalent to IntelliJ Quick Documentation.

| Parameter | Type | Required | Description |
|---|---|---|---|
| `filePath` | String | Yes | Path relative to project root. |
| `line` | Integer | Yes | 1-based line number (from file content). |
| `column` | Integer | Yes | 1-based column number — position on the symbol name. |
| `projectPath` | String | Recommended | Always pass if known. |

**Returns:**
```json
{
  "symbolInfo": {
    "name": "findByEmail",
    "declarationText": "Optional<User> findByEmail(String email)",
    "declarationFile": "src/.../UserRepository.java",
    "declarationLine": 15,
    "language": "JAVA"
  },
  "documentation": "Spring Data derived query..."
}
```

**Workflow:** First read the file with `get_file_text_by_path` to get line numbers, then call this tool on the symbol of interest.
