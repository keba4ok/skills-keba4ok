# Category C: File Creation & Editing

Tools for creating new files and modifying existing ones. All tools use the `mcp__jetbrains__` prefix.

**Rules:**
- NEVER use `sed`, `awk`, `echo >`, shell heredocs for file operations
- NEVER use text replace for renaming symbols — use `rename_refactoring`
- ALWAYS call `reformat_file` after creating or significantly editing any file

---

## mcp__jetbrains__create_new_file

**Purpose:** Creates a new file with optional content. Primary tool for scaffolding non-JPA files.
**Replaces:** `echo >`, shell heredocs — never use those.
**Not for:** JPA entities (use `create_jpa_entity`) or repositories (use `create_spring_data_repository`).

| Parameter | Type | Required | Description |
|---|---|---|---|
| `pathInProject` | String | Yes | Relative to project root. Parent dirs created automatically. |
| `text` | String | No | File content. Provide complete content including package, imports, class body. |
| `overwrite` | Boolean | No | Default: false. Set true only when intentionally replacing. |
| `projectPath` | String | Recommended | Always pass if known. |

**Returns:** Confirmation with created file path, or error if file exists and overwrite=false.

**Examples:**
```
New service:   { "pathInProject": "src/main/java/com/example/service/ProductService.java", "text": "package com.example.service;\n..." }
Test config:   { "pathInProject": "src/test/resources/application.yml", "text": "spring:\n  datasource:\n    url: jdbc:h2:mem:test\n..." }
SQL migration: { "pathInProject": "src/main/resources/db/migration/V3__add_product.sql", "text": "ALTER TABLE products ADD COLUMN sku VARCHAR(50);\n" }
```

---

## mcp__jetbrains__replace_text_in_file

**Purpose:** Targeted find-and-replace in a file. Primary tool for editing existing source files.
**Replaces:** `sed`, `awk`, shell-based file editing — never use those.
**Not for:** Renaming symbols — use `rename_refactoring`.

| Parameter | Type | Required | Description |
|---|---|---|---|
| `pathInProject` | String | Yes | Relative to project root. |
| `oldText` | String | Yes | **Exact** text to find — must match file content exactly including whitespace. |
| `newText` | String | Yes | Replacement text. Empty string to delete. |
| `replaceAll` | Boolean | No | Default: true. Set false to replace only first occurrence. |
| `caseSensitive` | Boolean | No | Default: true. |
| `projectPath` | String | Recommended | Always pass if known. |

**Returns:** `"ok"` on success. Errors: `"no occurrences found"`, `"file not found"`, `"could not get document"`.

**Critical:** Always call `get_file_text_by_path` first to get the exact text to replace.

**If `"no occurrences found"`:** The `oldText` doesn't exactly match. Re-read the file and copy the exact text including indentation and newlines.

**Examples:**
```
Add import:
  oldText: "import org.springframework.stereotype.Service;"
  newText: "import org.springframework.stereotype.Service;\nimport org.springframework.transaction.annotation.Transactional;"

Add annotation to method:
  oldText: "    public List<Product> findAll() {"
  newText: "    @Transactional(readOnly = true)\n    public List<Product> findAll() {"
  replaceAll: false

Update config:
  oldText: "ddl-auto: create-drop"
  newText: "ddl-auto: validate"
```

---

## mcp__jetbrains__rename_refactoring

**Purpose:** Renames a symbol and updates ALL references project-wide. IDE-aware — understands code semantics.
**Always use this instead of text search-and-replace for any symbol rename.**

| Parameter | Type | Required | Description |
|---|---|---|---|
| `pathInProject` | String | Yes | File containing the symbol definition. |
| `symbolName` | String | Yes | Exact current name (case-sensitive). |
| `newName` | String | Yes | New name for the symbol. |
| `projectPath` | String | Recommended | Always pass if known. |

**Returns:** Success message or error if file/symbol not found.

**Updates automatically:** Class name, file name, all import statements, all usages across every file, annotation references, derived repository method names.

**Examples:**
```
Rename class:   { "pathInProject": "src/.../domain/User.java", "symbolName": "User", "newName": "Customer" }
Rename method:  { "pathInProject": "src/.../service/UserService.java", "symbolName": "getUserById", "newName": "findUserById" }
Rename field:   { "pathInProject": "src/.../domain/User.java", "symbolName": "name", "newName": "fullName" }
```

---

## mcp__jetbrains__reformat_file

**Purpose:** Applies IntelliJ's code formatting rules to a file. Call after every file creation or significant edit.

| Parameter | Type | Required | Description |
|---|---|---|---|
| `path` | String | Yes | Path relative to project root. |
| `projectPath` | String | Recommended | Always pass if known. |

**Returns:** Confirmation of reformatting.

**Rule:** Always call after `create_new_file`, `create_jpa_entity`, `create_spring_data_repository`, and `replace_text_in_file`.
