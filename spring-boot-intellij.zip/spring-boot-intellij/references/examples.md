# End-to-End Examples — Spring Boot IntelliJ

Complete worked examples showing how to combine all tools for real development tasks.

---

## Example 1: Create a New Entity with Repository

**Task:** "Create a `Product` entity with name, price, and category relationship, then add a repository."

```
Step 1 — Check what already exists
mcp__jetbrains__find_jpa_entities()
→ Result: [User, Order, Category] — no Product entity, Category exists

Step 2 — Understand conventions from existing entity
mcp__jetbrains__get_jpa_entity_by_name(entityName: "Category")
→ Result: packageName: "com.example.domain", tableName: "categories", IDENTITY strategy

Step 3 — Check for existing repository
mcp__jetbrains__find_spring_data_repositories(entityName: "Product")
→ Result: [] — no ProductRepository

Step 4 — Create the entity
mcp__jetbrains__create_jpa_entity(
  entityName: "Product",
  entityPackage: "com.example.domain",
  tableName: "products",
  attributes: [
    { name: "id", type: "Long", isId: true,
      columnProperties: {},
      idGenerationProperties: { generatedStrategy: "IDENTITY" },
      relationshipProperties: {}, collectionProperties: {}, embeddedProperties: {} },
    { name: "name", type: "String", isId: false,
      columnProperties: { nullable: false, length: 200 },
      idGenerationProperties: {}, relationshipProperties: {}, collectionProperties: {}, embeddedProperties: {} },
    { name: "price", type: "BigDecimal", isId: false,
      columnProperties: { nullable: false, precision: 19, scale: 2 },
      idGenerationProperties: {}, relationshipProperties: {}, collectionProperties: {}, embeddedProperties: {} },
    { name: "category", type: "Category", isId: false,
      columnProperties: {},
      idGenerationProperties: {},
      relationshipProperties: { relationship: "ManyToOne", joinColumn: "category_id", fetch: "LAZY" },
      collectionProperties: {}, embeddedProperties: {} }
  ]
)
→ Result: status: "Success", path: "src/main/java/com/example/domain/Product.java"

Step 5 — Reformat
mcp__jetbrains__reformat_file(path: "src/main/java/com/example/domain/Product.java")

Step 6 — Build
mcp__jetbrains__build_project()
→ Result: errors: [] ✓

Step 7 — Check IDE inspections
mcp__jetbrains__get_file_problems(filePath: "src/main/java/com/example/domain/Product.java")
→ Result: errors: [] ✓

Step 8 — Create repository
mcp__jetbrains__create_spring_data_repository(
  repositoryClassName: "ProductRepository",
  entityName: "Product",
  baseRepositoryClass: "JpaRepository"
)
→ Result: path: "src/main/java/com/example/repository/ProductRepository.java"

Step 9 — Final build
mcp__jetbrains__build_project()
→ Result: errors: [] ✓

Step 10 — Verify
mcp__jetbrains__get_jpa_entity_by_name(entityName: "Product")
→ Confirms: id (IDENTITY), name, price, category (ManyToOne LAZY) ✓
```

---

## Example 2: Add Bidirectional OneToMany Relationship

**Task:** "Add a one-to-many relationship between `User` and `Order`."

```
Step 1 — Analyze both entities
mcp__jetbrains__get_jpa_entity_by_name(entityName: "User")
→ FQN: "com.example.domain.User", no orders field yet

mcp__jetbrains__get_jpa_entity_by_name(entityName: "Order")
→ FQN: "com.example.domain.Order", no user field yet

Step 2 — Add owning side (ManyToOne on Order)
mcp__jetbrains__create_or_update_entity_attribute(
  entityFqn: "com.example.domain.Order",
  name: "user",
  type: "User",
  isId: false,
  columnProperties: {},
  idGenerationProperties: {},
  relationshipProperties: {
    relationship: "ManyToOne",
    joinColumn: "user_id",
    fetch: "LAZY"
  },
  collectionProperties: {},
  embeddedProperties: {}
)

Step 3 — Add inverse side (OneToMany on User)
mcp__jetbrains__create_or_update_entity_attribute(
  entityFqn: "com.example.domain.User",
  name: "orders",
  type: "List<Order>",
  isId: false,
  columnProperties: {},
  idGenerationProperties: {},
  relationshipProperties: {
    relationship: "OneToMany",
    mappedBy: "user",
    cascade: "ALL",
    fetch: "LAZY",
    orphanRemoval: true
  },
  collectionProperties: {},
  embeddedProperties: {}
)

Step 4 — Build to validate
mcp__jetbrains__build_project()
→ errors: [] ✓

Step 5 — Verify both sides
mcp__jetbrains__get_jpa_entity_by_name(entityName: "User")
→ Confirms: orders (OneToMany, mappedBy: "user", LAZY, cascade: ALL) ✓

mcp__jetbrains__get_jpa_entity_by_name(entityName: "Order")
→ Confirms: user (ManyToOne, joinColumn: "user_id", LAZY) ✓
```

---

## Example 3: Edit an Existing Service File

**Task:** "Add `@Transactional(readOnly = true)` to `findAll()` in `ProductService`."

```
Step 1 — Find the file
mcp__jetbrains__find_files_by_name_keyword(nameKeyword: "ProductService")
→ Result: ["src/main/java/com/example/service/ProductService.java"]

Step 2 — Read the file
mcp__jetbrains__get_file_text_by_path(
  pathInProject: "src/main/java/com/example/service/ProductService.java"
)
→ Output (line 15):
   "    public List<Product> findAll() {"

Step 3 — Check if Transactional is imported
→ Reading output: no import for Transactional found

Step 4 — Add import
mcp__jetbrains__replace_text_in_file(
  pathInProject: "src/main/java/com/example/service/ProductService.java",
  oldText: "import org.springframework.stereotype.Service;",
  newText: "import org.springframework.stereotype.Service;\nimport org.springframework.transaction.annotation.Transactional;"
)

Step 5 — Add annotation
mcp__jetbrains__replace_text_in_file(
  pathInProject: "src/main/java/com/example/service/ProductService.java",
  oldText: "    public List<Product> findAll() {",
  newText: "    @Transactional(readOnly = true)\n    public List<Product> findAll() {",
  replaceAll: false
)

Step 6 — Reformat
mcp__jetbrains__reformat_file(path: "src/main/java/com/example/service/ProductService.java")

Step 7 — Build
mcp__jetbrains__build_project()
→ errors: [] ✓
```

---

## Example 4: Debug a LazyInitializationException

**Task:** "I'm getting `LazyInitializationException` when accessing `user.getOrders()`."

```
Step 1 — Analyze User entity
mcp__jetbrains__get_jpa_entity_by_name(entityName: "User")
→ orders field: relationship: "OneToMany", fetch: "LAZY"
→ This is the root cause: collection accessed outside transaction

Step 2 — Find where orders is accessed
mcp__jetbrains__search_in_files_by_text(
  searchText: "getOrders()",
  directoryToSearch: "src/main/java",
  fileMask: "*.java"
)
→ Result: UserService.java:42 — "user.getOrders()"

Step 3 — Read the service method
mcp__jetbrains__get_file_text_by_path(
  pathInProject: "src/main/java/com/example/service/UserService.java"
)
→ Line 38: "    public User getUserWithOrders(Long id) {"
→ No @Transactional — this is the problem

Step 4 — Fix: add @Transactional
mcp__jetbrains__replace_text_in_file(
  pathInProject: "src/main/java/com/example/service/UserService.java",
  oldText: "    public User getUserWithOrders(Long id) {",
  newText: "    @Transactional(readOnly = true)\n    public User getUserWithOrders(Long id) {",
  replaceAll: false
)

Step 5 — Build
mcp__jetbrains__build_project()
→ errors: [] ✓

Step 6 — Run tests to confirm fix
mcp__jetbrains__get_run_configurations()
→ Find "UserServiceTest" config

mcp__jetbrains__execute_run_configuration(configurationName: "UserServiceTest", timeout: 60000)
→ exitCode: 0 ✓
```

---

## Example 5: Rename an Entity Class

**Task:** "Rename the `User` entity to `Customer`."

```
Step 1 — Locate the entity file
mcp__jetbrains__find_files_by_name_keyword(nameKeyword: "User")
→ Result: "src/main/java/com/example/domain/User.java" (and others)

Step 2 — Understand current usage
mcp__jetbrains__search_in_files_by_text(searchText: "User", fileMask: "*.java")
→ Shows UserService, UserRepository, UserController all reference User

Step 3 — Rename (IDE-aware — updates ALL references)
mcp__jetbrains__rename_refactoring(
  pathInProject: "src/main/java/com/example/domain/User.java",
  symbolName: "User",
  newName: "Customer"
)
→ Updates: class name, UserRepository type param, UserService usages,
   UserController imports, all @ManyToOne references — automatically

Step 4 — Verify no old name remains
mcp__jetbrains__search_in_files_by_text(searchText: "class User", fileMask: "*.java")
→ Result: [] ✓

Step 5 — Build
mcp__jetbrains__build_project()
→ errors: [] ✓
```

---

## Example 6: Reverse Engineer Entity from Legacy Database

**Task:** "We have a legacy `customers` table — create an entity for it."

```
Step 1 — Check if entity already exists
mcp__jetbrains__find_jpa_entities()
→ No Customer or Customers entity found

Step 2 — Reverse engineer from DB table
mcp__jetbrains__reverse_engineering_jpa_entity_by_name(entityTableName: "customers")
→ attributes: ["id: Long", "first_name: String", "last_name: String",
               "email: String", "created_at: Timestamp", "is_active: Boolean"]

Step 3 — Check target package convention
mcp__jetbrains__get_jpa_entity_by_name(entityName: "Order")
→ packageName: "com.example.domain"

Step 4 — Create entity using reverse-engineered attributes
mcp__jetbrains__create_jpa_entity(
  entityName: "Customer",
  entityPackage: "com.example.domain",
  tableName: "customers",
  attributes: [
    { name: "id", type: "Long", isId: true,
      idGenerationProperties: { generatedStrategy: "IDENTITY" }, ... },
    { name: "firstName", type: "String", column: "first_name",
      columnProperties: { nullable: false, length: 100 }, ... },
    { name: "lastName", type: "String", column: "last_name",
      columnProperties: { nullable: false, length: 100 }, ... },
    { name: "email", type: "String",
      columnProperties: { nullable: false, unique: true, length: 255 }, ... },
    { name: "createdAt", type: "LocalDateTime", column: "created_at",
      columnProperties: { nullable: false, updatable: false }, ... },
    { name: "isActive", type: "Boolean", column: "is_active",
      columnProperties: { nullable: false }, ... }
  ]
)

Step 5 — Build and inspect
mcp__jetbrains__build_project()
mcp__jetbrains__get_file_problems(filePath: "src/.../domain/Customer.java")

Step 6 — Create repository
mcp__jetbrains__create_spring_data_repository(
  repositoryClassName: "CustomerRepository",
  entityName: "Customer",
  baseRepositoryClass: "JpaRepository"
)

Step 7 — Final build
mcp__jetbrains__build_project()
→ errors: [] ✓
```

---

## Example 7: Full Test Cycle After Implementation

**Task:** "Verify everything still works after adding the `Product` entity."

```
Step 1 — Build first
mcp__jetbrains__build_project()
→ If errors: fix them first, then continue

Step 2 — Check modified files
mcp__jetbrains__get_file_problems(
  filePath: "src/main/java/com/example/domain/Product.java"
)
mcp__jetbrains__get_file_problems(
  filePath: "src/main/java/com/example/repository/ProductRepository.java"
)

Step 3 — Discover test configurations
mcp__jetbrains__get_run_configurations()
→ Finds: "Unit Tests", "Integration Tests", "ProductServiceTest"

Step 4 — Run unit tests
mcp__jetbrains__execute_run_configuration(
  configurationName: "Unit Tests",
  timeout: 300000,
  truncateMode: "START",
  maxLinesCount: 200
)
→ exitCode: 0 ✓

Step 5 — Run integration tests
mcp__jetbrains__execute_run_configuration(
  configurationName: "Integration Tests",
  timeout: 600000,
  truncateMode: "START",
  maxLinesCount: 300
)
→ exitCode: 0 ✓
```

---

## Example 8: Explore an Unfamiliar Project

**Task:** "I've just opened this project — understand its structure before making changes."

```
Step 1 — High-level overview
mcp__jetbrains__list_directory_tree(directoryPath: "", maxDepth: 3)
→ Identifies: src/main/java, src/test, pom.xml, docker-compose.yml

Step 2 — Project metadata
mcp__jetbrains__get_project_modules()
→ Finds: feature-service, feature-service-domain, feature-service-web

mcp__jetbrains__get_project_dependencies()
→ Finds: spring-boot-starter-data-jpa:3.2, postgresql:42.6, junit-jupiter:5.10

Step 3 — Domain model
mcp__jetbrains__find_jpa_entities()
→ Finds: Feature, FeatureFlag, Experiment (3 entities)

mcp__jetbrains__get_jpa_entity_by_name(entityName: "Feature")
→ Understands: fields, relationships to FeatureFlag, SEQUENCE id strategy

mcp__jetbrains__get_jpa_entity_by_name(entityName: "FeatureFlag")
→ Understands: ManyToOne back to Feature

Step 4 — Repository coverage
mcp__jetbrains__find_spring_data_repositories()
→ Finds: FeatureRepository, FeatureFlagRepository (Experiment has no repo)

Step 5 — Source structure
mcp__jetbrains__list_directory_tree(directoryPath: "src/main/java")
→ Understands package layout: .domain, .repository, .service, .web

Step 6 — Check open files (user context)
mcp__jetbrains__get_all_open_file_paths()
→ User has FeatureService.java open — focus area identified

Step 7 — Understand key service
mcp__jetbrains__get_file_text_by_path(
  pathInProject: "src/main/java/com/example/service/FeatureService.java"
)
→ Read key business logic

Step 8 — Available run configurations
mcp__jetbrains__get_run_configurations()
→ Finds: "FeatureService Application", "Unit Tests", "Integration Tests"

→ Now ready to implement with full context
```
