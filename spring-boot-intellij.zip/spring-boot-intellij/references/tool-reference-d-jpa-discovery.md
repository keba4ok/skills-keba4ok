# Category D: JPA Entity Discovery

Tools for discovering and analyzing JPA entities and Spring Data repositories. All tools use the `mcp__jetbrains__` prefix.

**Rules:**
- ALWAYS call these BEFORE any entity/repository creation or modification
- NEVER search for @Entity by text/regex — use `find_jpa_entities`
- NEVER read entity files to understand structure — use `get_jpa_entity_by_name`
- NEVER look for repositories by reading files — use `find_spring_data_repositories`

---

## mcp__jetbrains__find_jpa_entities

**Purpose:** Discovers all `@Entity` classes in the project. **Mandatory before creating any entity.**

| Parameter | Type | Required | Description |
|---|---|---|---|
| `entityPackage` | String | No | Filter by package name. Omit to search entire project. |
| `moduleName` | String | No | Scope to specific module (multi-module projects). |
| `projectPath` | String | Recommended | Always pass if known. |

**Returns:**
```json
{
  "entities": [
    {
      "name": "User", "tableName": "users", "packageName": "com.example.domain",
      "attributes": [...], "mappedSuperclass": false, "compositeId": false,
      "inheritanceType": null, "superclass": null, "indexes": [...], "namedQueries": [...]
    }
  ]
}
```

**Call this:** Before creating any entity. To get domain model overview. To find naming and package conventions.

---

## mcp__jetbrains__get_jpa_entity_by_name

**Purpose:** Full details of a specific entity — attributes, relationships, fetch types, cascade, inheritance. **Mandatory before modifying any entity.**

| Parameter | Type | Required | Description |
|---|---|---|---|
| `entityName` | String | Yes | Simple name (`"User"`) or FQN (`"com.example.domain.User"`). Use FQN if name is ambiguous. |
| `projectPath` | String | Recommended | Always pass if known. |

**Returns:** Full entity structure including all attribute details, relationship configuration (relationship type, fetch, cascade, mappedBy, joinColumn), inheritance strategy.

**Key fields to check:**
- `attributes[].relationshipProperties.fetch` — LAZY vs EAGER (source of LazyInitializationException)
- `attributes[].relationshipProperties.mappedBy` — present = inverse side; absent = owning side
- `attributes[].idGenerationProperties.generatedStrategy` — for ID conventions
- `packageName` — for consistent package placement of new entities
- `inheritanceType` — SINGLE_TABLE, JOINED, TABLE_PER_CLASS

**Call this:** Before `create_or_update_entity_attribute`. When debugging relationships. To get the FQN needed for `entityFqn` parameters.

---

## mcp__jetbrains__find_spring_data_repositories

**Purpose:** Discovers all Spring Data repository interfaces. **Mandatory before creating any repository.**

| Parameter | Type | Required | Description |
|---|---|---|---|
| `entityName` | String | No | Filter by entity name. Omit to list all repositories. |
| `moduleName` | String | No | Scope to specific module. |
| `searchInLibraries` | Boolean | No | Default: false. Include repos from external dependencies. |
| `projectPath` | String | Recommended | Always pass if known. |

**Returns:**
```json
{
  "repositories": [
    { "name": "UserRepository", "path": "src/.../UserRepository.java",
      "content": "public interface UserRepository extends JpaRepository<User, Long> { ... }",
      "entity": "User" }
  ]
}
```

**Call this:** Before `create_spring_data_repository` to check for duplicates. To audit repository coverage (find entities missing repositories).

---

## mcp__jetbrains__reverse_engineering_jpa_entity_by_name

**Purpose:** Generates JPA entity attribute list from an existing database table — for legacy/database-first development.

| Parameter | Type | Required | Description |
|---|---|---|---|
| `entityTableName` | String | Yes | Actual database table name (snake_case). |
| `projectPath` | String | Recommended | Always pass if known. |

**Returns:**
```json
{ "attributes": ["id: Long", "first_name: String", "email: String", "created_at: Timestamp"] }
```

**Workflow:** Call this → use the result to inform a `create_jpa_entity` call (map snake_case columns to camelCase attribute names).
