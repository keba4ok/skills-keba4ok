# Category A: Navigation & Discovery

Tools for exploring project structure, finding files, and understanding project metadata. All tools use the `mcp__jetbrains__` prefix.

**Rule:** NEVER use `ls`, `dir`, `find`, `tree` in terminal — always use these tools.

---

## mcp__jetbrains__list_directory_tree

**Purpose:** Tree representation of a project directory. Primary way to understand project layout.
**Replaces:** `ls`, `dir`, `tree` — never use those.

| Parameter | Type | Required | Description |
|---|---|---|---|
| `directoryPath` | String | Yes | Path relative to project root. Use `""` for root. |
| `maxDepth` | Integer | No | Maximum recursion depth. Use `2–3` for overview, `5+` for deep. |
| `timeout` | Integer | No | Milliseconds. |
| `projectPath` | String | Recommended | Always pass if known. |

**Returns:**
```json
{ "traversedDirectory": "src", "tree": "src\n└── main\n    └── java\n...", "errors": [], "listingTimedOut": null }
```

**Examples:**
```
Full project overview:    { "directoryPath": "", "maxDepth": 3 }
Source packages:          { "directoryPath": "src/main/java" }
Test structure:           { "directoryPath": "src/test" }
```

---

## mcp__jetbrains__find_files_by_name_keyword

**Purpose:** Find files by partial name using IntelliJ's index. Fastest file search — prefer over glob.
**Replaces:** `find -name` — never use that.

| Parameter | Type | Required | Description |
|---|---|---|---|
| `nameKeyword` | String | Yes | Case-insensitive substring to match against file names only (not paths). |
| `fileCountLimit` | Integer | No | Cap results. Use `10–20` when only a few results needed. |
| `timeout` | Integer | No | Milliseconds. |
| `projectPath` | String | Recommended | Always pass if known. |

**Returns:**
```json
{ "files": ["src/main/java/com/example/service/UserService.java"], "probablyHasMoreMatchingFiles": false }
```

**When to use vs glob:** Use this for name-based lookups. Use `find_files_by_glob` only when you need a pattern (e.g., `**/*Test.java`).

**Examples:**
```
Find a class:      { "nameKeyword": "UserService" }
Find all tests:    { "nameKeyword": "Test", "fileCountLimit": 50 }
Find configs:      { "nameKeyword": "application" }
```

---

## mcp__jetbrains__find_files_by_glob

**Purpose:** Find files recursively by glob pattern.
**Replaces:** `find` with globs — never use that.

| Parameter | Type | Required | Description |
|---|---|---|---|
| `globPattern` | String | Yes | Relative to project root. Example: `src/**/*.java` |
| `subDirectoryRelativePath` | String | No | Restrict search to this subdirectory. |
| `fileCountLimit` | Integer | No | Cap results. |
| `timeout` | Integer | No | Milliseconds. |
| `projectPath` | String | Recommended | Always pass if known. |

**Returns:** Same shape as `find_files_by_name_keyword`.

**Examples:**
```
All Java sources:        { "globPattern": "src/main/java/**/*.java" }
All test files:          { "globPattern": "src/test/**/*Test.java" }
All YAML configs:        { "globPattern": "src/main/resources/**/*.yml" }
All SQL migrations:      { "globPattern": "src/main/resources/db/migration/**/*.sql" }
```

---

## mcp__jetbrains__get_all_open_file_paths

**Purpose:** Returns files currently open in the IDE editor — reveals user's current context.

| Parameter | Type | Required | Description |
|---|---|---|---|
| `projectPath` | String | Recommended | Always pass if known. |

**Returns:**
```json
{ "activeFilePath": "src/main/java/com/example/domain/User.java", "openFiles": ["...", "..."] }
```

**When to use:** When the user says "the file I have open" or when you need to understand their current focus before making suggestions.

---

## mcp__jetbrains__get_project_modules

**Purpose:** Lists all project modules with their types — essential for multi-module Maven/Gradle projects.

| Parameter | Type | Required | Description |
|---|---|---|---|
| `projectPath` | String | Recommended | Always pass if known. |

**Returns:**
```json
{ "modules": [{ "name": "my-app-domain", "type": "JAVA_MODULE" }, ...] }
```

**When to use:** Before passing `moduleName` to any JPA tool. Before creating files to identify the correct module.

---

## mcp__jetbrains__get_project_dependencies

**Purpose:** Lists all library dependencies — confirms available frameworks before implementation.

| Parameter | Type | Required | Description |
|---|---|---|---|
| `projectPath` | String | Recommended | Always pass if known. |

**Returns:**
```json
{ "dependencies": [{ "name": "spring-boot-starter-data-jpa:3.2.0" }, ...] }
```

**When to use:** Before JPA operations — confirm `spring-boot-starter-data-jpa` is present. Before suggesting patterns — check Spring Boot version, test frameworks, DB driver.

---

## mcp__jetbrains__get_repositories

**Purpose:** Lists all VCS roots with their VCS type.

| Parameter | Type | Required | Description |
|---|---|---|---|
| `projectPath` | String | Recommended | Always pass if known. |

**Returns:**
```json
{ "roots": [{ "pathRelativeToProject": "", "vcsName": "Git" }] }
```

**When to use:** Multi-repository projects. Verifying which directories are under version control.

---

## mcp__jetbrains__get_run_configurations

**Purpose:** Lists all run configurations with name, command, working directory, and environment.
**ALWAYS call before `execute_run_configuration`** — config names are case-sensitive.

| Parameter | Type | Required | Description |
|---|---|---|---|
| `projectPath` | String | Recommended | Always pass if known. |

**Returns:**
```json
{
  "configurations": [
    { "name": "All Tests", "commandLine": "mvn test", "workingDirectory": "/...", "environment": null },
    { "name": "MyApp", "commandLine": null, "environment": { "SPRING_PROFILES_ACTIVE": "dev" } }
  ]
}
```

**When to use:** Always first, before any `execute_run_configuration` call. To discover what test suites and application launchers exist.

---

## mcp__jetbrains__open_file_in_editor

**Purpose:** Opens a file in the IDE editor — makes it visible to the user in IntelliJ.

| Parameter | Type | Required | Description |
|---|---|---|---|
| `filePath` | String | Yes | Path relative to project root (or absolute). |
| `projectPath` | String | Recommended | Always pass if known. |

**When to use:** After creating or locating a relevant file — show it to the user in the IDE.
