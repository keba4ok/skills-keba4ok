# Category E: JPA Entity & Repository Creation

Tools for creating and modifying JPA entities and repositories. All tools use the `mcp__jetbrains__` prefix.

**Rule:** NEVER manually edit entity/repository files — always use these tools. They handle JPA annotation placement, relationship integrity, database mapping consistency, and IDE synchronization automatically.

---

## mcp__jetbrains__create_jpa_entity

**Purpose:** Creates a complete JPA entity class with all annotations. The ONLY correct way to create an entity.

| Parameter | Type | Required | Description |
|---|---|---|---|
| `entityName` | String | Yes | PascalCase singular class name. |
| `entityPackage` | String | No | Target package. Auto-detected from existing entities if omitted. |
| `language` | Enum | No | `"Java"` or `"Kotlin"`. Default: Java. |
| `moduleName` | String | No | Multi-module projects only. |
| `tableName` | String | No | Database table name. Auto-generated (snake_case) if omitted. |
| `attributes` | Array | No | Entity fields. See attribute object below. |
| `inheritanceType` | String | No | `"SINGLE_TABLE"`, `"JOINED"`, `"TABLE_PER_CLASS"`. |
| `discriminatorColumn` | String | No | Inheritance discrimination column name. |
| `discriminatorType` | String | No | `"STRING"`, `"CHAR"`, `"INTEGER"`. Default: STRING. |
| `discriminatorValue` | String | No | Value for this subclass. |
| `superclass` | String | No | Parent entity class name. |
| `mappedSuperclass` | Boolean | No | Mark as `@MappedSuperclass`. |
| `compositeId` | Boolean | No | Enable composite primary key. |
| `indexes` | Array | No | `[{ "name": "idx_email", "columnList": ["email"], "unique": true, "constraint": false }]` |
| `namedQueries` | Array | No | `[{ "name": "User.findActive", "query": "SELECT u FROM User u WHERE..." }]` |
| `projectPath` | String | Recommended | Always pass if known. |

**Attribute object — all required keys:**
```json
{
  "name": "email",
  "type": "String",
  "isId": false,
  "column": "email",
  "columnProperties": { "nullable": false, "unique": true, "length": 255 },
  "idGenerationProperties": {},
  "relationshipProperties": {},
  "collectionProperties": {},
  "embeddedProperties": {}
}
```

**Common attribute patterns:**

| Pattern | Key fields |
|---|---|
| ID (auto-increment) | `isId: true`, `idGenerationProperties: { generatedStrategy: "IDENTITY" }` |
| ID (sequence) | `isId: true`, `idGenerationProperties: { generatedStrategy: "SEQUENCE", sequenceName: "x_seq", allocationSize: 50 }` |
| ID (UUID) | `isId: true`, `idGenerationProperties: { generatedStrategy: "UUID" }` |
| Non-null String | `columnProperties: { nullable: false, length: 200 }` |
| Money (BigDecimal) | `columnProperties: { nullable: false, precision: 19, scale: 2 }` |
| Immutable timestamp | `columnProperties: { nullable: false, updatable: false }` |
| @Version | `columnProperties: { nullable: false, version: true }` |
| ManyToOne | `relationshipProperties: { relationship: "ManyToOne", joinColumn: "user_id", fetch: "LAZY" }` |
| OneToMany | `relationshipProperties: { relationship: "OneToMany", mappedBy: "user", cascade: "ALL", fetch: "LAZY", orphanRemoval: true }` |
| ManyToMany | `relationshipProperties: { relationship: "ManyToMany", joinTable: "user_roles", joinColumn: "user_id", inverseJoinColumn: "role_id", fetch: "LAZY" }` |
| OneToOne owning | `relationshipProperties: { relationship: "OneToOne", joinColumn: "profile_id", fetch: "LAZY" }` |

**Returns:**
```json
{ "status": "Success", "message": "...", "nextSuggestedActions": "...", "resultFiles": [{ "name": "User.java", "path": "..." }] }
```
If `status: "Ask user"` — provide clarification (package, module) and retry. If `status: "Failure"` — check `message`.

**Prerequisite:** Always call `find_jpa_entities` first to check for duplicates and learn package conventions.

---

## mcp__jetbrains__create_or_update_entity_attribute

**Purpose:** Adds a new attribute or modifies an existing one in a JPA entity. The ONLY correct way to evolve entity fields.

| Parameter | Type | Required | Description |
|---|---|---|---|
| `entityFqn` | String | Yes | **Fully qualified** entity name: `com.example.domain.User` — never just `User`. |
| `name` | String | Yes | Attribute name (camelCase). |
| `type` | String | Yes | Java/Kotlin type: `"String"`, `"Long"`, `"List<Order>"`, `"LocalDateTime"`. |
| `isId` | Boolean | No | Mark as primary key. |
| `column` | String | No | Custom column name. Auto-generated if omitted. |
| `columnProperties` | Object | No | See `create_jpa_entity` attribute reference. |
| `idGenerationProperties` | Object | No | See `create_jpa_entity` attribute reference. |
| `relationshipProperties` | Object | No | See `create_jpa_entity` attribute reference. |
| `collectionProperties` | Object | No | For `@ElementCollection`. |
| `embeddedProperties` | Object | No | For `@Embedded`. |
| `projectPath` | String | Recommended | Always pass if known. |

**Prerequisite:** Always call `get_jpa_entity_by_name` first to get the correct FQN and understand current state.

**Returns:** Same shape as `create_jpa_entity`.

**Examples:**
```json
// Add @Version field
{ "entityFqn": "com.example.domain.Order", "name": "version", "type": "Long",
  "columnProperties": { "nullable": false, "version": true } }

// Add ManyToOne relationship
{ "entityFqn": "com.example.domain.Order", "name": "user", "type": "User",
  "relationshipProperties": { "relationship": "ManyToOne", "joinColumn": "user_id", "fetch": "LAZY" } }

// Add OneToMany inverse side
{ "entityFqn": "com.example.domain.User", "name": "orders", "type": "List<Order>",
  "relationshipProperties": { "relationship": "OneToMany", "mappedBy": "user", "cascade": "ALL", "fetch": "LAZY", "orphanRemoval": true } }
```

---

## mcp__jetbrains__delete_entity_attribute

**Purpose:** Removes an attribute from a JPA entity including annotations and relationship mappings. The ONLY correct way to remove entity fields.

| Parameter | Type | Required | Description |
|---|---|---|---|
| `entityFqn` | String | Yes | Fully qualified entity name. |
| `name` | String | Yes | Exact attribute name to remove. |
| `projectPath` | String | Recommended | Always pass if known. |

**Prerequisite:** Always call `get_jpa_entity_by_name` first to confirm the attribute exists and check for dependent relationships. Call `search_in_files_by_text` for field usages before deleting.

**Returns:** Updated entity file details.

---

## mcp__jetbrains__create_spring_data_repository

**Purpose:** Generates a Spring Data JPA repository interface. The ONLY correct way to create a repository.

| Parameter | Type | Required | Description |
|---|---|---|---|
| `repositoryClassName` | String | Yes | Repository name. Convention: `{Entity}Repository`. |
| `entityName` | String | No | Target entity name or FQN. Strongly recommended. |
| `packageName` | String | No | Repository package. Auto-detected from entity if omitted. |
| `sourceRootType` | String | No | `"source"` or `"test"`. Default: `"source"`. |
| `moduleName` | String | No | Multi-module projects only. |
| `baseRepositoryClass` | String | No | `"JpaRepository"` (default, recommended), `"CrudRepository"`, `"PagingAndSortingRepository"`, `"ListCrudRepository"`. |
| `projectPath` | String | Recommended | Always pass if known. |

**Prerequisite:** Always call `find_spring_data_repositories` first to confirm no duplicate exists.

**Returns:**
```json
{ "file": { "name": "UserRepository.java", "path": "src/.../UserRepository.java", "content": "...", "entity": "User" } }
```
