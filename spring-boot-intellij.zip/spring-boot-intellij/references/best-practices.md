# Spring Boot IntelliJ — Best Practices

Cross-category rules and decision guidance for all 29 MCP tools.

---

## Universal Rules

| Rule | Why |
|---|---|
| Pass `projectPath` in every tool call | Eliminates ambiguity in multi-project environments |
| Explore before implementing | Always know the current state before changing it |
| Build after every change | Catch compilation errors immediately — never accumulate |
| Reformat after every create/edit | Maintain consistent code style across the project |
| Use `rename_refactoring` for symbol renames, not text replace | IDE-aware — updates ALL references correctly |
| Never use terminal equivalents (cat, grep, ls, sed, find) | MCP tools are indexed, faster, and IDE-integrated |

---

## Category-Specific Best Practices

### A — Navigation

| Rule |
|---|
| Use `find_files_by_name_keyword` first when you know any part of the filename — it's fastest |
| Use `find_files_by_glob` only when you need a pattern (e.g., all `*Test.java`) |
| Use `search_in_files_by_text` for literal searches — faster than regex |
| Use `search_in_files_by_regex` only when pattern matching is needed |
| Always call `get_run_configurations` before `execute_run_configuration` — names are case-sensitive |
| Call `get_all_open_file_paths` when user says "this file" or "the file I have open" |

### B — Content

| Rule |
|---|
| Always read a file with `get_file_text_by_path` before calling `replace_text_in_file` |
| Use `get_symbol_info` to understand types and declarations — don't guess from reading raw text |
| Read files with `maxLinesCount: 50` for quick preview; omit for full read |

### C — Editing

| Rule |
|---|
| Never use `create_new_file` for JPA entities or repositories — use specialized tools |
| `oldText` in `replace_text_in_file` must match exactly — re-read file if "no occurrences found" |
| `rename_refactoring` > `replace_text_in_file` for any symbol rename — always |
| Always call `reformat_file` after `create_new_file` and `replace_text_in_file` |

### D — JPA Discovery

| Rule |
|---|
| Always call `find_jpa_entities` before creating any entity |
| Always call `get_jpa_entity_by_name` before modifying any entity — get FQN + current state |
| Always call `find_spring_data_repositories` before creating any repository |
| Never read `@Entity` files to understand structure — use `get_jpa_entity_by_name` |

### E — JPA Creation

| Rule |
|---|
| Every attribute requires all 5 property objects, even if empty: `columnProperties`, `idGenerationProperties`, `relationshipProperties`, `collectionProperties`, `embeddedProperties` |
| Always complete both sides of bidirectional relationships |
| Always create a repository after creating an entity |
| Always inform user about database migration needs after entity changes |
| FQN is required — never guess; always get it from `get_jpa_entity_by_name` |

### F — Build & Test

| Rule |
|---|
| `build_project` is mandatory after every code change — no exceptions |
| If unexpected build errors: retry with `rebuild: true` before assuming real error |
| Use `truncateMode: "START"` with `maxLinesCount: 300` for test output — results appear at the end |
| Prefer `execute_run_configuration` over `execute_terminal_command` when config exists |
| Use `get_file_problems` after creating entities — catches JPA annotation issues compilation misses |

---

## Anti-Patterns (Universal)

| Anti-Pattern | Correct Approach |
|---|---|
| `grep` / `rg` to search content | `search_in_files_by_text` or `search_in_files_by_regex` |
| `ls` / `find` to list files | `list_directory_tree` or `find_files_by_name_keyword` |
| `cat` / `head` / `tail` to read files | `get_file_text_by_path` |
| `sed` / `awk` to edit files | `replace_text_in_file` |
| Text replace to rename symbols | `rename_refactoring` |
| Manual `@Entity` class creation | `create_jpa_entity` |
| Manually editing entity fields | `create_or_update_entity_attribute` / `delete_entity_attribute` |
| Manual repository interface | `create_spring_data_repository` |
| Skipping `build_project` after changes | Always build — no exceptions |
| Guessing run configuration names | `get_run_configurations` → exact name |
| Guessing entity FQN | `get_jpa_entity_by_name` → exact FQN |

---

## Exploration → Implementation → Validation Sequence

```
ANY TASK
  │
  ▼ EXPLORE (Category A, B, D)
  list_directory_tree → project layout
  find_files_by_name_keyword / find_files_by_glob → locate files
  get_file_text_by_path → read content
  find_jpa_entities → domain model overview
  get_jpa_entity_by_name → entity details + FQN
  find_spring_data_repositories → existing repos
  get_project_dependencies → confirm available libraries
  │
  ▼ IMPLEMENT (Category C, E)
  create_jpa_entity / create_or_update_entity_attribute / delete_entity_attribute
  create_spring_data_repository
  create_new_file / replace_text_in_file / rename_refactoring
  reformat_file (after every create/edit)
  │
  ▼ VALIDATE (Category F)
  build_project → compilation check (MANDATORY)
  get_file_problems → IDE inspection check
  get_run_configurations → find test config
  execute_run_configuration → run tests
```

---

## Troubleshooting

| Issue | Cause | Fix |
|---|---|---|
| `"no occurrences found"` in replace_text_in_file | Whitespace or newline mismatch in `oldText` | Re-read file, copy exact text |
| `status: "Ask user"` from entity tools | Disambiguation needed (package, module) | Read `message`, present to user, re-call |
| `cannot find symbol` build error | Missing import or wrong type | Add import; verify entity name |
| `duplicate class` build error | Manual + tool-created file conflict | Delete one |
| `LazyInitializationException` in tests | LAZY relation accessed outside `@Transactional` | Add `@Transactional` to test or service method |
| `UnsatisfiedDependencyException` in tests | Missing `@MockBean` | Add `@MockBean` for the missing bean |
| Build errors after clean: retry | Stale artifacts | `build_project(rebuild: true)` |
