# Category F: Build, Run & Validate

Tools for compiling, running, and inspecting code quality. All tools use the `mcp__jetbrains__` prefix.

**Rules:**
- ALWAYS call `build_project` after every code change — no exceptions
- ALWAYS call `get_run_configurations` before `execute_run_configuration` — names are case-sensitive
- ALWAYS prefer `execute_run_configuration` over raw `mvn`/`gradle` commands when a config exists
- Use `execute_terminal_command` only as fallback when no run config exists

---

## mcp__jetbrains__build_project

**Purpose:** Triggers IntelliJ's build system and returns structured compilation errors. **Mandatory after every code change.**

| Parameter | Type | Required | Description |
|---|---|---|---|
| `rebuild` | Boolean | No | Default: false (incremental). Set `true` for full clean rebuild. |
| `timeout` | Integer | No | Milliseconds. Large projects: 120000–300000. |
| `projectPath` | String | Recommended | Always pass if known. |

**Returns:**
```json
{
  "errors": [
    { "severity": "ERROR", "description": "cannot find symbol: class Order",
      "filePath": "src/.../User.java", "line": 15, "column": 12, "lineContent": "..." }
  ],
  "timedOut": false
}
```

**Call after:** Every `create_jpa_entity`, `create_or_update_entity_attribute`, `delete_entity_attribute`, `create_new_file`, `replace_text_in_file`, `rename_refactoring`, `create_spring_data_repository`.

**If unexpected errors:** Retry with `rebuild: true` to eliminate stale artifacts.

**Common error guide:**

| Error | Cause | Fix |
|---|---|---|
| `cannot find symbol: class X` | Missing import or class doesn't exist | Add import; verify class name |
| `package X does not exist` | Missing dependency or wrong import path | Add to pom.xml or fix import |
| `incompatible types` | Type mismatch | Fix assignment/return type |
| `duplicate class` | Two classes with same FQN | Rename or delete one |
| `javax vs jakarta` | Mixed Spring Boot 2.x / 3.x imports | Align JPA imports to Boot version |

---

## mcp__jetbrains__execute_run_configuration

**Purpose:** Executes a named run configuration and waits for completion. Primary tool for running tests and applications.

| Parameter | Type | Required | Description |
|---|---|---|---|
| `configurationName` | String | Yes | **Exact** config name from `get_run_configurations`. Case-sensitive. |
| `timeout` | Integer | No | Milliseconds. Unit tests: 120000. Integration tests: 300000–600000. App startup: 120000. |
| `maxLinesCount` | Integer | No | Cap output lines. Use `200–500` for focused results. |
| `truncateMode` | Enum | No | `"START"` to see end of output (test summary). `"END"` to see beginning. |
| `projectPath` | String | Recommended | Always pass if known. |

**Returns:**
```json
{ "exitCode": 0, "timedOut": false, "output": "...[INFO] Tests run: 42, Failures: 0...[INFO] BUILD SUCCESS" }
```

**Always call `get_run_configurations` first** — never guess the config name.

**Exit codes:** `0` = success. Non-zero = failure. `null` = timed out or killed.

**Recommended:** `truncateMode: "START"` with `maxLinesCount: 300` — test summaries and failure details appear at the end of Maven/Gradle output.

**Common test failures:**

| Output Pattern | Meaning |
|---|---|
| `expected:<X> but was:<Y>` | Assertion failed — logic error |
| `NullPointerException` in test | Missing test data setup |
| `UnsatisfiedDependencyException` | Missing `@MockBean` or Spring bean |
| `LazyInitializationException` | LAZY relation accessed outside `@Transactional` |
| `Compilation failure` | Build failed — run `build_project` first |

---

## mcp__jetbrains__get_file_problems

**Purpose:** Runs IntelliJ's full inspection engine on a specific file — returns errors and warnings the IDE detects.

| Parameter | Type | Required | Description |
|---|---|---|---|
| `filePath` | String | Yes | Relative to project root. |
| `errorsOnly` | Boolean | No | Default: false (errors + warnings). Set true for critical issues only. |
| `timeout` | Integer | No | Inspections can be slow: allow 15000–30000ms. |
| `projectPath` | String | Recommended | Always pass if known. |

**Returns:**
```json
{
  "filePath": "src/.../domain/User.java",
  "errors": [
    { "severity": "ERROR", "description": "Entity class must have a public no-argument constructor",
      "lineContent": "public class User {", "line": 12, "column": 1 }
  ],
  "timedOut": false
}
```

**Severity:** `ERROR` = must fix. `WARNING` = investigate. `WEAK_WARNING` = optional.

**JPA-specific issues detected:**
- Missing no-arg constructor (`@NoArgsConstructor` required)
- Missing `@Id` annotation
- Incorrect owning/inverse relationship configuration
- Field injection warnings (prefer constructor injection)
- `@Transactional` on private method (Spring AOP limitation)

**Call after:** Creating any entity. Creating any service or controller. After edits to validate no new issues.

---

## mcp__jetbrains__execute_terminal_command

**Purpose:** Executes shell commands in the IDE terminal. Use as fallback when no dedicated tool or run configuration covers the operation.
**Prefer `execute_run_configuration` when a matching config exists.**

| Parameter | Type | Required | Description |
|---|---|---|---|
| `command` | String | Yes | Shell command to execute. |
| `executeInShell` | Boolean | No | Run in user's shell (bash/zsh) to inherit full environment. |
| `reuseExistingTerminalWindow` | Boolean | No | Avoid creating multiple terminal tabs. |
| `timeout` | Integer | No | Default: 30000ms. Always increase for builds/tests: 120000–600000. |
| `maxLinesCount` | Integer | No | Default: 2000. Use `200–500` for test runs. |
| `truncateMode` | Enum | No | `"START"` to see end of output (result summaries). |
| `projectPath` | String | Recommended | Always pass if known. |

**Returns:**
```json
{ "command_output": "...", "command_exit_code": 0, "is_timed_out": false }
```

**Appropriate uses:**
- `mvn dependency:resolve` — resolve dependencies
- `mvn test -Dtest=UserServiceTest#testMethod` — specific test method
- `./gradlew test --tests 'com.example.*'` — Gradle filtered tests
- `mvn flyway:migrate` — database migrations
- `mvn jacoco:report` — coverage reports
- `mvn verify -P integration` — integration test profile

---

# Quick Tool Selection Reference

```
FIND FILES
  Know part of name?    → find_files_by_name_keyword     (fastest)
  Have a pattern?       → find_files_by_glob
  Browse directory?     → list_directory_tree

READ CODE
  Read a file?          → get_file_text_by_path
  Search plain text?    → search_in_files_by_text
  Search with regex?    → search_in_files_by_regex
  Understand a symbol?  → get_symbol_info

PROJECT METADATA
  Modules?              → get_project_modules
  Dependencies?         → get_project_dependencies
  VCS roots?            → get_repositories
  Run configs?          → get_run_configurations

CREATE / EDIT
  New entity?           → create_jpa_entity              (never write manually)
  New repository?       → create_spring_data_repository  (never write manually)
  Add entity field?     → create_or_update_entity_attribute
  Remove entity field?  → delete_entity_attribute
  New other file?       → create_new_file
  Edit file text?       → replace_text_in_file           (read first!)
  Rename symbol?        → rename_refactoring             (never text replace)
  Reformat?             → reformat_file                  (always after editing)

JPA DISCOVERY
  All entities?         → find_jpa_entities              (before creating)
  Specific entity?      → get_jpa_entity_by_name         (before modifying)
  Repositories?         → find_spring_data_repositories  (before creating)
  From DB table?        → reverse_engineering_jpa_entity_by_name

BUILD & TEST
  Validate changes?     → build_project                  (mandatory after every change)
  Full rebuild?         → build_project(rebuild: true)
  Find test config?     → get_run_configurations         (always first)
  Run tests/app?        → execute_run_configuration
  Check file issues?    → get_file_problems
  Custom command?       → execute_terminal_command       (fallback only)
```
