# Workflow Patterns — Spring Boot IntelliJ

Common multi-tool workflows for Spring Boot development tasks. Each pattern lists tools in call order.

---

## Group A: Exploration Patterns

### A1 — Project Orientation (start of any task)
Use at the beginning of any session or unfamiliar task.
```
1. mcp__jetbrains__list_directory_tree(directoryPath: "")
   → Understand top-level structure, identify modules

2. mcp__jetbrains__get_project_modules()
   → List all modules for multi-module projects

3. mcp__jetbrains__get_project_dependencies()
   → Verify Spring Boot, JPA, test frameworks present

4. mcp__jetbrains__list_directory_tree(directoryPath: "src/main/java")
   → Understand package layout
```

### A2 — Domain Model Audit
Use before designing new features or planning entity changes.
```
1. mcp__jetbrains__find_jpa_entities()
   → Full entity list with table names and packages

2. mcp__jetbrains__get_jpa_entity_by_name(entityName: "<key entity>")
   → Drill into critical entities one by one

3. mcp__jetbrains__find_spring_data_repositories()
   → Map repositories to entities, find coverage gaps

4. mcp__jetbrains__search_in_files_by_text(searchText: "@Transactional")
   → Understand transaction boundaries in services
```

### A3 — File Location & Reading
Use when you need to find and read a specific file.
```
1. mcp__jetbrains__find_files_by_name_keyword(nameKeyword: "<keyword>")
   → Locate files by name (fastest option)

   OR if you need a pattern:
   mcp__jetbrains__find_files_by_glob(globPattern: "src/**/*Service.java")

2. mcp__jetbrains__get_file_text_by_path(pathInProject: "<path from step 1>")
   → Read the file content

3. mcp__jetbrains__get_symbol_info(filePath, line, column)
   → Understand a specific symbol in the file (optional)
```

### A4 — Codebase Search
Use when you need to find usages, patterns, or configuration values.
```
1. mcp__jetbrains__search_in_files_by_text(searchText: "<term>", fileMask: "*.java")
   → Find exact text matches

   OR for patterns:
   mcp__jetbrains__search_in_files_by_regex(regexPattern: "<pattern>", fileMask: "*.java")

2. mcp__jetbrains__get_file_text_by_path(pathInProject: "<result file>")
   → Read the full file to understand context

3. mcp__jetbrains__get_symbol_info(...)
   → Get declaration details for a found symbol
```

### A5 — Pre-Implementation Check
Use before ANY create/modify operation to avoid duplicates and follow conventions.
```
1. mcp__jetbrains__find_jpa_entities()
   → Confirm entity doesn't already exist

2. mcp__jetbrains__find_spring_data_repositories()
   → Confirm repository doesn't already exist

3. mcp__jetbrains__get_jpa_entity_by_name(entityName: "<similar entity>")
   → Learn package, naming conventions, patterns

4. mcp__jetbrains__list_directory_tree(directoryPath: "src/main/java")
   → Identify correct target package/directory
```

### A6 — Debugging LazyInitializationException
```
1. mcp__jetbrains__get_jpa_entity_by_name(entityName: "<entity>")
   → Find relationship with fetch: LAZY

2. mcp__jetbrains__get_jpa_entity_by_name(entityName: "<related entity>")
   → Check the other side: mappedBy, cascade

3. mcp__jetbrains__search_in_files_by_text(searchText: "<entity>.get<Collection>")
   → Find where collection is accessed

4. mcp__jetbrains__get_file_text_by_path("<service file>")
   → Check if access is inside @Transactional
```

---

## Group B: Entity Implementation Patterns

### B1 — New Entity (full workflow)
```
1. mcp__jetbrains__find_jpa_entities()
   → Confirm entity doesn't exist, note package convention

2. mcp__jetbrains__get_project_dependencies()
   → Confirm spring-boot-starter-data-jpa present

3. mcp__jetbrains__create_jpa_entity(entityName, entityPackage, tableName, attributes, ...)
   → Create the entity with all attributes

4. mcp__jetbrains__reformat_file(path: "<created entity path>")
   → Apply formatting

5. mcp__jetbrains__build_project()
   → Validate compilation — fix errors before continuing

6. mcp__jetbrains__get_file_problems(filePath: "<entity path>")
   → Check IDE inspections (missing no-arg constructor, @Id, etc.)

7. mcp__jetbrains__find_spring_data_repositories(entityName: "<new entity>")
   → Confirm repository doesn't exist

8. mcp__jetbrains__create_spring_data_repository(repositoryClassName, entityName, ...)
   → Create repository

9. mcp__jetbrains__build_project()
   → Final validation

10. mcp__jetbrains__get_jpa_entity_by_name("<new entity>")
    → Confirm structure is correct
```

### B2 — Add Attribute to Existing Entity
```
1. mcp__jetbrains__get_jpa_entity_by_name(entityName: "<entity>")
   → Get FQN, see existing attributes, understand conventions

2. mcp__jetbrains__create_or_update_entity_attribute(entityFqn: "<FQN>", name, type, ...)
   → Add the attribute with proper JPA annotations

3. mcp__jetbrains__build_project()
   → Validate compilation

4. mcp__jetbrains__get_jpa_entity_by_name("<entity>")
   → Confirm attribute was added correctly
```

### B3 — Bidirectional Relationship
```
1. mcp__jetbrains__get_jpa_entity_by_name("<entity A>")
2. mcp__jetbrains__get_jpa_entity_by_name("<entity B>")
   → Understand both entities' current structure and FQNs

3. mcp__jetbrains__create_or_update_entity_attribute(
     entityFqn: "<B FQN>",          ← owning side (ManyToOne)
     relationshipProperties: { relationship: "ManyToOne", joinColumn: "a_id", fetch: "LAZY" }
   )

4. mcp__jetbrains__create_or_update_entity_attribute(
     entityFqn: "<A FQN>",          ← inverse side (OneToMany)
     relationshipProperties: { relationship: "OneToMany", mappedBy: "<field on B>", cascade: "ALL", fetch: "LAZY" }
   )

5. mcp__jetbrains__build_project()
   → Validate both sides compile

6. mcp__jetbrains__get_jpa_entity_by_name("<entity A>")
7. mcp__jetbrains__get_jpa_entity_by_name("<entity B>")
   → Verify both sides configured correctly
```

### B4 — Remove Deprecated Field
```
1. mcp__jetbrains__get_jpa_entity_by_name("<entity>")
   → Confirm field exists, check for relationships that depend on it

2. mcp__jetbrains__search_in_files_by_text(searchText: ".<fieldName>")
   → Check for code references to this field

3. mcp__jetbrains__delete_entity_attribute(entityFqn: "<FQN>", name: "<field>")
   → Remove the attribute

4. mcp__jetbrains__build_project()
   → Validate — fix any remaining references found in step 2
```

### B5 — Add Optimistic Locking
```
1. mcp__jetbrains__get_jpa_entity_by_name("<entity>")
   → Confirm no @Version field already exists

2. mcp__jetbrains__create_or_update_entity_attribute(
     entityFqn: "<FQN>",
     name: "version", type: "Long",
     columnProperties: { nullable: false, version: true }
   )

3. mcp__jetbrains__build_project()
4. mcp__jetbrains__get_jpa_entity_by_name("<entity>")
   → Confirm @Version is present
```

---

## Group C: File Editing Patterns

### C1 — Edit Existing File
```
1. mcp__jetbrains__find_files_by_name_keyword(nameKeyword: "<filename>")
   → Locate the file

2. mcp__jetbrains__get_file_text_by_path(pathInProject: "<path>")
   → Read current content — get exact text to replace

3. mcp__jetbrains__replace_text_in_file(pathInProject, oldText: "<exact text>", newText: "<replacement>")
   → Make the change

4. mcp__jetbrains__reformat_file(path: "<path>")
   → Apply formatting

5. mcp__jetbrains__build_project()
   → Validate
```

### C2 — Create a New Non-Entity File
```
1. mcp__jetbrains__list_directory_tree(directoryPath: "src/main/java/<target package>")
   → Confirm target directory exists

2. mcp__jetbrains__find_files_by_name_keyword(nameKeyword: "<filename>")
   → Confirm file doesn't already exist

3. mcp__jetbrains__create_new_file(pathInProject: "<path>", text: "<content>")
   → Create the file

4. mcp__jetbrains__reformat_file(path: "<path>")
   → Apply formatting

5. mcp__jetbrains__build_project()
   → Validate
```

### C3 — Rename a Symbol
```
1. mcp__jetbrains__find_files_by_name_keyword(nameKeyword: "<current name>")
   → Locate the file containing the symbol

2. mcp__jetbrains__rename_refactoring(
     pathInProject: "<file path>",
     symbolName: "<exact current name>",
     newName: "<new name>"
   )
   → Rename across entire project (IDE-aware)

3. mcp__jetbrains__build_project()
   → Verify no broken references
```

### C4 — Add Annotation or Import to Existing Class
```
1. mcp__jetbrains__get_file_text_by_path("<path>")
   → Read file to find exact text to replace

2. mcp__jetbrains__replace_text_in_file(
     pathInProject: "<path>",
     oldText: "import org.springframework.stereotype.Service;",
     newText: "import org.springframework.stereotype.Service;\nimport org.springframework.transaction.annotation.Transactional;"
   )

3. mcp__jetbrains__replace_text_in_file(
     pathInProject: "<path>",
     oldText: "    public User findById(",
     newText: "    @Transactional(readOnly = true)\n    public User findById("
   )

4. mcp__jetbrains__build_project()
```

---

## Group D: Build & Test Patterns

### D1 — Standard Post-Change Validation
```
1. mcp__jetbrains__build_project()
   → Check for compilation errors

   If errors:
   → Fix with replace_text_in_file or create_or_update_entity_attribute
   → Call build_project() again

2. mcp__jetbrains__get_file_problems(filePath: "<changed file>")
   → Check IDE inspections for warnings

3. mcp__jetbrains__get_run_configurations()
   → Find the test configuration name

4. mcp__jetbrains__execute_run_configuration(configurationName: "<test config>")
   → Run tests
```

### D2 — Run Specific Tests
```
1. mcp__jetbrains__build_project()
   → Must compile before running tests

2. mcp__jetbrains__get_run_configurations()
   → Find exact name (case-sensitive) of test config

3. mcp__jetbrains__execute_run_configuration(
     configurationName: "<exact name>",
     timeout: 120000
   )
   → Run tests, check exitCode (0 = pass)
```

### D3 — Debug Test Failure
```
1. mcp__jetbrains__execute_run_configuration("<failing config>")
   → Reproduce failure, read error message

2. mcp__jetbrains__get_file_text_by_path("<test file>")
   → Read the failing test

3. mcp__jetbrains__get_file_text_by_path("<production file>")
   → Read the code under test

4. mcp__jetbrains__get_file_problems("<production file>")
   → Check for IDE-detected issues

5.  Fix with implementation tools

6. mcp__jetbrains__build_project()
   → Validate fix compiles

7. mcp__jetbrains__execute_run_configuration("<failing config>")
   → Confirm fix
```

### D4 — Full Rebuild After Dependency Change
```
1. mcp__jetbrains__get_file_text_by_path("pom.xml")    ← read first
2. mcp__jetbrains__replace_text_in_file("pom.xml", ...)  ← add dependency
3. mcp__jetbrains__build_project(rebuild: true, timeout: 300000)
   → Full clean rebuild to pick up new dependency
4. mcp__jetbrains__get_file_problems("<affected file>")
```

### D5 — Start Application & Verify
```
1. mcp__jetbrains__build_project()
   → Compile first

2. mcp__jetbrains__get_run_configurations()
   → Find application launcher config

3. mcp__jetbrains__execute_run_configuration(
     configurationName: "<app launcher>",
     timeout: 120000
   )
   → Check output for "Started ... in X.XX seconds"
   → On failure: read stack trace, fix with implementation tools
```

---

## Group E: Cross-Cutting Patterns

### E1 — Feature Development (end-to-end)
```
EXPLORE
1. list_directory_tree → understand structure
2. find_jpa_entities → existing domain model
3. find_spring_data_repositories → existing repos
4. get_project_modules → identify target module

DESIGN
5. Identify entities to create/modify
6. Plan relationships and attributes

IMPLEMENT
7. create_jpa_entity (for new entities)
8. create_or_update_entity_attribute (for new fields/relationships)
9. create_spring_data_repository (for new repos)
10. create_new_file / replace_text_in_file (for services, controllers)
11. reformat_file (for each created/edited file)

VALIDATE
12. build_project → compilation check
13. get_file_problems → inspection check
14. execute_run_configuration → run tests
```

### E2 — Legacy DB Integration
```
1. get_project_dependencies()
   → Confirm JPA and DB driver present

2. reverse_engineering_jpa_entity_by_name("<table1>")
3. reverse_engineering_jpa_entity_by_name("<table2>")
   → Get attribute types from schema

4. find_jpa_entities()
   → Check if entities already exist

5. create_jpa_entity(<name>, <attributes from step 2>)
   → Create entity from schema

6. build_project()
7. create_spring_data_repository(...)
8. build_project()
```

### E3 — Refactoring (rename + cleanup)
```
1. find_files_by_name_keyword("<old name>")
   → Locate all affected files

2. get_jpa_entity_by_name("<entity>")
   → Understand current structure

3. rename_refactoring("<file>", "<old name>", "<new name>")
   → Rename symbol across project

4. search_in_files_by_text("<old name>")
   → Verify no remaining references

5. build_project()
   → Confirm clean compilation after rename
```

---

## Tool Priority Reference

When multiple tools could work, use this priority order:

| Task | First Choice | Fallback |
|---|---|---|
| Find file by name | `find_files_by_name_keyword` | `find_files_by_glob` |
| Read file | `get_file_text_by_path` | — |
| Search content | `search_in_files_by_text` | `search_in_files_by_regex` |
| List directory | `list_directory_tree` | — |
| Understand entity | `get_jpa_entity_by_name` | `get_file_text_by_path` (only if tool fails) |
| Create entity | `create_jpa_entity` | — (no fallback — never write manually) |
| Edit file | `replace_text_in_file` | — |
| Rename symbol | `rename_refactoring` | — (no fallback — never use text replace) |
| Run config | `execute_run_configuration` | `execute_terminal_command` |
| Build | `build_project` | `execute_terminal_command("mvn compile")` |
