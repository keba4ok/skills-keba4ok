---
name: jpa-spring-data
description: >
  MANDATORY skill for ALL JPA entity and Spring Data repository operations in Spring Boot projects.
  This skill provides IntelliJ MCP tools (mcp__jetbrains__* prefix) that MUST be used instead of
  manual file editing for entity/repository management. Use this skill WHENEVER the user wants to:
  create, read, modify, or delete JPA entities; add/modify/delete entity attributes; create or find
  Spring Data repositories; reverse-engineer entities from database tables; explore the domain model;
  add entity relationships; modify entity structure; or perform ANY JPA/Spring Data operation.

  CRITICAL: ALWAYS use these MCP tools for entity operations - NEVER manually edit entity files with
  Read/Write/Edit tools. These specialized tools ensure proper JPA annotation handling, relationship
  integrity, database mapping consistency, and IDE integration.

  Trigger this skill on ANY mention of: JPA entities, @Entity, entity creation/modification, Spring Data
  repositories, entity relationships (@OneToMany, @ManyToOne, @ManyToMany, @OneToOne), entity attributes,
  database table mappings, domain modeling, entity packages, repository interfaces, JpaRepository,
  entity fields, @Column, @Id, @GeneratedValue, entity discovery, reverse engineering from database,
  or ANY Spring Boot persistence layer work.
---

# JPA Spring Data — MCP Tools Skill

Mandatory toolkit for all JPA entity and Spring Data repository operations via IntelliJ MCP tools.

---

## CRITICAL: MANDATORY TOOL USAGE POLICY

**YOU MUST USE MCP TOOLS FOR ALL JPA OPERATIONS. THIS IS NON-NEGOTIABLE.**

- **NEVER** manually edit entity files with Read/Write/Edit tools — use `create_jpa_entity`, `create_or_update_entity_attribute`, `delete_entity_attribute`
- **NEVER** create repository interfaces by hand — use `create_spring_data_repository`
- **NEVER** search for `@Entity` with grep/text search — use `find_jpa_entities`
- **NEVER** read entity files to understand structure — use `get_jpa_entity_by_name`
- **NEVER** guess the FQN — always retrieve it with `get_jpa_entity_by_name`
- **NEVER** skip discovery — always check what exists before creating
- **ALWAYS** include all 5 attribute property objects (even if empty): `columnProperties`, `idGenerationProperties`, `relationshipProperties`, `collectionProperties`, `embeddedProperties`
- **ALWAYS** load tools first: `ToolSearch: query="+jetbrains jpa"`
- **ALWAYS** pass `projectPath` in every call
- **ALWAYS** complete bidirectional relationships (both owning and inverse side)
- **ALWAYS** create a repository after creating an entity

---

## When to Use This Skill

- Create, modify, or delete JPA entities
- Add, change, or remove entity attributes or relationships
- Create Spring Data repository interfaces
- Explore the domain model (all entities, specific entity structure)
- Reverse-engineer entities from existing database tables
- Audit entity-repository coverage

## Trigger Keywords

Entity creation/modification, repository creation, @Entity, @OneToMany, @ManyToOne, @ManyToMany, @OneToOne, @JoinColumn, @JoinTable, @Id, @Column, @GeneratedValue, JpaRepository, Spring Data, domain model, entity field, entity attribute, entity relationship, database table mapping, reverse engineer

---

## Available Tools

All tools use the `mcp__jetbrains__` prefix.

| Tool | Purpose | Never Do Instead |
|---|---|---|
| `find_jpa_entities` | Discover all entities (mandatory before creating) | Text search for `@Entity` |
| `get_jpa_entity_by_name` | Full entity details + FQN (mandatory before modifying) | Read entity file directly |
| `find_spring_data_repositories` | Find existing repositories (mandatory before creating) | Grep for "Repository" |
| `reverse_engineering_jpa_entity_by_name` | Generate entity structure from DB table | Manual schema inspection |
| `create_jpa_entity` | Create a complete entity with all annotations | Write file manually |
| `create_or_update_entity_attribute` | Add or modify entity field | Edit Java file directly |
| `delete_entity_attribute` | Remove entity field | Edit Java file directly |
| `create_spring_data_repository` | Generate repository interface | Write interface manually |

---

## Workflow

```
Creating entity?
  find_jpa_entities (check + get package)
    → create_jpa_entity
      → create_spring_data_repository

Modifying entity?
  get_jpa_entity_by_name (get FQN + current state)
    → create_or_update_entity_attribute / delete_entity_attribute

Adding relationship?
  get_jpa_entity_by_name (both entities)
    → create_or_update_entity_attribute (owning side: ManyToOne + joinColumn)
    → create_or_update_entity_attribute (inverse side: OneToMany + mappedBy)

From database?
  reverse_engineering_jpa_entity_by_name (get columns)
    → create_jpa_entity → create_spring_data_repository

Auditing domain?
  find_jpa_entities + find_spring_data_repositories → cross-reference
```

---

## Reference Files

- **references/tool-schemas.md** — Full input/output schemas for all 8 tools
- **references/examples.md** — 6 end-to-end worked examples (entity, relationship, reverse-engineering, audit)
- **references/patterns.md** — Common operation sequences and attribute property templates
- **references/best-practices.md** — Rules, anti-patterns, decision tree, troubleshooting, relationship ownership, DB migration reminders

---

## Next Steps

After entity/repository operations, use:
- **intellij-implementation** skill for service layer, file editing, renaming
- **intellij-testing** skill to build and run tests to validate changes
