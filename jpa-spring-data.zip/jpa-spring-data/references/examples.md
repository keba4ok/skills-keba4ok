# JPA Spring Data — Examples

End-to-end examples for the most common JPA operations. Each example shows the exact tool call sequence.

---

## Example 1: Create a New Entity with Repository

**Task:** Create a `Product` entity in a project where other entities already exist.

```
1. Load tools
   ToolSearch: query="+jetbrains jpa"

2. Discover existing entities (observe package pattern)
   find_jpa_entities(projectPath: "/path/to/project")
   → entities[0].packageName = "com.example.domain"

3. Create entity with attributes
   create_jpa_entity(
     entityName: "Product",
     entityPackage: "com.example.domain",
     tableName: "products",
     projectPath: "/path/to/project",
     attributes: [
       {name: "id", type: "Long", isId: true,
        idGenerationProperties: {generatedStrategy: "IDENTITY"},
        columnProperties: {}, relationshipProperties: {},
        collectionProperties: {}, embeddedProperties: {}},
       {name: "name", type: "String", isId: false,
        columnProperties: {nullable: false, length: 255},
        idGenerationProperties: {}, relationshipProperties: {},
        collectionProperties: {}, embeddedProperties: {}},
       {name: "price", type: "BigDecimal", isId: false,
        columnProperties: {nullable: false, precision: 10, scale: 2},
        idGenerationProperties: {}, relationshipProperties: {},
        collectionProperties: {}, embeddedProperties: {}},
       {name: "createdAt", type: "LocalDateTime", isId: false,
        columnProperties: {nullable: false, updatable: false},
        idGenerationProperties: {}, relationshipProperties: {},
        collectionProperties: {}, embeddedProperties: {}}
     ]
   )

4. Create repository
   create_spring_data_repository(
     repositoryClassName: "ProductRepository",
     entityName: "Product",
     projectPath: "/path/to/project"
   )
```

---

## Example 2: Add a Field to an Existing Entity

**Task:** Add `email` (unique, non-null) to the `User` entity.

```
1. Get current entity structure and FQN
   get_jpa_entity_by_name(entityName: "User", projectPath: "/path/to/project")
   → packageName: "com.example.domain"
   → FQN: "com.example.domain.User"

2. Add the attribute
   create_or_update_entity_attribute(
     entityFqn: "com.example.domain.User",
     name: "email",
     type: "String",
     columnProperties: {nullable: false, unique: true, length: 320},
     idGenerationProperties: {},
     relationshipProperties: {},
     collectionProperties: {},
     embeddedProperties: {},
     projectPath: "/path/to/project"
   )
```

**Note:** Inform user that a database migration is required to add the `email` column.

---

## Example 3: Create a Bidirectional @OneToMany / @ManyToOne

**Task:** Add a User ↔ Order relationship (one User has many Orders).

```
1. Inspect both entities
   get_jpa_entity_by_name(entityName: "User", projectPath: "/path/to/project")
   get_jpa_entity_by_name(entityName: "Order", projectPath: "/path/to/project")
   → Get FQNs: "com.example.domain.User", "com.example.domain.Order"

2. Add owning side: Order → User (ManyToOne, holds the foreign key)
   create_or_update_entity_attribute(
     entityFqn: "com.example.domain.Order",
     name: "user",
     type: "User",
     isId: false,
     relationshipProperties: {relationship: "ManyToOne", joinColumn: "user_id", fetch: "LAZY"},
     columnProperties: {}, idGenerationProperties: {},
     collectionProperties: {}, embeddedProperties: {},
     projectPath: "/path/to/project"
   )

3. Add inverse side: User → Orders (OneToMany, no FK)
   create_or_update_entity_attribute(
     entityFqn: "com.example.domain.User",
     name: "orders",
     type: "List<Order>",
     isId: false,
     relationshipProperties: {
       relationship: "OneToMany",
       mappedBy: "user",
       cascade: "ALL",
       orphanRemoval: true,
       fetch: "LAZY"
     },
     columnProperties: {}, idGenerationProperties: {},
     collectionProperties: {}, embeddedProperties: {},
     projectPath: "/path/to/project"
   )

4. Verify both entities
   get_jpa_entity_by_name(entityName: "User", projectPath: "/path/to/project")
   get_jpa_entity_by_name(entityName: "Order", projectPath: "/path/to/project")
```

---

## Example 4: Reverse Engineer Entity from Database Table

**Task:** The `orders` table already exists in the database. Create an entity from it.

```
1. Get table structure
   reverse_engineering_jpa_entity_by_name(
     entityTableName: "orders",
     projectPath: "/path/to/project"
   )
   → attributes: ["id: Long", "total_amount: BigDecimal", "status: String", "created_at: Timestamp"]

2. Check existing entities (find package)
   find_jpa_entities(projectPath: "/path/to/project")
   → packageName: "com.example.domain"

3. Create entity (map snake_case → camelCase)
   create_jpa_entity(
     entityName: "Order",
     entityPackage: "com.example.domain",
     tableName: "orders",
     projectPath: "/path/to/project",
     attributes: [
       {name: "id", type: "Long", isId: true,
        idGenerationProperties: {generatedStrategy: "IDENTITY"},
        columnProperties: {}, relationshipProperties: {},
        collectionProperties: {}, embeddedProperties: {}},
       {name: "totalAmount", type: "BigDecimal", isId: false,
        column: "total_amount",
        columnProperties: {nullable: false, precision: 10, scale: 2},
        idGenerationProperties: {}, relationshipProperties: {},
        collectionProperties: {}, embeddedProperties: {}},
       {name: "status", type: "String", isId: false,
        columnProperties: {nullable: false, length: 50},
        idGenerationProperties: {}, relationshipProperties: {},
        collectionProperties: {}, embeddedProperties: {}},
       {name: "createdAt", type: "LocalDateTime", isId: false,
        column: "created_at",
        columnProperties: {nullable: false, updatable: false},
        idGenerationProperties: {}, relationshipProperties: {},
        collectionProperties: {}, embeddedProperties: {}}
     ]
   )

4. Create repository
   create_spring_data_repository(
     repositoryClassName: "OrderRepository",
     entityName: "Order",
     projectPath: "/path/to/project"
   )
```

---

## Example 5: Remove a Field from Entity

**Task:** Remove the deprecated `legacyCode` field from `Product`.

```
1. Get current entity structure
   get_jpa_entity_by_name(entityName: "Product", projectPath: "/path/to/project")
   → FQN: "com.example.domain.Product"
   → Confirm "legacyCode" attribute exists and has no dependent relationships

2. Delete the attribute
   delete_entity_attribute(
     entityFqn: "com.example.domain.Product",
     name: "legacyCode",
     projectPath: "/path/to/project"
   )
```

**Note:** Inform user that a database migration is required to drop the `legacy_code` column.

---

## Example 6: Audit the Domain Model

**Task:** "Show me all entities and check if each has a repository."

```
1. Get all entities
   find_jpa_entities(projectPath: "/path/to/project")
   → entities: [User, Order, Product, Category]

2. Get all repositories
   find_spring_data_repositories(projectPath: "/path/to/project")
   → repositories: [UserRepository(User), OrderRepository(Order), ProductRepository(Product)]

3. Cross-reference
   → Category has NO repository → suggest creating CategoryRepository

4. (Optional) Create missing repository
   create_spring_data_repository(
     repositoryClassName: "CategoryRepository",
     entityName: "Category",
     projectPath: "/path/to/project"
   )
```
