# JPA Spring Data MCP Tool Schemas

Complete input/output schemas for all `mcp__jetbrains__` JPA tools.

## Table of Contents

- [create_jpa_entity](#create_jpa_entity)
- [create_or_update_entity_attribute](#create_or_update_entity_attribute)
- [delete_entity_attribute](#delete_entity_attribute)
- [find_jpa_entities](#find_jpa_entities)
- [get_jpa_entity_by_name](#get_jpa_entity_by_name)
- [create_spring_data_repository](#create_spring_data_repository)
- [find_spring_data_repositories](#find_spring_data_repositories)
- [reverse_engineering_jpa_entity_by_name](#reverse_engineering_jpa_entity_by_name)

---

## create_jpa_entity

Create complete JPA entities with Spring Data integration.

**Required:** `entityName`

**Optional:** `entityPackage`, `language` (Java|Kotlin), `moduleName`, `tableName`, `attributes`, `inheritanceType`, `discriminatorColumn`, `discriminatorType`, `discriminatorValue`, `superclass`, `mappedSuperclass`, `compositeId`, `indexes`, `namedQueries`, `projectPath`

### Attribute Schema

Each attribute in the `attributes` array requires:

```json
{
  "name": "string",
  "type": "string",
  "isId": "boolean",
  "columnProperties": {
    "nullable": "boolean|null",
    "length": "integer|null",
    "unique": "boolean|null",
    "columnDefinition": "string|null",
    "precision": "integer|null",
    "scale": "integer|null",
    "insertable": "boolean|null",
    "updatable": "boolean|null",
    "lob": "boolean|null",
    "temporal": "string|null",
    "version": "boolean|null"
  },
  "idGenerationProperties": {
    "generatedStrategy": "AUTO|IDENTITY|SEQUENCE|TABLE|UUID",
    "sequenceName": "string|null",
    "initialValue": "integer|null",
    "allocationSize": "integer|null",
    "generatorName": "string|null",
    "pkColumnName": "string|null",
    "valueColumnName": "string|null"
  },
  "relationshipProperties": {
    "relationship": "OneToOne|OneToMany|ManyToOne|ManyToMany",
    "joinColumn": "string|null",
    "mappedBy": "string|null",
    "cascade": "string|null",
    "fetch": "LAZY|EAGER",
    "orphanRemoval": "boolean|null",
    "joinTable": "string|null",
    "inverseJoinColumn": "string|null"
  },
  "collectionProperties": {
    "elementCollection": "boolean|null",
    "collectionTable": "string|null"
  },
  "embeddedProperties": {
    "embedded": "boolean|null",
    "attributeOverrides": [{"attributeName": "string", "column": "string"}]
  }
}
```

### Index Schema

```json
{
  "name": "string|null",
  "columnList": ["string"],
  "unique": "boolean",
  "constraint": "boolean"
}
```

### Output

Returns `status` (Ask user | Success | Failure), `message`, `nextSuggestedActions`, and `resultFiles` array.

---

## create_or_update_entity_attribute

Add or modify attributes on existing JPA entities.

**Required:** `entityFqn`, `name`, `type`

**Optional:** `isId`, `column`, `columnProperties`, `idGenerationProperties`, `relationshipProperties`, `collectionProperties`, `embeddedProperties`, `projectPath`

Property schemas are identical to `create_jpa_entity` attribute schema above.

### Output

Same as `create_jpa_entity`.

---

## delete_entity_attribute

Remove attributes from JPA entities.

**Required:** `entityFqn`, `name`

**Optional:** `projectPath`

### Output

Returns `name`, `path`, optionally `content` and `description`.

---

## find_jpa_entities

Discover all JPA entities in the project.

**Required:** none

**Optional:** `entityPackage`, `moduleName`, `projectPath`

### Output

Returns `entities` array with full entity definitions (name, tableName, attributes, inheritance info, indexes, namedQueries).

---

## get_jpa_entity_by_name

Get detailed information about a specific JPA entity.

**Required:** `entityName`

**Optional:** `projectPath`

### Output

Returns `entities` array with full entity definitions (same structure as `find_jpa_entities`).

---

## create_spring_data_repository

Generate Spring Data JPA repository interfaces.

**Required:** `repositoryClassName`

**Optional:** `entityName`, `packageName`, `sourceRootType` (source|test), `moduleName`, `baseRepositoryClass`, `projectPath`

### Output

Returns `file` object with `name`, `path`, optionally `content`, `entity`, `description`.

---

## find_spring_data_repositories

Discover existing Spring Data repositories.

**Required:** none

**Optional:** `entityName`, `moduleName`, `searchInLibraries`, `projectPath`

### Output

Returns `repositories` array with `name`, `path`, optionally `content`, `entity`, `description`.

---

## reverse_engineering_jpa_entity_by_name

Reverse engineer a JPA entity from a database table.

**Required:** `entityTableName`

**Optional:** `projectPath`

### Output

Returns `attributes` array of strings.
