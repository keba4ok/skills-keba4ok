# JPA Spring Data — Patterns

Common operation patterns for quick reference. Each pattern is a minimal sequence.

---

## Discovery Patterns

### Before creating any entity
```
find_jpa_entities → check package, avoid duplicates
```

### Before modifying any entity
```
get_jpa_entity_by_name → get FQN + current structure
```

### Before creating any repository
```
find_spring_data_repositories → check if one already exists
```

### Domain model audit
```
find_jpa_entities → find_spring_data_repositories → cross-reference
```

---

## Creation Patterns

### Entity + Repository (standard)
```
find_jpa_entities (check)
  → create_jpa_entity
    → create_spring_data_repository
```

### Entity from DB table
```
reverse_engineering_jpa_entity_by_name (get columns)
  → find_jpa_entities (find package)
    → create_jpa_entity (mapped attributes)
      → create_spring_data_repository
```

---

## Modification Patterns

### Add field to existing entity
```
get_jpa_entity_by_name (get FQN + check)
  → create_or_update_entity_attribute (use FQN)
```

### Remove field from existing entity
```
get_jpa_entity_by_name (confirm exists + check deps)
  → delete_entity_attribute (use FQN)
```

### Add @Version for optimistic locking
```
get_jpa_entity_by_name (get FQN)
  → create_or_update_entity_attribute(
       name: "version", type: "Long",
       columnProperties: {version: true, nullable: false}
     )
```

### Add audit timestamps
```
get_jpa_entity_by_name (get FQN)
  → create_or_update_entity_attribute(
       name: "createdAt", type: "LocalDateTime",
       columnProperties: {nullable: false, updatable: false}
     )
  → create_or_update_entity_attribute(
       name: "updatedAt", type: "LocalDateTime",
       columnProperties: {nullable: false}
     )
```

---

## Relationship Patterns

### @ManyToOne (owning side only)
```
get_jpa_entity_by_name("ChildEntity")
  → create_or_update_entity_attribute(
       entityFqn: "..ChildEntity",
       name: "parent", type: "ParentEntity",
       relationshipProperties: {relationship: "ManyToOne", joinColumn: "parent_id", fetch: "LAZY"}
     )
```

### Bidirectional @OneToMany ↔ @ManyToOne
```
get_jpa_entity_by_name("Parent") + get_jpa_entity_by_name("Child")
  → create_or_update_entity_attribute on Child (ManyToOne + joinColumn)
  → create_or_update_entity_attribute on Parent (OneToMany + mappedBy)
  → verify: get_jpa_entity_by_name on both
```

### @ManyToMany
```
get_jpa_entity_by_name("Entity1") + get_jpa_entity_by_name("Entity2")
  → create_or_update_entity_attribute on owning side:
       relationshipProperties: {
         relationship: "ManyToMany",
         joinTable: "entity1_entity2",
         joinColumn: "entity1_id",
         inverseJoinColumn: "entity2_id",
         fetch: "LAZY"
       }
  → (optional) create_or_update_entity_attribute on inverse side:
       relationshipProperties: {relationship: "ManyToMany", mappedBy: "entity2s"}
```

### @OneToOne
```
get_jpa_entity_by_name on both entities
  → create_or_update_entity_attribute on owning entity:
       relationshipProperties: {relationship: "OneToOne", joinColumn: "profile_id", fetch: "LAZY"}
  → (optional) inverse side:
       relationshipProperties: {relationship: "OneToOne", mappedBy: "profile"}
```

---

## Attribute Property Templates

### ID (auto-increment)
```json
{"isId": true, "idGenerationProperties": {"generatedStrategy": "IDENTITY"},
 "columnProperties": {}, "relationshipProperties": {},
 "collectionProperties": {}, "embeddedProperties": {}}
```

### ID (UUID)
```json
{"isId": true, "idGenerationProperties": {"generatedStrategy": "UUID"},
 "columnProperties": {}, "relationshipProperties": {},
 "collectionProperties": {}, "embeddedProperties": {}}
```

### Non-null string
```json
{"columnProperties": {"nullable": false, "length": 255},
 "idGenerationProperties": {}, "relationshipProperties": {},
 "collectionProperties": {}, "embeddedProperties": {}}
```

### BigDecimal (money)
```json
{"columnProperties": {"nullable": false, "precision": 19, "scale": 2},
 "idGenerationProperties": {}, "relationshipProperties": {},
 "collectionProperties": {}, "embeddedProperties": {}}
```

### ManyToOne
```json
{"relationshipProperties": {"relationship": "ManyToOne", "joinColumn": "parent_id", "fetch": "LAZY"},
 "columnProperties": {}, "idGenerationProperties": {},
 "collectionProperties": {}, "embeddedProperties": {}}
```

### OneToMany (inverse)
```json
{"relationshipProperties": {"relationship": "OneToMany", "mappedBy": "parent",
 "cascade": "ALL", "orphanRemoval": true, "fetch": "LAZY"},
 "columnProperties": {}, "idGenerationProperties": {},
 "collectionProperties": {}, "embeddedProperties": {}}
```
