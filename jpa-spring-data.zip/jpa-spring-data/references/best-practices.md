# JPA Spring Data — Best Practices

---

## Core Rules

| Rule | Why |
|---|---|
| Always discover before creating | Prevents duplicates, learns package conventions |
| Always use FQN for modifications | Simple name fails if ambiguous or in multi-module project |
| Always complete entity + repository | Incomplete implementation blocks service layer |
| Always include all 5 property objects | Missing any causes tool failure |
| Always handle `status: "Ask user"` | Read the `message` — it contains disambiguation options |
| Always follow `nextSuggestedActions` | Tool knows the logical next step |
| Always inform user about DB migrations | Entity changes ≠ automatic schema changes |

---

## Anti-Patterns

### ❌ Creating an entity without checking what exists
```
# WRONG
create_jpa_entity(entityName: "Product", ...)

# CORRECT
find_jpa_entities(...)  → then create
```

### ❌ Guessing the FQN
```
# WRONG
create_or_update_entity_attribute(entityFqn: "User", ...)

# CORRECT
get_jpa_entity_by_name("User")  → get real FQN  → then update
```

### ❌ Omitting property objects
```
# WRONG - will fail
{"name": "email", "type": "String", "columnProperties": {"nullable": false}}

# CORRECT - all 5 objects required
{"name": "email", "type": "String", "isId": false,
 "columnProperties": {"nullable": false, "length": 320},
 "idGenerationProperties": {}, "relationshipProperties": {},
 "collectionProperties": {}, "embeddedProperties": {}}
```

### ❌ Incomplete bidirectional relationships
```
# WRONG — only one side
create_or_update_entity_attribute(Order, user, ManyToOne)
# missing inverse side on User!

# CORRECT — both sides
create_or_update_entity_attribute(Order, user, ManyToOne + joinColumn)
create_or_update_entity_attribute(User, orders, OneToMany + mappedBy)
```

---

## Decision Tree

```
Working with JPA/Spring Data?
│
├─ Creating new entity?
│  └─> find_jpa_entities → create_jpa_entity → create_spring_data_repository
│
├─ Modifying existing entity?
│  ├─ Adding/changing field?
│  │  └─> get_jpa_entity_by_name → create_or_update_entity_attribute
│  └─ Removing field?
│     └─> get_jpa_entity_by_name → delete_entity_attribute
│
├─ Adding relationship?
│  └─> get_jpa_entity_by_name (both) → create_or_update_entity_attribute (owning) → create_or_update_entity_attribute (inverse)
│
├─ Creating repository?
│  └─> find_spring_data_repositories → create_spring_data_repository
│
├─ Auditing domain model?
│  └─> find_jpa_entities + find_spring_data_repositories → cross-reference
│
└─ Working with existing database?
   └─> reverse_engineering_jpa_entity_by_name → create_jpa_entity
```

---

## Troubleshooting

| Issue | Cause | Fix |
|---|---|---|
| `status: "Ask user"` | Disambiguation needed | Read `message`, present options to user, re-call with clarified params |
| Attribute tool call fails | Missing property objects | Include all 5 objects, even if empty `{}` |
| "Entity not found" | Wrong name or wrong module | Use `find_jpa_entities` to get exact name and FQN |
| Relationship creation fails | Type name mismatch | Type must match entity class name exactly (case-sensitive) |
| Repository already exists | Duplicate creation | Use `find_spring_data_repositories` to check first |
| `mappedBy` error | Wrong field name reference | Verify the owning-side field name matches `mappedBy` value |

---

## Relationship Ownership Rules

| Relationship | Owning Side | Inverse Side |
|---|---|---|
| `@ManyToOne` ↔ `@OneToMany` | `@ManyToOne` side (has `@JoinColumn`) | `@OneToMany` side (has `mappedBy`) |
| `@ManyToMany` | Declared with `@JoinTable` | Declared with `mappedBy` |
| `@OneToOne` | Side with `@JoinColumn` | Side with `mappedBy` |

**Rule:** The owning side holds the foreign key column. The inverse side is a "mirror" — it only reflects the relationship defined on the owning side.

---

## Database Migration Reminders

Always inform the user when a migration is needed:

| Operation | Migration Needed |
|---|---|
| Create new entity | `CREATE TABLE` |
| Add new attribute (non-relationship) | `ALTER TABLE ADD COLUMN` |
| Remove attribute | `ALTER TABLE DROP COLUMN` |
| Add `@ManyToOne` (owning) | `ALTER TABLE ADD COLUMN <fk_column>` |
| Add `@OneToMany` (inverse only) | No schema change needed |
| Add `@ManyToMany` | `CREATE TABLE <join_table>` |
