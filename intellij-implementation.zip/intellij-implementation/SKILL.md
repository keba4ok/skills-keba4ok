---
name: intellij-implementation
description: >
  Code creation, modification, refactoring, and JPA/Spring Data entity management using
  IntelliJ IDEA MCP tools. Use this skill whenever you need to create, modify, or refactor
  code in an IntelliJ/Spring Boot project: create new source files; modify existing files
  with targeted text replacement; rename symbols across the entire project; reformat code;
  create JPA entities with annotations and relationships; add/modify/remove entity
  attributes; create Spring Data JPA repository interfaces; implement entity relationships;
  add optimistic locking, audit fields, or composite keys; or run terminal commands.
  Triggers on: create file, create entity, add/modify/remove field, add relationship,
  create repository, rename symbol, replace text, reformat, build project, run command.
---

# IntelliJ Implementation Skill

Code creation, modification, refactoring, and JPA/Spring Data entity management using IntelliJ IDEA MCP tools.

---

## CRITICAL: MANDATORY TOOL USAGE POLICY

**YOU MUST USE MCP TOOLS FOR ALL IMPLEMENTATION TASKS. THIS IS NON-NEGOTIABLE.**

- **NEVER** write `@Entity` class files manually — use `mcp__jetbrains__create_jpa_entity`
- **NEVER** edit JPA entity fields with text editing — use `mcp__jetbrains__create_or_update_entity_attribute`
- **NEVER** delete entity fields by text editing — use `mcp__jetbrains__delete_entity_attribute`
- **NEVER** create Spring Data repositories manually — use `mcp__jetbrains__create_spring_data_repository`
- **NEVER** rename symbols with text search-and-replace — use `mcp__jetbrains__rename_refactoring`
- **NEVER** edit files with shell commands (`sed`, `awk`, `echo >`) — use `mcp__jetbrains__replace_text_in_file`
- **NEVER** call `replace_text_in_file` without reading the file first — `oldText` must match exactly
- **ALWAYS** call `mcp__jetbrains__build_project` after every code change
- **ALWAYS** call `mcp__jetbrains__reformat_file` after creating or significantly editing any file
- **ALWAYS** explore first using the **intellij-exploration** skill before implementing

---

## When to Use This Skill

- Create new source files, configs, SQL migrations, test files
- Modify existing file content with targeted text replacement
- Rename symbols (classes, methods, fields) across the entire project
- Create JPA entities with full annotation support
- Add, modify, or remove entity attributes and relationships
- Create Spring Data JPA repository interfaces
- Build the project to verify compilation

## Trigger Keywords

"create a new file", "create entity", "add field", "add attribute", "modify field", "add relationship", "@OneToMany", "@ManyToOne", "remove field", "create repository", "rename symbol", "replace text", "reformat", "build project", "compile"

---

## Available Tools

All tools use the `mcp__jetbrains__` prefix.

### File Creation & Editing

| Tool | Purpose | Never Do Instead |
|---|---|---|
| `create_new_file` | Create new file with content | `echo >`, shell heredocs |
| `replace_text_in_file` | Targeted find-and-replace | `sed`, `awk` |
| `rename_refactoring` | Rename symbol + update all references | Text search-and-replace |
| `reformat_file` | Apply IDE code formatting | — |

### JPA Entity & Repository

| Tool | Purpose | Never Do Instead |
|---|---|---|
| `create_jpa_entity` | Create complete @Entity class | Write file manually |
| `create_or_update_entity_attribute` | Add or modify entity field | Edit Java file directly |
| `delete_entity_attribute` | Remove entity field | Edit Java file directly |
| `create_spring_data_repository` | Generate repository interface | Write interface manually |

### Build & Terminal

| Tool | Purpose | When |
|---|---|---|
| `build_project` | Build project, return compilation errors | After EVERY code change |
| `execute_terminal_command` | Run shell commands in IDE terminal | When no run config covers it |

---

## Workflow

```
1. EXPLORE (intellij-exploration skill first)
   find_jpa_entities / get_jpa_entity_by_name / find_spring_data_repositories
   find_files_by_name_keyword / get_file_text_by_path

2. IMPLEMENT
   New entity     → create_jpa_entity → create_spring_data_repository
   Add field      → get_jpa_entity_by_name → create_or_update_entity_attribute
   Remove field   → get_jpa_entity_by_name → delete_entity_attribute
   New file       → create_new_file
   Edit file      → get_file_text_by_path → replace_text_in_file
   Rename         → rename_refactoring

3. FORMAT
   reformat_file (after every create or significant edit)

4. VALIDATE
   build_project (mandatory — always)
```

---

## Reference Files

- **references/tool-reference.md** — All 10 tools: parameters, return values, examples, attribute patterns
- **references/examples.md** — 6 end-to-end implementation examples (entity, relationship, rename, file edit)
- **references/patterns.md** — Implementation sequences: entity, relationship, file editing, build patterns
- **references/best-practices.md** — Rules, anti-patterns, tool selection guide, checklists, common errors

## Next Steps After Implementation

Use the **intellij-testing** skill to:
- Build the project to validate compilation
- Run unit or integration tests
- Check file problems with IDE inspections
