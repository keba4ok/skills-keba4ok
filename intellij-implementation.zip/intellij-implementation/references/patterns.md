# IntelliJ Implementation — Patterns

Common implementation workflows for quick reference.

---

## Standard Implementation Sequence

```
EXPLORE (always first — intellij-exploration skill)
  find_jpa_entities / find_spring_data_repositories / get_jpa_entity_by_name
  list_directory_tree / find_files_by_name_keyword / get_file_text_by_path

IMPLEMENT
  create_jpa_entity / create_or_update_entity_attribute / delete_entity_attribute
  create_spring_data_repository
  create_new_file / replace_text_in_file / rename_refactoring

FORMAT
  reformat_file  (after every create or significant edit)

VALIDATE
  build_project  (mandatory after every change)
```

---

## Entity Patterns

### Create entity (full sequence)
```
find_jpa_entities (check for duplicate + get package)
  → create_jpa_entity (with attributes)
    → create_spring_data_repository
      → build_project
```

### Add field to entity
```
get_jpa_entity_by_name (get FQN)
  → create_or_update_entity_attribute (use FQN)
    → build_project
```

### Remove field from entity
```
get_jpa_entity_by_name (confirm exists + check deps)
  → delete_entity_attribute (use FQN)
    → build_project
```

### Add @Version for optimistic locking
```
get_jpa_entity_by_name (get FQN)
  → create_or_update_entity_attribute(
       name: "version", type: "Long",
       columnProperties: {version: true, nullable: false}
     )
  → build_project
```

---

## Relationship Patterns

### Add ManyToOne (owning side only)
```
get_jpa_entity_by_name("ChildEntity") (get FQN + check for existing field)
  → create_or_update_entity_attribute(
       entityFqn: "..ChildEntity",
       relationshipProperties: {relationship: "ManyToOne", joinColumn: "parent_id", fetch: "LAZY"}
     )
  → build_project
```

### Add bidirectional OneToMany ↔ ManyToOne
```
get_jpa_entity_by_name(both entities) (get both FQNs)
  → create_or_update_entity_attribute (child entity, ManyToOne + joinColumn)
  → create_or_update_entity_attribute (parent entity, OneToMany + mappedBy)
  → build_project
  → get_jpa_entity_by_name (both, to verify)
```

### Add ManyToMany
```
get_jpa_entity_by_name(both entities)
  → create_or_update_entity_attribute (owning side, ManyToMany + joinTable + joinColumn + inverseJoinColumn)
  → create_or_update_entity_attribute (inverse side, ManyToMany + mappedBy)
  → build_project
```

---

## File Editing Patterns

### Edit existing file (add annotation, change code)
```
get_file_text_by_path (read exact text first!)
  → replace_text_in_file (oldText = exact match, newText = replacement)
    → reformat_file
      → build_project
```

### Rename symbol across project
```
find_files_by_name_keyword (locate the file)
  → rename_refactoring (pathInProject, symbolName, newName)
    → build_project (verify all references updated)
```

### Create new non-entity file
```
find_files_by_name_keyword (find similar file to confirm package path)
  → create_new_file (pathInProject, text with full content)
    → reformat_file
      → build_project
```

---

## Build Patterns

### Standard build after change
```
build_project(projectPath: "...")
→ check errors array
→ if empty: success
→ if errors: fix each, rebuild
```

### Full rebuild (stale artifacts)
```
build_project(rebuild: true, projectPath: "...")
```

### Build, then run specific test
```
build_project()
  → get_run_configurations()
    → execute_run_configuration(configurationName: "UserServiceTest")
```

---

## Attribute Property Object Reference (All Required)

Every attribute in `create_jpa_entity` or `create_or_update_entity_attribute` needs all 5:

```json
{
  "name": "fieldName",
  "type": "TypeName",
  "isId": false,
  "columnProperties": {},
  "idGenerationProperties": {},
  "relationshipProperties": {},
  "collectionProperties": {},
  "embeddedProperties": {}
}
```

Missing any of these → tool failure.
