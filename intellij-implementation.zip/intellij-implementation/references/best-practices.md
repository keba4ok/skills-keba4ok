# IntelliJ Implementation — Best Practices

---

## Core Rules

| Rule | Why |
|---|---|
| Always explore before implementing | Know the existing structure before changing it |
| Always call `build_project` after every change | Catch compilation errors immediately |
| Always call `reformat_file` after every create/edit | Maintain consistent code style |
| Use `create_jpa_entity` — never manually write entity files | Tools handle JPA annotation correctness, relationship integrity |
| Use `rename_refactoring` — never text-replace symbol names | Refactoring updates ALL references; text-replace breaks them |
| Always read the file before `replace_text_in_file` | `oldText` must match exactly including whitespace |
| Always use FQN in entity modification tools | Simple names fail with ambiguous or multi-module setups |
| Include all 5 property objects in every attribute | Missing any causes tool failure |

---

## Anti-Patterns

### ❌ Manually writing @Entity files
```
# WRONG
create_new_file(text: "@Entity\npublic class User {...}")
# Missing annotations, wrong placement, breaks IDE index

# CORRECT
create_jpa_entity(entityName: "User", attributes: [...])
```

### ❌ Using text replace to rename a symbol
```
# WRONG
replace_text_in_file(oldText: "UserService", newText: "CustomerService", replaceAll: true)
# Breaks imports, string literals, partial matches, annotation values

# CORRECT
rename_refactoring(symbolName: "UserService", newName: "CustomerService")
# Updates all references across entire project, IDE-aware
```

### ❌ Replacing text without reading first
```
# WRONG
replace_text_in_file(oldText: "public List<User> findAll() {", ...)
# Likely whitespace mismatch → "no occurrences found" error

# CORRECT
get_file_text_by_path(...) → copy exact text with indentation → replace_text_in_file
```

### ❌ Not building after changes
```
# WRONG
create_jpa_entity(...) → tell user "done!"

# CORRECT
create_jpa_entity(...) → build_project() → report result
```

### ❌ Forgetting to reformat
```
# WRONG
create_new_file(text: "...messy indentation...")

# CORRECT
create_new_file(...) → reformat_file(path: "...")
```

---

## Tool Selection Guide

```
Creating something new?
  ├── New JPA entity             → create_jpa_entity
  ├── New repository             → create_spring_data_repository
  └── Other new file             → create_new_file

Modifying something existing?
  ├── Add/change JPA attribute   → create_or_update_entity_attribute
  ├── Remove JPA attribute       → delete_entity_attribute
  ├── Change code text           → replace_text_in_file (read file first!)
  └── Rename a symbol            → rename_refactoring (never text-replace)

After any change?
  └── build_project              (ALWAYS — mandatory)

After creating or editing a file?
  └── reformat_file              (ALWAYS — apply IDE style)
```

---

## Checklist: Creating an Entity

Before:
- [ ] Called `find_jpa_entities` → no duplicate exists
- [ ] Noted target package from existing entities
- [ ] Planned all attributes (ID strategy, constraints, relationships)
- [ ] Determined relationship ownership (ManyToOne side holds FK)

After:
- [ ] Called `build_project` → 0 errors
- [ ] Called `get_jpa_entity_by_name` → structure looks correct
- [ ] Called `create_spring_data_repository` → repository created
- [ ] Informed user about DB migration needs

---

## Checklist: Bidirectional Relationship

- [ ] Called `get_jpa_entity_by_name` on both entities → have both FQNs
- [ ] Added owning side (ManyToOne + `joinColumn`)
- [ ] Added inverse side (OneToMany + `mappedBy` matching owning field name)
- [ ] Called `build_project` → 0 errors
- [ ] Verified both sides with `get_jpa_entity_by_name`
- [ ] Informed user: owning side's new FK column needs DB migration

---

## Common Errors and Fixes

| Error | Likely Cause | Fix |
|---|---|---|
| `"no occurrences found"` in replace_text_in_file | `oldText` doesn't exactly match file content | Re-read file with `get_file_text_by_path`, copy exact text |
| `status: "Ask user"` from entity tool | Ambiguous package or module | Read the `message`, present options to user, re-call with clarified params |
| `cannot find symbol` after build | Missing import or wrong type reference | Check entity type names are correct; add import in file |
| `duplicate class` after build | Two classes with same FQN | One was created manually alongside tool-created one — delete the duplicate |
| `"Failure"` from create_jpa_entity | Missing required fields or invalid config | Read the `message` field in the response for specific cause |
