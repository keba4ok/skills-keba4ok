# IntelliJ Implementation — Examples

End-to-end examples for common implementation tasks.

---

## Example 1: Create a JPA Entity

**Task:** Create a `Category` entity with a name and description.

```
1. Explore first (intellij-exploration skill)
   find_jpa_entities(projectPath: "/path/to/project")
   → package: "com.example.domain", no Category exists

2. Create the entity
   create_jpa_entity(
     entityName: "Category",
     entityPackage: "com.example.domain",
     tableName: "categories",
     projectPath: "/path/to/project",
     attributes: [
       {name: "id", type: "Long", isId: true,
        idGenerationProperties: {generatedStrategy: "IDENTITY"},
        columnProperties: {}, relationshipProperties: {},
        collectionProperties: {}, embeddedProperties: {}},
       {name: "name", type: "String", isId: false,
        columnProperties: {nullable: false, unique: true, length: 100},
        idGenerationProperties: {}, relationshipProperties: {},
        collectionProperties: {}, embeddedProperties: {}},
       {name: "description", type: "String", isId: false,
        columnProperties: {length: 500},
        idGenerationProperties: {}, relationshipProperties: {},
        collectionProperties: {}, embeddedProperties: {}}
     ]
   )

3. Create repository
   create_spring_data_repository(
     repositoryClassName: "CategoryRepository",
     entityName: "Category",
     projectPath: "/path/to/project"
   )

4. Build to validate
   build_project(projectPath: "/path/to/project")
```

---

## Example 2: Add a Field to an Existing Entity

**Task:** Add `phoneNumber` (nullable, max 20 chars) to `User`.

```
1. Get entity structure and FQN
   get_jpa_entity_by_name(entityName: "User", projectPath: "/path/to/project")
   → FQN: "com.example.domain.User"

2. Add the attribute
   create_or_update_entity_attribute(
     entityFqn: "com.example.domain.User",
     name: "phoneNumber",
     type: "String",
     columnProperties: {nullable: true, length: 20},
     idGenerationProperties: {},
     relationshipProperties: {},
     collectionProperties: {},
     embeddedProperties: {},
     projectPath: "/path/to/project"
   )

3. Build to validate
   build_project(projectPath: "/path/to/project")
```

---

## Example 3: Implement a Bidirectional Relationship

**Task:** Product belongs to Category (ManyToOne), Category has many Products (OneToMany).

```
1. Explore both entities
   get_jpa_entity_by_name(entityName: "Product", projectPath: "/path/to/project")
   → FQN: "com.example.domain.Product"
   get_jpa_entity_by_name(entityName: "Category", projectPath: "/path/to/project")
   → FQN: "com.example.domain.Category"

2. Add owning side: Product → Category (ManyToOne, has FK)
   create_or_update_entity_attribute(
     entityFqn: "com.example.domain.Product",
     name: "category",
     type: "Category",
     isId: false,
     relationshipProperties: {relationship: "ManyToOne", joinColumn: "category_id", fetch: "LAZY"},
     columnProperties: {}, idGenerationProperties: {},
     collectionProperties: {}, embeddedProperties: {},
     projectPath: "/path/to/project"
   )

3. Add inverse side: Category → Products (OneToMany)
   create_or_update_entity_attribute(
     entityFqn: "com.example.domain.Category",
     name: "products",
     type: "List<Product>",
     isId: false,
     relationshipProperties: {
       relationship: "OneToMany",
       mappedBy: "category",
       cascade: "ALL",
       fetch: "LAZY",
       orphanRemoval: true
     },
     columnProperties: {}, idGenerationProperties: {},
     collectionProperties: {}, embeddedProperties: {},
     projectPath: "/path/to/project"
   )

4. Build to validate
   build_project(projectPath: "/path/to/project")
```

---

## Example 4: Rename a Class Across the Project

**Task:** Rename `UserService` to `CustomerService`.

```
1. Find the file
   find_files_by_name_keyword(nameKeyword: "UserService", projectPath: "/path/to/project")
   → "src/main/java/com/example/service/UserService.java"

2. Rename (IDE-aware — updates ALL references)
   rename_refactoring(
     pathInProject: "src/main/java/com/example/service/UserService.java",
     symbolName: "UserService",
     newName: "CustomerService",
     projectPath: "/path/to/project"
   )

3. Build to validate
   build_project(projectPath: "/path/to/project")
```

---

## Example 5: Edit an Existing File

**Task:** Add `@Transactional(readOnly = true)` to the `findAll()` method in `UserService`.

```
1. Read the file (required before replace)
   get_file_text_by_path(
     pathInProject: "src/main/java/com/example/service/UserService.java",
     projectPath: "/path/to/project"
   )
   → Find exact text around findAll():
     "    public List<User> findAll() {"

2. Add the annotation
   replace_text_in_file(
     pathInProject: "src/main/java/com/example/service/UserService.java",
     oldText: "    public List<User> findAll() {",
     newText: "    @Transactional(readOnly = true)\n    public List<User> findAll() {",
     replaceAll: false,
     projectPath: "/path/to/project"
   )

3. Reformat the file
   reformat_file(
     path: "src/main/java/com/example/service/UserService.java",
     projectPath: "/path/to/project"
   )

4. Build to validate
   build_project(projectPath: "/path/to/project")
```

---

## Example 6: Create a New Service File

**Task:** Create `OrderService.java` in the service package.

```
1. Find existing service files to confirm package
   find_files_by_name_keyword(nameKeyword: "Service", projectPath: "/path/to/project")
   → "src/main/java/com/example/service/UserService.java"
   → package: "com.example.service"

2. Create the file
   create_new_file(
     pathInProject: "src/main/java/com/example/service/OrderService.java",
     text: "package com.example.service;\n\nimport org.springframework.stereotype.Service;\n\n@Service\npublic class OrderService {\n\n}\n",
     projectPath: "/path/to/project"
   )

3. Reformat
   reformat_file(
     path: "src/main/java/com/example/service/OrderService.java",
     projectPath: "/path/to/project"
   )

4. Build to validate
   build_project(projectPath: "/path/to/project")
```
