# Tool Reference - IntelliJ Implementation

Comprehensive documentation for all 10 implementation tools for creating, modifying, refactoring, and validating code.

---

## create_new_file

### Purpose
Creates a new file at a specified project-relative path, optionally with content. The primary tool for scaffolding non-JPA files.

### When to Use
- Creating new Java/Kotlin classes that are NOT JPA entities
- Creating configuration files, YAML, XML, SQL scripts
- Creating test files
- Creating documentation or resource files
- **Do NOT use for JPA entities — use `create_jpa_entity` instead**
- **Do NOT use for repositories — use `create_spring_data_repository` instead**

### Parameters

#### pathInProject (required)
- **Type:** String
- **Description:** Path relative to project root where the file will be created
- **Examples:**
  - `"src/main/java/com/example/service/UserService.java"`
  - `"src/main/resources/application-test.yml"`
  - `"src/test/java/com/example/service/UserServiceTest.java"`
  - `"src/main/resources/db/migration/V2__add_index.sql"`
- **Note:** Parent directories are created automatically

#### text (optional)
- **Type:** String
- **Description:** Initial file content
- **Guidance:** Provide complete file content when creating a new class:
  - Package declaration
  - Import statements
  - Class/interface body
  - Annotations
- **When to omit:** When creating an empty placeholder file

#### overwrite (optional)
- **Type:** Boolean
- **Default:** false
- **Description:** Whether to overwrite if file already exists
- **Caution:** Set to `true` only when intentionally replacing a file

#### projectPath (recommended)
- **Type:** String
- **Description:** Project root absolute path
- **Important:** ALWAYS pass if known

### Return Value
On success: confirmation message with created file path.
On failure: error message (e.g., file already exists if overwrite=false).

### Usage Examples

**Example 1: Create a service class**
```
Input: "Create a UserService class"
Tool Call:
{
  "pathInProject": "src/main/java/com/example/service/UserService.java",
  "text": "package com.example.service;\n\nimport org.springframework.stereotype.Service;\nimport lombok.RequiredArgsConstructor;\n\n@Service\n@RequiredArgsConstructor\npublic class UserService {\n    // TODO: implement\n}\n",
  "projectPath": "/path/to/project"
}
```

**Example 2: Create a test file**
```
Input: "Create a unit test for UserService"
Tool Call:
{
  "pathInProject": "src/test/java/com/example/service/UserServiceTest.java",
  "text": "package com.example.service;\n\nimport org.junit.jupiter.api.Test;\nimport static org.junit.jupiter.api.Assertions.*;\n\nclass UserServiceTest {\n    // TODO: add tests\n}\n",
  "projectPath": "/path/to/project"
}
```

**Example 3: Create a YAML config**
```
Input: "Create a test application.yml"
Tool Call:
{
  "pathInProject": "src/test/resources/application.yml",
  "text": "spring:\n  datasource:\n    url: jdbc:h2:mem:testdb\n    driver-class-name: org.h2.Driver\n  jpa:\n    hibernate:\n      ddl-auto: create-drop\n",
  "projectPath": "/path/to/project"
}
```

---

## replace_text_in_file

### Purpose
Performs targeted find-and-replace in an existing file — the primary tool for editing source files.

### When to Use
- Adding a new import statement to a Java class
- Updating a method body or configuration value
- Adding an annotation to an existing class
- Modifying XML or YAML configuration
- Fixing a specific code issue
- **Always use instead of `sed`, `awk`, or shell-based file editing**
- **Do NOT use for renaming symbols — use `rename_refactoring` instead**

### Parameters

#### pathInProject (required)
- **Type:** String
- **Description:** Project-relative path to the target file
- **Example:** `"src/main/java/com/example/service/UserService.java"`

#### oldText (required)
- **Type:** String
- **Description:** The exact text to find and replace
- **Critical:** Must match the file content exactly (including whitespace and indentation)
- **Tip:** Read the file first with `get_file_text_by_path` to get the exact text

#### newText (required)
- **Type:** String
- **Description:** The replacement text
- **Note:** Can be an empty string to delete the matched text

#### replaceAll (optional)
- **Type:** Boolean
- **Default:** true
- **Description:** Whether to replace all occurrences or just the first
- **Guidance:**
  - `true` (default) — for consistent changes throughout the file
  - `false` — when only the first occurrence should change

#### caseSensitive (optional)
- **Type:** Boolean
- **Default:** true
- **Guidance:** Keep true for code; set false for config value updates where case may vary

#### projectPath (recommended)
- **Type:** String

### Return Value
- `"ok"` — replacement succeeded
- Error: `"no occurrences found"` — oldText not in file (check exact match)
- Error: `"file not found"` — path is wrong
- Error: `"could not get document"` — file access issue

### Usage Examples

**Example 1: Add an import**
```
Read file first, then:
Tool Call:
{
  "pathInProject": "src/main/java/com/example/service/UserService.java",
  "oldText": "import org.springframework.stereotype.Service;",
  "newText": "import org.springframework.stereotype.Service;\nimport org.springframework.transaction.annotation.Transactional;",
  "projectPath": "/path/to/project"
}
```

**Example 2: Add @Transactional to a method**
```
Tool Call:
{
  "pathInProject": "src/main/java/com/example/service/UserService.java",
  "oldText": "    public User findById(Long id) {",
  "newText": "    @Transactional(readOnly = true)\n    public User findById(Long id) {",
  "replaceAll": false,
  "projectPath": "/path/to/project"
}
```

**Example 3: Update configuration value**
```
Tool Call:
{
  "pathInProject": "src/main/resources/application.yml",
  "oldText": "ddl-auto: create-drop",
  "newText": "ddl-auto: validate",
  "projectPath": "/path/to/project"
}
```

**Example 4: Delete a line**
```
Tool Call:
{
  "pathInProject": "src/main/java/com/example/UserService.java",
  "oldText": "    // TODO: remove this line\n",
  "newText": "",
  "projectPath": "/path/to/project"
}
```

### Common Failure: "no occurrences found"
This means `oldText` does not exactly match the file. Fix:
1. Call `get_file_text_by_path` to read the actual file
2. Copy-paste the exact text, preserving spaces and newlines
3. Retry with the exact match

---

## rename_refactoring

### Purpose
Renames a symbol (class, method, field, variable) and updates ALL references throughout the entire project — the only correct way to rename code symbols.

### When to Use
- Renaming a class, interface, or enum
- Renaming a method across all call sites
- Renaming a field and its getters/setters
- Renaming a package and all references
- **ALWAYS use instead of search-and-replace for symbol renaming**
- **IDE-aware: understands code semantics, not just text patterns**

### Parameters

#### pathInProject (required)
- **Type:** String
- **Description:** Project-relative path to the file containing the symbol
- **Example:** `"src/main/java/com/example/domain/User.java"`

#### symbolName (required)
- **Type:** String
- **Description:** Exact current name of the symbol (case-sensitive)
- **Examples:**
  - `"User"` — rename a class
  - `"findById"` — rename a method
  - `"userName"` — rename a field

#### newName (required)
- **Type:** String
- **Description:** The new name for the symbol
- **Examples:**
  - `"Customer"` — rename User to Customer
  - `"findByIdentifier"` — rename method
  - `"fullName"` — rename field

#### projectPath (recommended)
- **Type:** String

### Return Value
- Success message with confirmation of renamed symbol
- Error message if file or symbol not found

### Usage Examples

**Example 1: Rename a class**
```
Input: "Rename the User entity to Customer"
Tool Call:
{
  "pathInProject": "src/main/java/com/example/domain/User.java",
  "symbolName": "User",
  "newName": "Customer",
  "projectPath": "/path/to/project"
}
Result: Updates User.java filename, all @Entity usages, import statements, and all references project-wide
```

**Example 2: Rename a method**
```
Input: "Rename getUserById to findUserById"
Tool Call:
{
  "pathInProject": "src/main/java/com/example/service/UserService.java",
  "symbolName": "getUserById",
  "newName": "findUserById",
  "projectPath": "/path/to/project"
}
Result: Updates all call sites, interface definitions, test references automatically
```

**Example 3: Rename a field**
```
Input: "Rename the 'name' field to 'fullName' in User entity"
Tool Call:
{
  "pathInProject": "src/main/java/com/example/domain/User.java",
  "symbolName": "name",
  "newName": "fullName",
  "projectPath": "/path/to/project"
}
```

### Why NOT replace_text_in_file for renaming
`replace_text_in_file` does dumb text replacement — it misses:
- Usages in other files
- Import statements
- String references in annotations
- Derived method names in repositories
`rename_refactoring` understands the semantic structure and updates everything correctly.

---

## reformat_file

### Purpose
Applies IntelliJ's code formatting rules to a file — enforces consistent code style.

### When to Use
- After creating a new file with `create_new_file`
- After making edits with `replace_text_in_file`
- After creating JPA entities or repositories
- Anytime file formatting may be inconsistent
- **Always call after any file creation or significant modification**

### Parameters

#### path (required)
- **Type:** String
- **Description:** Path relative to project root
- **Example:** `"src/main/java/com/example/domain/User.java"`

#### projectPath (recommended)
- **Type:** String

### Return Value
Confirmation that file was reformatted.

### Usage Examples

**Example 1: Standard post-creation formatting**
```
After create_jpa_entity succeeds:
reformat_file("src/main/java/com/example/domain/User.java", projectPath: "/...")
```

**Example 2: After manual edits**
```
After replace_text_in_file succeeds:
reformat_file("src/main/java/com/example/service/UserService.java", projectPath: "/...")
```

---

## create_jpa_entity

### Purpose
Creates a complete JPA entity class with all annotations, attributes, and relationships — the ONLY correct way to create a new entity.

### When to Use
- Creating new domain entity classes
- Implementing entity hierarchies (inheritance)
- Creating join table entities with composite keys
- Adding a new table-backed domain object
- **NEVER create entity files manually — always use this tool**

### Parameters

#### entityName (required)
- **Type:** String
- **Description:** Entity class name (PascalCase, singular)
- **Examples:** `"User"`, `"Product"`, `"OrderItem"`
- **Convention:** Singular noun, PascalCase, no "Entity" suffix

#### entityPackage (optional)
- **Type:** String
- **Auto-detection:** Detects from existing entities if omitted
- **Examples:** `"com.example.domain"`, `"com.myapp.entities"`

#### language (optional)
- **Type:** Enum: `"Java"` | `"Kotlin"`
- **Default:** Java

#### moduleName (optional)
- **Type:** String
- **Use:** Multi-module projects only

#### tableName (optional)
- **Type:** String
- **Auto-generation:** Snake_case from entity name if omitted
- **Example:** `"order_items"` for `OrderItem`

#### attributes (optional)
- **Type:** Array of attribute objects
- **See:** "Attribute Object Reference" section below

#### inheritanceType (optional)
- **Type:** String: `"SINGLE_TABLE"` | `"JOINED"` | `"TABLE_PER_CLASS"`

#### discriminatorColumn / discriminatorType / discriminatorValue (optional)
- For entity hierarchies — see Inheritance section

#### superclass (optional)
- **Type:** String — parent entity class name

#### mappedSuperclass (optional)
- **Type:** Boolean — mark as @MappedSuperclass instead of @Entity

#### compositeId (optional)
- **Type:** Boolean — enable composite primary key

#### indexes (optional)
- **Type:** Array of index objects
- **Structure:**
  ```json
  { "name": "idx_email", "columnList": ["email"], "unique": true, "constraint": false }
  ```

#### namedQueries (optional)
- **Type:** Array
- **Structure:**
  ```json
  { "name": "User.findActive", "query": "SELECT u FROM User u WHERE u.active = true" }
  ```

#### projectPath (recommended)
- **Type:** String — ALWAYS pass

### Attribute Object Reference

```json
{
  "name": "fieldName",
  "type": "String",
  "isId": false,
  "column": "column_name",
  "columnProperties": {
    "nullable": false,
    "length": 255,
    "unique": false,
    "columnDefinition": null,
    "precision": null,
    "scale": null,
    "insertable": true,
    "updatable": true,
    "lob": false,
    "temporal": null,
    "version": false
  },
  "idGenerationProperties": {
    "generatedStrategy": "IDENTITY",
    "sequenceName": null,
    "initialValue": null,
    "allocationSize": null,
    "generatorName": null
  },
  "relationshipProperties": {
    "relationship": "OneToMany",
    "joinColumn": null,
    "mappedBy": "user",
    "cascade": "ALL",
    "fetch": "LAZY",
    "orphanRemoval": true,
    "joinTable": null,
    "inverseJoinColumn": null
  },
  "collectionProperties": {
    "elementCollection": null,
    "collectionTable": null
  },
  "embeddedProperties": {
    "embedded": null,
    "attributeOverrides": null
  }
}
```

**ID field (IDENTITY):**
```json
{
  "name": "id", "type": "Long", "isId": true,
  "columnProperties": {},
  "idGenerationProperties": { "generatedStrategy": "IDENTITY" },
  "relationshipProperties": {}, "collectionProperties": {}, "embeddedProperties": {}
}
```

**ID field (SEQUENCE):**
```json
{
  "name": "id", "type": "Long", "isId": true,
  "columnProperties": {},
  "idGenerationProperties": { "generatedStrategy": "SEQUENCE", "sequenceName": "user_seq", "allocationSize": 50 },
  "relationshipProperties": {}, "collectionProperties": {}, "embeddedProperties": {}
}
```

**Non-nullable String:**
```json
{
  "name": "email", "type": "String", "isId": false,
  "columnProperties": { "nullable": false, "unique": true, "length": 255 },
  "idGenerationProperties": {}, "relationshipProperties": {}, "collectionProperties": {}, "embeddedProperties": {}
}
```

**Money field (BigDecimal):**
```json
{
  "name": "price", "type": "BigDecimal", "isId": false,
  "columnProperties": { "nullable": false, "precision": 19, "scale": 2 },
  "idGenerationProperties": {}, "relationshipProperties": {}, "collectionProperties": {}, "embeddedProperties": {}
}
```

**Timestamp with immutable insert:**
```json
{
  "name": "createdAt", "type": "LocalDateTime", "isId": false,
  "columnProperties": { "nullable": false, "updatable": false },
  "idGenerationProperties": {}, "relationshipProperties": {}, "collectionProperties": {}, "embeddedProperties": {}
}
```

**@Version field (optimistic locking):**
```json
{
  "name": "version", "type": "Long", "isId": false,
  "columnProperties": { "nullable": false, "version": true },
  "idGenerationProperties": {}, "relationshipProperties": {}, "collectionProperties": {}, "embeddedProperties": {}
}
```

**OneToMany (inverse/parent side):**
```json
{
  "name": "orders", "type": "List<Order>", "isId": false,
  "columnProperties": {},
  "idGenerationProperties": {},
  "relationshipProperties": {
    "relationship": "OneToMany",
    "mappedBy": "user",
    "cascade": "ALL",
    "fetch": "LAZY",
    "orphanRemoval": true
  },
  "collectionProperties": {}, "embeddedProperties": {}
}
```

**ManyToOne (owning/child side):**
```json
{
  "name": "user", "type": "User", "isId": false,
  "columnProperties": {},
  "idGenerationProperties": {},
  "relationshipProperties": {
    "relationship": "ManyToOne",
    "joinColumn": "user_id",
    "fetch": "LAZY"
  },
  "collectionProperties": {}, "embeddedProperties": {}
}
```

**ManyToMany:**
```json
{
  "name": "roles", "type": "Set<Role>", "isId": false,
  "columnProperties": {},
  "idGenerationProperties": {},
  "relationshipProperties": {
    "relationship": "ManyToMany",
    "joinTable": "user_roles",
    "joinColumn": "user_id",
    "inverseJoinColumn": "role_id",
    "fetch": "LAZY"
  },
  "collectionProperties": {}, "embeddedProperties": {}
}
```

### Return Value
```json
{
  "status": "Success",
  "message": "Entity User created successfully",
  "nextSuggestedActions": "Create UserRepository for data access",
  "resultFiles": [
    {
      "name": "User.java",
      "path": "src/main/java/com/example/domain/User.java",
      "content": "package com.example.domain; ...",
      "description": "User JPA entity"
    }
  ]
}
```

### Error Handling
- `"Ask user"` — Tool needs clarification (ambiguous package, module). Provide the requested info and retry.
- `"Failure"` — Check `message` field for details. Common: entity already exists, invalid type, compilation error.

### Usage Examples

**Example 1: Simple entity**
```
Input: "Create a Product entity with name and price"
Prerequisite: find_jpa_entities() confirms Product doesn't exist
Tool Call:
{
  "entityName": "Product",
  "entityPackage": "com.example.domain",
  "tableName": "products",
  "attributes": [
    { "name": "id", "type": "Long", "isId": true, "columnProperties": {},
      "idGenerationProperties": {"generatedStrategy": "IDENTITY"},
      "relationshipProperties": {}, "collectionProperties": {}, "embeddedProperties": {} },
    { "name": "name", "type": "String", "isId": false,
      "columnProperties": {"nullable": false, "length": 200},
      "idGenerationProperties": {}, "relationshipProperties": {}, "collectionProperties": {}, "embeddedProperties": {} },
    { "name": "price", "type": "BigDecimal", "isId": false,
      "columnProperties": {"nullable": false, "precision": 19, "scale": 2},
      "idGenerationProperties": {}, "relationshipProperties": {}, "collectionProperties": {}, "embeddedProperties": {} }
  ],
  "projectPath": "/path/to/project"
}
```

**Example 2: Entity with inheritance**
```
{
  "entityName": "CreditCardPayment",
  "entityPackage": "com.example.domain",
  "superclass": "Payment",
  "discriminatorValue": "CREDIT_CARD",
  "attributes": [...],
  "projectPath": "/path/to/project"
}
```

---

## create_or_update_entity_attribute

### Purpose
Adds a new attribute or modifies an existing one in a JPA entity — the ONLY correct way to evolve entity structure.

### When to Use
- Adding a new field to an existing entity
- Adding a relationship to an existing entity
- Modifying column constraints on an existing field
- Adding @Version for optimistic locking
- Adding audit fields (createdAt, updatedAt)
- **ALWAYS call `get_jpa_entity_by_name` first to understand current structure**

### Parameters

#### entityFqn (required)
- **Type:** String
- **Description:** FULLY QUALIFIED entity name
- **Examples:** `"com.example.domain.User"`, `"com.myapp.entities.Product"`
- **Important:** Must be the full package + class name, NOT just the class name

#### name (required)
- **Type:** String
- **Description:** Attribute/field name in camelCase
- **Examples:** `"phoneNumber"`, `"createdAt"`, `"orders"`

#### type (required)
- **Type:** String
- **Description:** Java/Kotlin type
- **Examples:** `"String"`, `"Long"`, `"LocalDateTime"`, `"List<Order>"`, `"BigDecimal"`

#### isId (optional)
- **Type:** Boolean
- **Default:** false

#### column (optional)
- **Type:** String
- **Description:** Custom column name (snake_case)
- **Example:** `"phone_number"`

#### columnProperties, idGenerationProperties, relationshipProperties, collectionProperties, embeddedProperties
- Same objects as documented in `create_jpa_entity` attribute reference

#### projectPath (recommended)
- **Type:** String

### Usage Examples

**Example 1: Add a simple field**
```
Input: "Add a phone number field to User"
Prerequisite: get_jpa_entity_by_name("User") → get FQN "com.example.domain.User"
Tool Call:
{
  "entityFqn": "com.example.domain.User",
  "name": "phoneNumber",
  "type": "String",
  "column": "phone_number",
  "columnProperties": { "nullable": true, "length": 20 },
  "projectPath": "/path/to/project"
}
```

**Example 2: Add a relationship**
```
Input: "Add a one-to-many orders relationship to User"
Tool Call:
{
  "entityFqn": "com.example.domain.User",
  "name": "orders",
  "type": "List<Order>",
  "relationshipProperties": {
    "relationship": "OneToMany",
    "mappedBy": "user",
    "cascade": "ALL",
    "fetch": "LAZY",
    "orphanRemoval": true
  },
  "projectPath": "/path/to/project"
}
```

**Example 3: Add @Version for optimistic locking**
```
{
  "entityFqn": "com.example.domain.Order",
  "name": "version",
  "type": "Long",
  "columnProperties": { "nullable": false, "version": true },
  "projectPath": "/path/to/project"
}
```

---

## delete_entity_attribute

### Purpose
Removes an attribute from a JPA entity, cleaning up annotations, field declarations, and relationship mappings.

### When to Use
- Removing deprecated or unused fields
- Cleaning up relationships that are no longer needed
- Refactoring entity structure
- Removing temporary fields after data migration
- **ALWAYS check with `get_jpa_entity_by_name` first — confirm attribute exists and check for dependencies**

### Parameters

#### entityFqn (required)
- **Type:** String
- **Description:** Fully qualified entity name
- **Example:** `"com.example.domain.User"`

#### name (required)
- **Type:** String
- **Description:** Exact attribute name to remove
- **Example:** `"legacyField"`, `"oldStatus"`

#### projectPath (recommended)
- **Type:** String

### Return Value
```json
{
  "name": "User.java",
  "path": "src/main/java/com/example/domain/User.java",
  "content": "... updated entity content ...",
  "description": "Removed 'legacyField' attribute from User"
}
```

### Usage Examples

**Example 1: Remove deprecated field**
```
Input: "Remove the 'legacyStatus' field from the Order entity"
Step 1: get_jpa_entity_by_name("Order") → confirm field exists, check for dependencies
Step 2:
{
  "entityFqn": "com.example.domain.Order",
  "name": "legacyStatus",
  "projectPath": "/path/to/project"
}
Step 3: build_project → validate no compilation errors
```

---

## create_spring_data_repository

### Purpose
Generates a Spring Data JPA repository interface — the ONLY correct way to create a repository.

### When to Use
- Creating data access layer for a new entity
- Adding Spring Data CRUD operations to an entity
- Generating repository with custom query methods
- **ALWAYS call `find_spring_data_repositories` first to check for duplicates**

### Parameters

#### repositoryClassName (required)
- **Type:** String
- **Description:** Repository interface name
- **Convention:** `{Entity}Repository`
- **Examples:** `"UserRepository"`, `"ProductRepository"`, `"OrderItemRepository"`

#### entityName (optional but recommended)
- **Type:** String
- **Description:** Target entity name or FQN
- **Examples:** `"User"`, `"com.example.domain.Product"`

#### packageName (optional)
- **Type:** String
- **Auto-detection:** Inferred from entity package or existing repos if omitted
- **Example:** `"com.example.repository"`

#### sourceRootType (optional)
- **Type:** String: `"source"` | `"test"`
- **Default:** `"source"`

#### moduleName (optional)
- **Type:** String
- **Use:** Multi-module projects only

#### baseRepositoryClass (optional)
- **Type:** String
- **Values and when to use:**
  - `"JpaRepository"` — most common, full JPA features + pagination (recommended default)
  - `"CrudRepository"` — basic CRUD, no pagination
  - `"PagingAndSortingRepository"` — adds pagination/sorting without JPA-specific features
  - `"ListCrudRepository"` — like CrudRepository but returns `List` instead of `Iterable`
- **Default:** Follows project convention (usually JpaRepository)

#### projectPath (recommended)
- **Type:** String

### Return Value
```json
{
  "file": {
    "name": "UserRepository.java",
    "path": "src/main/java/com/example/repository/UserRepository.java",
    "content": "package com.example.repository;\n\nimport org.springframework.data.jpa.repository.JpaRepository;\npublic interface UserRepository extends JpaRepository<User, Long> {\n}",
    "entity": "User",
    "description": "Spring Data JPA repository for User entity"
  }
}
```

### Usage Examples

**Example 1: Standard repository**
```
Input: "Create a repository for the Product entity"
Step 1: find_spring_data_repositories(entityName: "Product") → confirm none exists
Step 2:
{
  "repositoryClassName": "ProductRepository",
  "entityName": "Product",
  "baseRepositoryClass": "JpaRepository",
  "projectPath": "/path/to/project"
}
```

**Example 2: Multi-module repository**
```
{
  "repositoryClassName": "OrderRepository",
  "entityName": "com.example.domain.Order",
  "packageName": "com.example.data.repositories",
  "moduleName": "data-module",
  "baseRepositoryClass": "JpaRepository",
  "projectPath": "/path/to/project"
}
```

---

## build_project

### Purpose
Triggers IntelliJ's build system and returns structured compilation errors — **MANDATORY after every code change**.

### When to Use
- **After EVERY code change** (entity creation, attribute modification, file edits)
- After modifying build scripts (`pom.xml`, `build.gradle`)
- Before running tests — ensure clean compilation first
- When something behaves unexpectedly — try with `rebuild: true`
- As the final step in any implementation workflow

### Parameters

#### rebuild (optional)
- **Type:** Boolean
- **Default:** false
- **Description:** Full clean rebuild vs incremental build
- **When to set `true`:**
  - After structural changes (new modules, dependency changes)
  - When incremental build shows unexpected errors
  - When stale artifact issues are suspected

#### timeout (optional)
- **Type:** Integer (milliseconds)
- **Default:** Tool decides
- **Guidance:** Large projects may need 120000–300000ms

#### projectPath (recommended)
- **Type:** String

### Return Value

**Success (no errors):**
```json
{
  "errors": [],
  "timedOut": false
}
```

**With errors:**
```json
{
  "errors": [
    {
      "severity": "ERROR",
      "description": "cannot find symbol: class Order",
      "filePath": "src/main/java/com/example/domain/User.java",
      "line": 15,
      "column": 12,
      "lineContent": "    private List<Order> orders;"
    }
  ],
  "timedOut": false
}
```

### Interpreting Errors

| Error Message | Likely Cause | Fix |
|---|---|---|
| `cannot find symbol` | Missing import, wrong class name | Add import or fix class name |
| `incompatible types` | Type mismatch in assignment/return | Fix the type |
| `package does not exist` | Missing dependency or wrong import | Add dependency or fix import |
| `method not found` | Wrong method name or signature | Check the API |
| `duplicate class` | Two classes with same name in same package | Rename or delete duplicate |

### Usage Examples

**Example 1: Standard post-change build**
```
After any create_jpa_entity or create_or_update_entity_attribute:
{ "projectPath": "/path/to/project" }
→ Check errors array; if empty, proceed
→ If errors: fix with replace_text_in_file or correct the entity call, then rebuild
```

**Example 2: Full rebuild after dependency change**
```
After modifying pom.xml:
{ "rebuild": true, "projectPath": "/path/to/project" }
```

---

## execute_terminal_command

### Purpose
Executes shell commands in the IDE's integrated terminal — a fallback for operations not covered by dedicated tools.

### When to Use
- Running Maven commands not covered by run configurations (`mvn dependency:resolve`, `mvn flyway:migrate`)
- Running Gradle tasks (`./gradlew dependencies`, `./gradlew generateJooq`)
- Running code generation tools (OpenAPI generator, QueryDSL)
- Running specific database migration commands
- **Prefer `execute_run_configuration` (intellij-testing skill) for defined test/app configs**
- **Prefer dedicated implementation tools for file/entity operations**

### Parameters

#### command (required)
- **Type:** String
- **Description:** Shell command to execute
- **Examples:**
  - `"mvn dependency:resolve"`
  - `"./gradlew dependencies --configuration runtimeClasspath"`
  - `"mvn flyway:migrate -Dflyway.url=jdbc:postgresql://localhost/mydb"`

#### executeInShell (optional)
- **Type:** Boolean
- **Default:** false
- **Description:** Run in user's shell (bash/zsh) to inherit full environment
- **When to use:** Commands using shell features (pipes, env vars, aliases)

#### reuseExistingTerminalWindow (optional)
- **Type:** Boolean
- **Default:** false
- **When to use:** Avoid creating multiple terminal tabs

#### timeout (optional)
- **Type:** Integer (milliseconds)
- **Default:** 30000ms
- **Guidance:** Long builds may need 300000ms

#### maxLinesCount (optional)
- **Type:** Integer
- **Default:** 2000 lines

#### truncateMode (optional)
- **Type:** Enum: `"START"` | `"MIDDLE"` | `"END"` | `"NONE"`
- **Guidance:**
  - `"START"` — see the end of output (build result/summary at the end)
  - `"END"` — see the beginning

#### projectPath (recommended)
- **Type:** String

### Return Value
```json
{
  "command_output": "...",
  "command_exit_code": 0,
  "is_timed_out": false
}
```
- `command_exit_code: 0` — success
- `command_exit_code: 1` (non-zero) — failure; check `command_output` for details

### Usage Examples

**Example 1: Update Maven dependencies**
```
{ "command": "mvn dependency:resolve", "projectPath": "/path/to/project" }
```

**Example 2: Run specific Maven plugin**
```
{ "command": "mvn liquibase:update", "executeInShell": true, "timeout": 60000, "projectPath": "/..." }
```

**Example 3: Check Gradle dependencies**
```
{ "command": "./gradlew dependencies --configuration runtimeClasspath", "timeout": 120000, "truncateMode": "START", "maxLinesCount": 100 }
```

---

## Implementation Workflow

### Standard Entity Implementation
```
1. find_jpa_entities()                          → check existing entities
2. find_spring_data_repositories()              → check existing repos
3. create_jpa_entity(...)                       → create the entity
4. reformat_file(entityPath)                    → apply formatting
5. build_project()                              → validate compilation
6. create_spring_data_repository(...)           → create repository
7. build_project()                              → validate again
8. get_jpa_entity_by_name(name)                 → verify structure
```

### Standard Attribute Addition
```
1. get_jpa_entity_by_name("EntityName")         → understand current state
2. create_or_update_entity_attribute(FQN, ...)  → add the attribute
3. build_project()                              → validate compilation
4. get_jpa_entity_by_name("EntityName")         → verify attribute added
```

### Standard File Edit
```
1. get_file_text_by_path("path/to/file.java")   → read current content
2. replace_text_in_file("path", old, new)       → make targeted edit
3. reformat_file("path/to/file.java")           → apply formatting
4. build_project()                              → validate compilation
```

---

## Best Practices

1. **Always pass `projectPath`** — critical for accuracy in all tools
2. **Explore before implementing** — call intellij-exploration tools first
3. **Use FQN for `entityFqn`** — `com.example.domain.User` not just `User`
4. **Always `build_project` after changes** — catch compilation errors immediately
5. **Use `rename_refactoring` not `replace_text_in_file` for renaming** — safe, semantic rename
6. **Reformat after every file creation/edit** — maintain consistent code style
7. **Check `status` field in JPA tool responses** — handle `"Ask user"` and `"Failure"` appropriately
