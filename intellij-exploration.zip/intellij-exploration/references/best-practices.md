# IntelliJ Exploration — Best Practices

---

## Core Rules

| Rule | Why |
|---|---|
| Use `find_files_by_name_keyword` over `find_files_by_glob` when you know the filename | Name keyword uses IDE index — significantly faster |
| Use `find_jpa_entities` over `search_in_files_by_text("@Entity")` | Returns parsed structured data, not raw file lines |
| Use `get_jpa_entity_by_name` over reading entity files directly | Returns relationship metadata that is hard to parse from raw text |
| Always check `get_all_open_file_paths` when user says "this file" or "the file I have open" | User's current context is in the IDE, not implied |
| Prefer `search_in_files_by_text` over `search_in_files_by_regex` for literal searches | Text search is faster; regex has overhead |
| Always pass `projectPath` in every tool call | Removes ambiguity in multi-project environments |

---

## Tool Selection Guide

```
Looking for files?
  ├── Know part of filename      → find_files_by_name_keyword   (fastest)
  ├── Need a glob pattern        → find_files_by_glob
  └── Know content to match      → search_in_files_by_text

Reading content?
  └── Always                     → get_file_text_by_path
                                   (never cat/head/tail)

Understanding a symbol?
  └── get_symbol_info at the position (read file first to find line/column)

Understanding JPA?
  ├── All entities               → find_jpa_entities
  ├── Specific entity            → get_jpa_entity_by_name
  ├── Repositories               → find_spring_data_repositories
  └── From DB table              → reverse_engineering_jpa_entity_by_name

Project metadata?
  ├── Modules                    → get_project_modules
  ├── Dependencies               → get_project_dependencies
  ├── VCS roots                  → get_repositories
  └── Run configs                → get_run_configurations
```

---

## Anti-Patterns

### ❌ Reading entity file to understand structure
```
# WRONG
get_file_text_by_path("src/main/java/com/example/domain/User.java")
# You have to parse @OneToMany, @ManyToOne manually, risk misreading cascade/fetch

# CORRECT
get_jpa_entity_by_name(entityName: "User")
# Returns structured data: all attributes, types, fetch strategies, cascade, mappedBy
```

### ❌ Searching for @Entity with text search
```
# WRONG
search_in_files_by_text(searchText: "@Entity")
# Returns raw lines, no entity structure, no relationship data

# CORRECT
find_jpa_entities()
# Returns parsed entity objects ready to use
```

### ❌ Guessing file locations
```
# WRONG
# Assuming UserService is at src/main/java/com/example/service/UserService.java

# CORRECT
find_files_by_name_keyword(nameKeyword: "UserService")
# Returns the actual path — no assumptions needed
```

### ❌ Not checking open files when user says "this file"
```
# WRONG
# Assume what file the user means based on context

# CORRECT
get_all_open_file_paths()
# activeFilePath tells you exactly what they're looking at
```

---

## Exploration Sequence for Unknown Projects

When starting work on an unfamiliar project:

```
1. list_directory_tree("", maxDepth: 3)
   → understand source layout, package structure

2. get_project_modules()
   → is it multi-module? what are the module names?

3. get_project_dependencies()
   → what Spring Boot version? JPA present? what test framework?

4. find_jpa_entities()
   → what's the domain model? what packages are used?

5. find_spring_data_repositories()
   → what data access layer exists?

6. get_run_configurations()
   → what test suites and app configs are available?
```

This sequence gives a complete picture in 6 tool calls.

---

## Key Fields to Check in Tool Output

### From `get_jpa_entity_by_name`

| Field | What it tells you |
|---|---|
| `packageName` | Use this as `entityPackage` for new related entities |
| `attributes[].relationshipProperties.fetch` | `LAZY` = potential `LazyInitializationException` |
| `attributes[].relationshipProperties.mappedBy` | Present = **inverse** side (no FK in DB) |
| `attributes[].idGenerationProperties.generatedStrategy` | Match convention in new entities |
| `inheritanceType` | Affects table design and how to add entities in a hierarchy |

### From `get_project_dependencies`

| What to look for | Why |
|---|---|
| `spring-boot-starter-data-jpa` | Confirms JPA is available |
| `spring-boot-starter-test` | Confirms Mockito, JUnit available |
| Spring Boot version | Affects `javax` vs `jakarta` imports in JPA |
| DB driver (`h2`, `postgresql`, etc.) | Affects available SQL features |
