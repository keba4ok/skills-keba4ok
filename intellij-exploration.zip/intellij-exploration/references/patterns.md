# IntelliJ Exploration — Patterns

Common exploration workflows for quick reference.

---

## Pre-Implementation Exploration

### Before any implementation task
```
list_directory_tree("", maxDepth: 3)
  → understand project layout

find_jpa_entities()
  → check domain model, package conventions

find_spring_data_repositories()
  → check existing data access layer

get_project_modules()
  → confirm module names for multi-module projects

get_project_dependencies()
  → confirm Spring Boot version, JPA present, test libraries
```

### Before creating a new entity
```
find_jpa_entities()                          → check for duplicates + get package
find_spring_data_repositories()              → see if repo already exists
```

### Before modifying an entity
```
get_jpa_entity_by_name("EntityName")         → get FQN + current attributes
→ note FQN (e.g., com.example.domain.User)   → use as entityFqn in modification tools
```

---

## File Finding Patterns

### Know part of the filename → fastest search
```
find_files_by_name_keyword(nameKeyword: "UserService")
```

### Need a file type pattern
```
find_files_by_glob(globPattern: "src/main/java/**/*Service.java")
find_files_by_glob(globPattern: "src/test/**/*Test.java")
find_files_by_glob(globPattern: "src/main/resources/**/*.yml")
```

### Find by content
```
search_in_files_by_text(searchText: "@Transactional", fileMask: "*.java")
search_in_files_by_text(searchText: "spring.datasource", fileMask: "*.yml")
```

### Find by code pattern
```
search_in_files_by_regex(regexPattern: "fetch.*LAZY", fileMask: "*.java")
search_in_files_by_regex(regexPattern: "public.*find.*By.*\\(", fileMask: "*.java")
```

---

## Code Understanding Patterns

### Read a file
```
get_file_text_by_path(pathInProject: "src/main/java/com/example/service/UserService.java")
```

### Understand a symbol at a position
```
get_file_text_by_path(...)                   → get line numbers
get_symbol_info(filePath: "...", line: 24, column: 15)   → get declaration + docs
```

### Understand user's current work context
```
get_all_open_file_paths()
  → activeFilePath = "..."
get_file_text_by_path(activeFilePath)
```

---

## JPA Domain Exploration Patterns

### Full domain model overview
```
find_jpa_entities()
  + find_spring_data_repositories()
  → cross-reference: which entities have repos?
```

### Deep entity analysis
```
find_jpa_entities()                          → find entity name
get_jpa_entity_by_name("EntityName")         → get full structure
  → check fetch types (LAZY/EAGER)
  → check mappedBy (inverse side has it, owning side doesn't)
  → check cascade types
  → check inheritance strategy
```

### Repository audit
```
find_spring_data_repositories()              → list all repositories
  → for each entity with no repo: suggest create_spring_data_repository
```

### Database-first exploration
```
reverse_engineering_jpa_entity_by_name("table_name")
  → get column list → use to inform create_jpa_entity call
```

---

## Debugging Patterns

### Debug LazyInitializationException
```
get_jpa_entity_by_name("AffectedEntity")
  → check fetch type on the LAZY field
search_in_files_by_text("entity.getLazyField()")
  → find caller location
get_file_text_by_path("...CallerService.java")
  → check if @Transactional is on the calling method
```

### Debug missing dependency or class
```
find_files_by_name_keyword("ClassName")
  → is it there?
get_project_dependencies()
  → is the library included?
```

### Understand build configuration
```
get_file_text_by_path("pom.xml")             → Maven projects
get_file_text_by_path("build.gradle")        → Gradle projects
get_project_dependencies()                   → parsed library list
```
