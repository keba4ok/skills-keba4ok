# Tool Reference - IntelliJ Exploration

Comprehensive documentation for all 17 exploration tools combining IntelliJ IDEA navigation and JPA/Spring Data discovery.

---

## list_directory_tree

### Purpose
Provides a tree-format representation of a project directory — the primary way to navigate project structure.

### When to Use
- Getting an overview of project layout before any task
- Understanding module structure and source directories
- Locating configuration files, resource directories, or test directories
- Understanding package structure before creating new files
- **Always use instead of `ls`, `dir`, or `find` commands**

### Parameters

#### directoryPath (required)
- **Type:** String
- **Description:** Path relative to project root to list
- **Examples:**
  - `""` or `"."` — project root
  - `"src/main/java"` — main source directory
  - `"src/main/java/com/example"` — specific package
  - `"src/test"` — test directory
- **Tip:** Start with `"src"` for a focused overview, or `""` for the full project tree

#### maxDepth (optional)
- **Type:** Integer
- **Description:** Maximum recursion depth
- **Examples:** `2` for a shallow overview, `5` for deep exploration
- **Default:** Tool decides — omit for reasonable default

#### timeout (optional)
- **Type:** Integer (milliseconds)
- **Description:** Override default timeout for large directories

#### projectPath (recommended)
- **Type:** String
- **Description:** Project root absolute path
- **Important:** ALWAYS pass if known

### Return Value
```json
{
  "traversedDirectory": "src/main/java",
  "tree": "src/main/java\n└── com\n    └── example\n        ├── domain\n        │   ├── User.java\n        │   └── Order.java\n        └── repository\n            └── UserRepository.java",
  "errors": [],
  "listingTimedOut": false
}
```

### Usage Examples

**Example 1: Full project overview**
```
Input: "Show me the project structure"
Tool Call: { "directoryPath": "", "maxDepth": 3, "projectPath": "/path/to/project" }
```

**Example 2: Explore source packages**
```
Input: "What packages exist under com.example?"
Tool Call: { "directoryPath": "src/main/java/com/example", "projectPath": "/path/to/project" }
```

**Example 3: Check test directory layout**
```
Input: "Where are the tests?"
Tool Call: { "directoryPath": "src/test", "projectPath": "/path/to/project" }
```

---

## find_files_by_name_keyword

### Purpose
Finds files by name keyword using IntelliJ's fast index — the preferred tool when you know part of a filename.

### When to Use
- Finding a class or file by partial name
- Locating configuration files by name
- Checking if a file exists before creating it
- **Prefer over `find_files_by_glob` for name-based searches — much faster (index-based)**
- **Does NOT support glob patterns — use `find_files_by_glob` for those**

### Parameters

#### nameKeyword (required)
- **Type:** String
- **Description:** Substring to find in file names (case-insensitive)
- **Examples:**
  - `"UserService"` — finds UserService.java, UserServiceImpl.java
  - `"application"` — finds application.yml, application.properties
  - `"Controller"` — finds all controller files
  - `"Test"` — finds all test files

#### fileCountLimit (optional)
- **Type:** Integer
- **Description:** Maximum number of files to return
- **Default:** No limit (returns all matches)
- **Tip:** Use `10` or `20` when you only need first results

#### timeout (optional)
- **Type:** Integer (milliseconds)

#### projectPath (recommended)
- **Type:** String

### Return Value
```json
{
  "probablyHasMoreMatchingFiles": false,
  "timedOut": null,
  "files": [
    "src/main/java/com/example/service/UserService.java",
    "src/test/java/com/example/service/UserServiceTest.java"
  ]
}
```

### Usage Examples

**Example 1: Find a service class**
```
Input: "Where is the UserService?"
Tool Call: { "nameKeyword": "UserService", "projectPath": "/path/to/project" }
```

**Example 2: Find all controllers**
```
Input: "List all controller files"
Tool Call: { "nameKeyword": "Controller", "fileCountLimit": 20, "projectPath": "/path/to/project" }
```

**Example 3: Check if a file exists**
```
Input: "Does OrderRepository exist?"
Tool Call: { "nameKeyword": "OrderRepository", "projectPath": "/path/to/project" }
```

---

## find_files_by_glob

### Purpose
Searches for files recursively using glob patterns — use when you need pattern-based file matching.

### When to Use
- Finding all files of a specific type (`**/*.java`)
- Finding files in a specific directory pattern
- Finding files matching a naming convention (`**/*Service.java`)
- **Use when you need glob patterns; use `find_files_by_name_keyword` for simple name searches**

### Parameters

#### globPattern (required)
- **Type:** String
- **Description:** Glob pattern relative to project root
- **Examples:**
  - `"src/**/*.java"` — all Java files in src
  - `"**/*Service.java"` — all service files
  - `"src/main/resources/**/*.yml"` — all YAML configs
  - `"src/test/**/*Test.java"` — all test files
  - `"**/pom.xml"` — find Maven build files

#### subDirectoryRelativePath (optional)
- **Type:** String
- **Description:** Restrict search to this subdirectory
- **Example:** `"src/main/java"` — only search in main sources

#### addExcluded (optional)
- **Type:** Boolean
- **Default:** false
- **Description:** Include files excluded from project index

#### fileCountLimit (optional)
- **Type:** Integer
- **Description:** Maximum files to return

#### timeout (optional)
- **Type:** Integer (milliseconds)

#### projectPath (recommended)
- **Type:** String

### Return Value
```json
{
  "probablyHasMoreMatchingFiles": false,
  "timedOut": null,
  "files": [
    "src/main/java/com/example/UserService.java",
    "src/main/java/com/example/OrderService.java"
  ]
}
```

### Usage Examples

**Example 1: Find all Java files**
```
Input: "Show me all Java source files"
Tool Call: { "globPattern": "src/main/java/**/*.java", "projectPath": "/path/to/project" }
```

**Example 2: Find all test files**
```
Input: "List all test classes"
Tool Call: { "globPattern": "src/test/**/*Test.java", "projectPath": "/path/to/project" }
```

**Example 3: Find Liquibase migration scripts**
```
Input: "What migration scripts exist?"
Tool Call: { "globPattern": "src/main/resources/db/migration/**/*.sql", "projectPath": "/path/to/project" }
```

---

## get_all_open_file_paths

### Purpose
Returns the currently active and open files in the IDE editor.

### When to Use
- Understanding what the user is currently working on
- Getting context about the user's current focus before making suggestions
- Finding the path to a file the user mentions "the file I have open"

### Parameters

#### projectPath (recommended)
- **Type:** String

### Return Value
```json
{
  "activeFilePath": "src/main/java/com/example/domain/User.java",
  "openFiles": [
    "src/main/java/com/example/domain/User.java",
    "src/main/java/com/example/service/UserService.java",
    "src/test/java/com/example/service/UserServiceTest.java"
  ]
}
```

### Usage Examples

**Example 1: Understand user context**
```
Input: "What are you looking at?" / "Fix the file I have open"
Tool Call: { "projectPath": "/path/to/project" }
Result: Use activeFilePath as the target file
```

---

## get_project_modules

### Purpose
Returns all modules in the project with their types — essential for multi-module Spring Boot projects.

### When to Use
- Identifying module structure before targeted operations
- Checking module names to pass to other tools (moduleName parameter)
- Understanding multi-module Maven/Gradle layout
- Finding where to create new files in a multi-module project

### Parameters

#### projectPath (recommended)
- **Type:** String

### Return Value
```json
{
  "modules": [
    { "name": "my-app", "type": "JAVA_MODULE" },
    { "name": "my-app-domain", "type": "JAVA_MODULE" },
    { "name": "my-app-web", "type": "JAVA_MODULE" },
    { "name": "my-app-data", "type": "JAVA_MODULE" }
  ]
}
```

### Usage Examples

**Example 1: Identify modules before targeted operations**
```
Input: "What modules does this project have?"
Tool Call: { "projectPath": "/path/to/project" }
Result: Use module names when calling find_jpa_entities(moduleName: "my-app-domain")
```

---

## get_project_dependencies

### Purpose
Returns all library dependencies defined in the project.

### When to Use
- Checking if Spring Data JPA is available before JPA operations
- Verifying library versions (Spring Boot, Hibernate, etc.)
- Checking available test frameworks (JUnit, Mockito)
- Understanding what's available before suggesting implementation patterns

### Parameters

#### projectPath (recommended)
- **Type:** String

### Return Value
```json
{
  "dependencies": [
    { "name": "spring-boot-starter-data-jpa:3.2.0" },
    { "name": "spring-boot-starter-web:3.2.0" },
    { "name": "postgresql:42.6.0" },
    { "name": "junit-jupiter:5.10.0" }
  ]
}
```

### Usage Examples

**Example 1: Verify JPA is available**
```
Input: "Can I add JPA entities to this project?"
Tool Call: { "projectPath": "/path/to/project" }
Look for: spring-boot-starter-data-jpa or hibernate-core in results
```

**Example 2: Check database driver**
```
Input: "What database is this project using?"
Tool Call: { "projectPath": "/path/to/project" }
Look for: postgresql, mysql, h2 in results
```

---

## get_repositories

### Purpose
Returns all VCS root paths and their VCS type (e.g., Git).

### When to Use
- Multi-repository projects — find all git roots
- Verifying which directories are under version control
- Understanding monorepo vs multi-repo structure

### Parameters

#### projectPath (recommended)
- **Type:** String

### Return Value
```json
{
  "roots": [
    { "pathRelativeToProject": "", "vcsName": "Git" },
    { "pathRelativeToProject": "submodule-dir", "vcsName": "Git" }
  ]
}
```

---

## get_run_configurations

### Purpose
Returns all available run configurations including command, working directory, and environment variables.

### When to Use
- **Always call BEFORE `execute_run_configuration`** to find exact config names
- Discovering available test suites and application launchers
- Understanding how the project is built and run
- Finding the exact name needed for `execute_run_configuration`

### Parameters

#### projectPath (recommended)
- **Type:** String

### Return Value
```json
{
  "configurations": [
    {
      "name": "MyApp",
      "description": "Run the Spring Boot application",
      "commandLine": "mvn spring-boot:run",
      "workingDirectory": "/path/to/project",
      "environment": { "SPRING_PROFILES_ACTIVE": "dev" }
    },
    {
      "name": "All Tests",
      "description": "Run all unit tests",
      "commandLine": null,
      "workingDirectory": null,
      "environment": null
    }
  ]
}
```

### Usage Examples

**Example 1: Discover available test configurations**
```
Input: "What tests can I run?"
Tool Call: { "projectPath": "/path/to/project" }
Result: Use configuration names for execute_run_configuration
```

---

## get_file_text_by_path

### Purpose
Reads the content of a file by its project-relative path — the primary way to read file contents.

### When to Use
- Reading a Java class before modifying it
- Reading configuration files (application.yml, pom.xml)
- Understanding existing code before making changes
- **Always use instead of `cat`, `head`, `tail`, or shell-based reading**

### Parameters

#### pathInProject (required)
- **Type:** String
- **Description:** Path relative to project root
- **Examples:**
  - `"src/main/java/com/example/domain/User.java"`
  - `"src/main/resources/application.yml"`
  - `"pom.xml"` or `"build.gradle"`

#### truncateMode (optional)
- **Type:** Enum: `"START"`, `"MIDDLE"`, `"END"`, `"NONE"`
- **Description:** How to truncate if file is too large
- **Guidance:**
  - `"START"` — see the end of the file (useful for appended logs)
  - `"END"` — see the beginning (useful for class header/imports)
  - `"MIDDLE"` — see both ends
  - `"NONE"` — no truncation (may be very large)

#### maxLinesCount (optional)
- **Type:** Integer
- **Description:** Maximum number of lines to return
- **Tip:** Use `100` for a quick preview, omit for full content

#### projectPath (recommended)
- **Type:** String

### Return Value
Returns the raw file content as a string. For binary files, returns an error.

### Usage Examples

**Example 1: Read a Java class**
```
Input: "Show me the User entity"
Step 1: find_files_by_name_keyword("User") → get path
Step 2: get_file_text_by_path("src/main/java/com/example/domain/User.java")
```

**Example 2: Read application config**
```
Input: "What's the database configuration?"
Tool Call: { "pathInProject": "src/main/resources/application.yml" }
```

**Example 3: Read large file with truncation**
```
Input: "Show me the top of the build file"
Tool Call: { "pathInProject": "pom.xml", "maxLinesCount": 50, "truncateMode": "END" }
```

---

## search_in_files_by_text

### Purpose
Fast text substring search across all project files using IntelliJ's index engine — primary search tool for content.

### When to Use
- Finding where a class or method is used
- Searching for specific annotations (`@Transactional`, `@Entity`)
- Finding configuration keys or values
- Locating TODO comments or specific patterns
- **Always use instead of `grep` or `rg` commands**

### Parameters

#### searchText (required)
- **Type:** String
- **Description:** Exact text substring to find (not a regex)
- **Examples:**
  - `"@Transactional"` — find transactional methods
  - `"userRepository.findBy"` — find repository usages
  - `"spring.datasource"` — find database config

#### directoryToSearch (optional)
- **Type:** String
- **Description:** Restrict search to this directory (relative to project root)
- **Example:** `"src/main/java"` — only search source files

#### fileMask (optional)
- **Type:** String
- **Description:** Filter by file extension or name pattern
- **Examples:** `"*.java"`, `"*.yml"`, `"*.xml"`

#### caseSensitive (optional)
- **Type:** Boolean
- **Default:** false
- **Example:** `true` when searching for exact symbol names

#### maxUsageCount (optional)
- **Type:** Integer
- **Description:** Maximum results to return
- **Tip:** Use `50` to limit large result sets

#### timeout (optional)
- **Type:** Integer (milliseconds)

#### projectPath (recommended)
- **Type:** String

### Return Value
```json
{
  "entries": [
    {
      "filePath": "src/main/java/com/example/service/UserService.java",
      "lineNumber": 42,
      "lineText": "    ||@Transactional|| public User findById(Long id) {"
    }
  ],
  "probablyHasMoreMatchingEntries": false,
  "timedOut": null
}
```
Note: `||text||` marks the matched portion.

### Usage Examples

**Example 1: Find all @Entity classes**
```
Input: "Show me where @Entity is used"
Tool Call: { "searchText": "@Entity", "fileMask": "*.java", "projectPath": "/path/to/project" }
```

**Example 2: Find usages of a repository method**
```
Input: "Where is userRepository used?"
Tool Call: { "searchText": "userRepository", "directoryToSearch": "src/main/java", "projectPath": "/..." }
```

**Example 3: Find configuration properties**
```
Input: "What are the datasource settings?"
Tool Call: { "searchText": "datasource", "fileMask": "*.yml", "projectPath": "/path/to/project" }
```

---

## search_in_files_by_regex

### Purpose
Regex pattern search across all project files — use when substring search is not precise enough.

### When to Use
- Finding patterns like method signatures (`public.*findBy.*\(`)
- Searching for annotations with arguments (`@Column\(.*nullable = false`)
- Finding import statements for a specific package
- Complex patterns that require regex
- **Use instead of `grep -E` or `rg` commands**

### Parameters

#### regexPattern (required)
- **Type:** String
- **Description:** Regular expression pattern
- **Examples:**
  - `"@OneToMany.*cascade"` — relationships with cascade
  - `"public.*Repository.*findBy"` — repository finder methods
  - `"@Version\s"` — optimistic locking fields
  - `"import com\.example\."` — project imports

#### directoryToSearch (optional)
- **Type:** String
- **Description:** Restrict search to subdirectory

#### fileMask (optional)
- **Type:** String
- **Examples:** `"*.java"`, `"*.xml"`

#### caseSensitive (optional)
- **Type:** Boolean
- **Default:** false

#### maxUsageCount (optional)
- **Type:** Integer

#### timeout (optional)
- **Type:** Integer (milliseconds)

#### projectPath (recommended)
- **Type:** String

### Return Value
Same structure as `search_in_files_by_text`.

### Usage Examples

**Example 1: Find all LAZY relationships**
```
Input: "Show me all LAZY fetch relationships"
Tool Call: { "regexPattern": "fetch.*LAZY|LAZY.*fetch", "fileMask": "*.java", "projectPath": "/..." }
```

**Example 2: Find all @Id fields**
```
Input: "What are the primary key strategies?"
Tool Call: { "regexPattern": "@Id\\s*\\n.*@GeneratedValue", "fileMask": "*.java", "projectPath": "/..." }
```

---

## get_symbol_info

### Purpose
Retrieves declaration, type, and documentation for any symbol (class, method, field, variable) at a specific file position — equivalent to IntelliJ's Quick Documentation.

### When to Use
- Understanding what a class, method, or field does
- Navigating to a symbol's declaration
- Understanding a symbol's type signature
- Checking method parameters and return types
- Understanding inherited or overridden members

### Parameters

#### filePath (required)
- **Type:** String
- **Description:** Path relative to project root containing the symbol
- **Example:** `"src/main/java/com/example/service/UserService.java"`

#### line (required)
- **Type:** Integer
- **Description:** 1-based line number of the symbol
- **Note:** Use line numbers from `get_file_text_by_path` output

#### column (required)
- **Type:** Integer
- **Description:** 1-based column number of the symbol
- **Note:** Position the cursor on the symbol name

#### projectPath (recommended)
- **Type:** String

### Return Value
```json
{
  "symbolInfo": {
    "name": "findByEmail",
    "declarationText": "Optional<User> findByEmail(String email)",
    "declarationFile": "src/main/java/com/example/repository/UserRepository.java",
    "declarationLine": 15,
    "language": "JAVA"
  },
  "documentation": "Spring Data derived query method. Generates SELECT * FROM users WHERE email = ?"
}
```

### Usage Examples

**Example 1: Understand a method**
```
Workflow:
1. get_file_text_by_path("src/main/.../UserService.java") → find line with method call
2. get_symbol_info(filePath: "src/main/.../UserService.java", line: 42, column: 10)
Result: Full method signature and documentation
```

---

## open_file_in_editor

### Purpose
Opens a file in the JetBrains IDE editor tab — makes it visible to the user in IntelliJ.

### When to Use
- Showing the user a relevant file after locating it
- Directing the user's attention to a specific file
- Opening a newly created file for review

### Parameters

#### filePath (required)
- **Type:** String
- **Description:** Path relative to project root (or absolute)
- **Example:** `"src/main/java/com/example/domain/User.java"`

#### projectPath (recommended)
- **Type:** String

### Usage Examples

**Example 1: Show entity after creation**
```
After create_jpa_entity succeeds:
open_file_in_editor("src/main/java/com/example/domain/User.java")
```

---

## find_jpa_entities

### Purpose
Discovers all JPA `@Entity` classes in the project — essential for understanding the domain model.

### When to Use
- Getting an overview of all domain entities
- Checking if an entity already exists before creating a new one
- Understanding entity organization and packages
- Exploring entity hierarchies
- Auditing domain model coverage
- **ALWAYS call before creating a new entity**

### Parameters

#### entityPackage (optional)
- **Type:** String
- **Description:** Filter entities by package name
- **Examples:** `"com.example.domain"`, `"com.myapp.entities"`
- **When to omit:** To discover ALL entities project-wide

#### moduleName (optional)
- **Type:** String
- **Description:** Scope to specific module in multi-module projects
- **Examples:** `"domain-module"`, `"core-service"`

#### projectPath (recommended)
- **Type:** String
- **Important:** ALWAYS pass if known

### Return Value
```json
{
  "entities": [
    {
      "name": "User",
      "tableName": "users",
      "packageName": "com.example.domain",
      "attributes": [...],
      "mappedSuperclass": false,
      "compositeId": false,
      "inheritanceType": null,
      "superclass": null,
      "indexes": [...],
      "namedQueries": [...]
    }
  ]
}
```

### Usage Examples

**Example 1: Full domain model overview**
```
Tool Call: { "projectPath": "/path/to/project" }
```

**Example 2: Package-scoped discovery**
```
Tool Call: { "entityPackage": "com.example.domain", "projectPath": "/path/to/project" }
```

**Example 3: Multi-module scoped**
```
Tool Call: { "moduleName": "core-module", "projectPath": "/path/to/project" }
```

### Common Tool Combinations
```
1. find_jpa_entities() → overview
2. get_jpa_entity_by_name("User") → drill into key entity
3. find_spring_data_repositories(entityName: "User") → check repository coverage
```

---

## get_jpa_entity_by_name

### Purpose
Retrieves full details of a specific JPA entity — all attributes, relationships, inheritance, and database mappings.

### When to Use
- Analyzing entity structure before making changes
- Checking relationship fetch types and cascade configuration
- Diagnosing LazyInitializationException (check fetch type, owning side)
- Understanding inheritance strategy
- Preparing for entity updates or migrations
- **ALWAYS call before `create_or_update_entity_attribute`**

### Parameters

#### entityName (required)
- **Type:** String
- **Description:** Simple name or fully qualified name
- **Examples:**
  - `"User"` — simple name (works if unique)
  - `"com.example.domain.Order"` — FQN (use when duplicate names exist)

#### projectPath (recommended)
- **Type:** String

### Return Value
```json
{
  "entities": [
    {
      "name": "User",
      "tableName": "users",
      "packageName": "com.example.domain",
      "attributes": [
        {
          "name": "id",
          "type": "Long",
          "isId": true,
          "column": "id",
          "columnProperties": { "nullable": false },
          "idGenerationProperties": { "generatedStrategy": "IDENTITY" },
          "relationshipProperties": {},
          "collectionProperties": {},
          "embeddedProperties": {}
        },
        {
          "name": "orders",
          "type": "List<Order>",
          "isId": false,
          "relationshipProperties": {
            "relationship": "OneToMany",
            "mappedBy": "user",
            "cascade": "ALL",
            "fetch": "LAZY",
            "orphanRemoval": true
          }
        }
      ],
      "mappedSuperclass": false,
      "compositeId": false,
      "inheritanceType": null,
      "superclass": null
    }
  ]
}
```

### Usage Examples

**Example 1: Analyze before modifying**
```
Input: "Add a phone number to User"
Step 1: get_jpa_entity_by_name("User") → see existing structure, conventions, package
Step 2: create_or_update_entity_attribute with FQN from result
```

**Example 2: Debug LazyInitializationException**
```
Input: "I get LazyInitializationException accessing user.orders"
Tool Call: { "entityName": "User", "projectPath": "/..." }
Look for: orders.relationshipProperties.fetch → should be EAGER or fixed with JOIN FETCH
Also check: owning side (mappedBy present = inverse side)
```

**Example 3: Understand inheritance**
```
Input: "How is Payment hierarchy set up?"
Tool Call: { "entityName": "Payment", "projectPath": "/..." }
Check: inheritanceType, discriminatorColumn, superclass
```

---

## find_spring_data_repositories

### Purpose
Discovers all Spring Data repository interfaces and their associated entities.

### When to Use
- Checking if a repository already exists for an entity
- Understanding the data access layer structure
- Finding which entities lack repositories
- Auditing repository coverage
- **ALWAYS call before `create_spring_data_repository`**

### Parameters

#### entityName (optional)
- **Type:** String
- **Description:** Filter by entity (simple name or FQN)
- **Examples:** `"User"`, `"com.example.Order"`
- **When to omit:** Want all repositories

#### moduleName (optional)
- **Type:** String
- **Description:** Scope to specific module

#### searchInLibraries (optional)
- **Type:** Boolean
- **Default:** false
- **When to set true:** Analyzing complete Spring Data ecosystem including inherited repos

#### projectPath (recommended)
- **Type:** String

### Return Value
```json
{
  "repositories": [
    {
      "name": "UserRepository",
      "path": "src/main/java/com/example/repository/UserRepository.java",
      "content": "public interface UserRepository extends JpaRepository<User, Long> { ... }",
      "entity": "User",
      "description": "Repository for User entity"
    }
  ]
}
```

### Usage Examples

**Example 1: Check before creating a repository**
```
Input: "Create a repository for Product"
Step 1: find_spring_data_repositories(entityName: "Product")
→ If empty: proceed to create_spring_data_repository
→ If found: inform user it already exists
```

**Example 2: Full repository audit**
```
Input: "Which entities don't have repositories?"
Step 1: find_jpa_entities() → list all entity names
Step 2: find_spring_data_repositories() → list all repos
Step 3: Compare → identify gaps
```

---

## reverse_engineering_jpa_entity_by_name

### Purpose
Generates JPA entity structure from an existing database table — for legacy database or database-first development.

### When to Use
- Integrating with an existing or legacy database
- Database-first development approach
- Rapid entity scaffolding from schema
- Understanding a database table's column types

### Parameters

#### entityTableName (required)
- **Type:** String
- **Description:** Actual database table name (usually snake_case)
- **Examples:** `"users"`, `"product_catalog"`, `"order_items"`

#### projectPath (recommended)
- **Type:** String

### Return Value
```json
{
  "attributes": [
    "id: Long",
    "username: String",
    "email: String",
    "created_at: Timestamp",
    "is_active: Boolean"
  ]
}
```

### Usage Examples

**Example 1: Generate entity from table**
```
Input: "Create an entity from the customers table"
Tool Call: { "entityTableName": "customers", "projectPath": "/path/to/project" }
Next step: Use result to inform create_jpa_entity call
```

**Example 2: Multiple tables**
```
Workflow for batch reverse engineering:
1. reverse_engineering_jpa_entity_by_name("orders")
2. reverse_engineering_jpa_entity_by_name("order_items")
3. For each: create_jpa_entity with generated attributes
```

---

## Common Tool Combinations

### Pattern 1: Pre-Implementation Discovery
```
1. find_jpa_entities()              → domain model overview
2. find_spring_data_repositories()  → repository coverage
3. get_project_modules()            → identify target module
4. list_directory_tree("src")       → understand structure
```

### Pattern 2: Entity Deep Dive
```
1. find_jpa_entities(entityPackage: "com.example.domain")
2. get_jpa_entity_by_name("User")
3. find_spring_data_repositories(entityName: "User")
4. search_in_files_by_text("UserRepository", directoryToSearch: "src/main")
```

### Pattern 3: Codebase Search
```
1. find_files_by_name_keyword("UserService")  → locate file
2. get_file_text_by_path("src/.../UserService.java")  → read content
3. search_in_files_by_text("userRepository")  → find usages
4. get_symbol_info(filePath, line, column)  → understand a symbol
```

### Pattern 4: Multi-Module Exploration
```
1. get_project_modules()  → identify all modules
2. find_jpa_entities(moduleName: "domain-module")  → entities in domain
3. find_spring_data_repositories(moduleName: "data-module")  → repos in data
4. list_directory_tree("domain-module/src")  → structure
```

---

## Best Practices

1. **Always pass `projectPath`** — reduces ambiguity and improves tool accuracy
2. **Start with `find_files_by_name_keyword`** for name-based searches — it is the fastest
3. **Call `find_jpa_entities` before creating any entity** — avoid duplicates and learn conventions
4. **Call `find_spring_data_repositories` before creating any repository** — avoid duplicates
5. **Call `get_jpa_entity_by_name` before modifying any entity** — understand current state
6. **Use `list_directory_tree` before any task** — understand project layout first
7. **Never use terminal commands for file reading or searching** — IDE tools are faster and IDE-aware
