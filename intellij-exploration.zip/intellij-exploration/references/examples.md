# IntelliJ Exploration — Examples

End-to-end examples for common exploration scenarios.

---

## Example 1: Understand Project Structure Before Starting Work

**Task:** Get a complete picture of a Spring Boot project before making any changes.

```
1. See overall layout
   list_directory_tree(directoryPath: "", maxDepth: 3, projectPath: "/path/to/project")
   → See: src/main/java, src/test, pom.xml, resources

2. Check project modules (multi-module?)
   get_project_modules(projectPath: "/path/to/project")

3. Check dependencies (Spring Boot version, JPA present?)
   get_project_dependencies(projectPath: "/path/to/project")

4. Discover domain model
   find_jpa_entities(projectPath: "/path/to/project")
   find_spring_data_repositories(projectPath: "/path/to/project")

5. Check available run configurations
   get_run_configurations(projectPath: "/path/to/project")
```

---

## Example 2: Find and Read a Specific File

**Task:** Find the `UserService` class and understand how it works.

```
1. Find the file (fastest approach — name-based)
   find_files_by_name_keyword(nameKeyword: "UserService", projectPath: "/path/to/project")
   → ["src/main/java/com/example/service/UserService.java"]

2. Read the file
   get_file_text_by_path(
     pathInProject: "src/main/java/com/example/service/UserService.java",
     projectPath: "/path/to/project"
   )

3. Understand a specific symbol (e.g., what does findActiveUsers return?)
   get_symbol_info(
     filePath: "src/main/java/com/example/service/UserService.java",
     line: 24,
     column: 19,
     projectPath: "/path/to/project"
   )
```

---

## Example 3: Analyze a JPA Entity and Its Relationships

**Task:** "What does the Order entity look like? What relationships does it have?"

```
1. Get full entity details
   get_jpa_entity_by_name(entityName: "Order", projectPath: "/path/to/project")
   → attributes: [id, totalAmount, status, user (ManyToOne LAZY), items (OneToMany)]
   → packageName: "com.example.domain"

2. Inspect related entity (if relationship found)
   get_jpa_entity_by_name(entityName: "User", projectPath: "/path/to/project")
   → Confirm User has "orders" OneToMany field with mappedBy: "user"

3. Find the Order repository
   find_spring_data_repositories(entityName: "Order", projectPath: "/path/to/project")
   → OrderRepository with custom queries
```

---

## Example 4: Search for Usage of a Pattern Across the Codebase

**Task:** Find all places where `@Transactional` is used.

```
1. Text search (fast, index-based)
   search_in_files_by_text(
     searchText: "@Transactional",
     fileMask: "*.java",
     projectPath: "/path/to/project"
   )
   → Returns file paths, line numbers, matching lines

2. Regex for @Transactional with readOnly
   search_in_files_by_regex(
     regexPattern: "@Transactional.*readOnly.*=.*true",
     fileMask: "*.java",
     projectPath: "/path/to/project"
   )
```

---

## Example 5: Understand What Files the User Is Working With

**Task:** User says "look at the file I have open." Understand their current context.

```
1. Check open editor files
   get_all_open_file_paths(projectPath: "/path/to/project")
   → activeFilePath: "src/main/java/com/example/domain/User.java"
   → openFiles: ["User.java", "UserService.java", "UserRepository.java"]

2. Read the active file
   get_file_text_by_path(
     pathInProject: "src/main/java/com/example/domain/User.java",
     projectPath: "/path/to/project"
   )

3. Get structured entity data (if it's a JPA entity)
   get_jpa_entity_by_name(entityName: "User", projectPath: "/path/to/project")
```

---

## Example 6: Debug a LazyInitializationException

**Task:** User reports `LazyInitializationException` on `order.getUser()`.

```
1. Get Order entity structure
   get_jpa_entity_by_name(entityName: "Order", projectPath: "/path/to/project")
   → user field: fetch = LAZY, relationship = ManyToOne

2. Get User entity structure
   get_jpa_entity_by_name(entityName: "User", projectPath: "/path/to/project")

3. Find where user is accessed in service
   search_in_files_by_text(
     searchText: "order.getUser()",
     fileMask: "*.java",
     projectPath: "/path/to/project"
   )
   → OrderService.java:45 — method missing @Transactional

4. Read the service method
   get_file_text_by_path(
     pathInProject: "src/main/java/com/example/service/OrderService.java",
     projectPath: "/path/to/project"
   )
   → Confirm missing @Transactional annotation
```
