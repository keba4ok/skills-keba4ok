---
name: intellij-exploration
description: >
  Comprehensive codebase discovery, navigation, and analysis using IntelliJ IDEA MCP tools.
  Use this skill whenever you need to understand, discover, or navigate an IntelliJ/Spring
  Boot project: explore project structure, modules, dependencies; find files by name,
  pattern, or content; read file contents; understand JPA entities and Spring Data
  repositories; reverse-engineer entities from database tables; check run configurations;
  or understand symbol definitions and declarations. Triggers on: project structure, find
  files, search for text, read/show/open file, show entities, find repositories, explore
  domain model, what modules/dependencies/run configurations exist, where is symbol defined.
---

# IntelliJ Exploration Skill

Codebase discovery, navigation, and analysis using IntelliJ IDEA MCP tools.

---

## CRITICAL: MANDATORY TOOL USAGE POLICY

**YOU MUST USE MCP TOOLS FOR ALL EXPLORATION TASKS. THIS IS NON-NEGOTIABLE.**

- **NEVER** use `cat`, `head`, `tail` to read files — use `mcp__jetbrains__get_file_text_by_path`
- **NEVER** use `grep` or `find` commands — use `mcp__jetbrains__search_in_files_by_text` or `mcp__jetbrains__find_files_by_name_keyword`
- **NEVER** use `ls` or `dir` to list directories — use `mcp__jetbrains__list_directory_tree`
- **NEVER** read entity files to understand JPA structure — use `mcp__jetbrains__find_jpa_entities` or `mcp__jetbrains__get_jpa_entity_by_name`
- **NEVER** search for `@Entity` with text/regex — use `mcp__jetbrains__find_jpa_entities`
- **NEVER** look for repositories by reading files — use `mcp__jetbrains__find_spring_data_repositories`
- **ALWAYS** prefer indexed IntelliJ tools over terminal commands — faster and IDE-aware
- **ALWAYS** pass `projectPath` in every tool call

---

## When to Use This Skill

- Explore project structure, modules, packages, dependencies
- Find specific files by name, pattern, or content
- Read and understand file contents before making changes
- Understand JPA entities, their attributes, and relationships
- Find Spring Data repositories
- Check available run configurations
- Understand symbol definitions and types
- Audit the JPA domain model before creating new entities

## Trigger Keywords

"project structure", "find files", "search for text", "read/show/open file", "show me all entities", "what entities exist", "find repositories", "explore domain model", "what modules/dependencies/run configurations exist", "where is symbol defined", "what files are open"

---

## Available Tools

All tools use the `mcp__jetbrains__` prefix.

### Navigation & Discovery

| Tool | Purpose | Never Do Instead |
|---|---|---|
| `list_directory_tree` | Tree view of a directory | `ls`, `tree` |
| `find_files_by_name_keyword` | Find files by partial name — index-based, fastest | `find -name` |
| `find_files_by_glob` | Find files by glob pattern | `find` with glob |
| `get_all_open_file_paths` | Files open in IDE editor | — |
| `get_project_modules` | All modules with types | — |
| `get_project_dependencies` | All library dependencies | — |
| `get_repositories` | VCS roots and types | — |
| `get_run_configurations` | Run configurations with details | — |
| `open_file_in_editor` | Open a file in the IDE | — |

### File Content & Code Intelligence

| Tool | Purpose | Never Do Instead |
|---|---|---|
| `get_file_text_by_path` | Read file content | `cat`, `head`, `tail` |
| `search_in_files_by_text` | Substring search across project | `grep` |
| `search_in_files_by_regex` | Regex search across project | `grep -E`, `rg` |
| `get_symbol_info` | Declaration and docs for a symbol | — |

### JPA & Spring Data Discovery

| Tool | Purpose | When |
|---|---|---|
| `find_jpa_entities` | Discover all @Entity classes | Before creating any entity |
| `get_jpa_entity_by_name` | Full entity details (attributes, relationships) | Before modifying any entity |
| `find_spring_data_repositories` | Discover all repositories | Before creating any repository |
| `reverse_engineering_jpa_entity_by_name` | Entity structure from DB table | Legacy/database-first work |

---

## Workflow

```
Finding files?
  name known → find_files_by_name_keyword (fastest)
  pattern    → find_files_by_glob
  content    → search_in_files_by_text / search_in_files_by_regex

Reading content?
  → get_file_text_by_path

Understanding a symbol?
  → get_file_text_by_path (get line/col) → get_symbol_info

Understanding JPA?
  all entities   → find_jpa_entities
  one entity     → get_jpa_entity_by_name
  repositories   → find_spring_data_repositories
  from DB table  → reverse_engineering_jpa_entity_by_name

Project metadata?
  modules → get_project_modules
  deps    → get_project_dependencies
  configs → get_run_configurations
```

---

## Reference Files

- **references/tool-reference.md** — All 17 tools: parameters, return values, examples
- **references/examples.md** — 6 end-to-end exploration scenarios (project overview, entity analysis, debugging)
- **references/patterns.md** — Common exploration workflows (pre-implementation, file finding, JPA, debugging)
- **references/best-practices.md** — Tool selection guide, anti-patterns, exploration sequence for unknown projects

## Next Steps After Exploration

After exploration, use the **intellij-implementation** skill to:
- Create new entities, attributes, or repositories
- Modify existing files using replace_text_in_file or rename_refactoring

After implementation, use the **intellij-testing** skill to:
- Build the project to validate compilation
- Run tests or run configurations
